# Checklist Mestre de Auditoria de Segurança — AI Security Auditor

Este checklist estruturado deve ser utilizado pelo auditor de IA e pela equipe técnica para orientar a cobertura das verificações de segurança em cada domínio durante as Fases C e D da metodologia.

---

## 1. Autenticação e Gestão de Sessões

- [ ] **1.1. Armazenamento e Criptografia de Senhas**: Algoritmos modernos de hashing com salting (Argon2id, bcrypt com fator de custo adequado >= 12, scrypt). Ausência de MD5, SHA1 ou texto claro.
- [ ] **1.2. Proteção contra Força Bruta e Rate Limiting**: Limites de tentativas por IP, por conta de usuário e globais nos endpoints `/login`, `/auth`, `/oauth/token`.
- [ ] **1.3. Bloqueio Temporário e Defesa contra Credential Stuffing**: Mecanismos de lockout progressivo ou desafios CAPTCHA invisíveis após falhas sucessivas.
- [ ] **1.4. Autenticação Multifator (MFA / 2FA)**: Suporte a TOTP (RFC 6238) ou WebAuthn/FIDO2. Proteção contra repetição (replay) de tokens e rate limit no endpoint de validação.
- [ ] **1.5. Fluxo de Recuperação de Senha**: Tokens criptograficamente seguros (CSPRNG, mínimo 128 bits), uso único, expiração curta (máximo 15-30 minutos) e invalidação de sessões prévias.
- [ ] **1.6. Enumeração de Usuários**: Mensagens genéricas de erro no login e recuperação (ex: "Se o e-mail existir, você receberá instruções") e proteção contra oráculos de tempo (timing attacks).
- [ ] **1.7. Ciclo de Vida da Sessão**: Geração de novo ID de sessão após login bem-sucedido (prevenção de Session Fixation).
- [ ] **1.8. Atributos de Cookies de Sessão**: Flags obrigatórias `Secure`, `HttpOnly` e `SameSite=Lax` ou `Strict`. Ausência de dados sensíveis descriptografados no cookie.
- [ ] **1.9. Invalidação Completa no Logout**: Destruição real do identificador de sessão no backend (tabela/Redis) e limpeza no cliente.
- [ ] **1.10. Expiração por Ociosidade e Absoluta**: Timeout automático após inatividade (ex: 15-30 min) e tempo de vida máximo forçado (ex: 8-12 horas).
- [ ] **1.11. Tokens "Lembre-se de mim"**: Tokens randômicos hashados no banco, nunca armazenando a senha ou credencial reutilizável.
- [ ] **1.12. Implementação OAuth 2.0 / OIDC**: Validação rigorosa do parâmetro `state` (anti-CSRF), `redirect_uri` com correspondência exata, e suporte a PKCE para clientes públicos.
- [ ] **1.13. Trilhas de Auditoria de Acesso**: Registro estruturado de tentativas de login (sucesso/falha), alteração de credenciais e troca de privilégios.

---

## 2. Segurança de APIs (REST & GraphQL)

- [ ] **2.1. Controle de Acesso por Objeto (BOLA / IDOR)**: Validação a nível de registro se o usuário solicitante tem propriedade/permissão sobre o recurso referenciado (IDs numéricos ou UUIDs).
- [ ] **2.2. Controle de Acesso por Função (BFLA)**: Proteção de endpoints administrativos (`/admin/*`, `/internal/*`) rejeitando chamadas de usuários comuns.
- [ ] **2.3. Atribuição em Massa (Mass Assignment)**: Validação estrita de schemas de entrada (DTOs/Zod/Pydantic), proibindo que campos internos (ex: `is_admin`, `balance`, `role`) sejam populados via payload do cliente.
- [ ] **2.4. Validação de JWT**:
  - [ ] Algoritmo estritamente definido no backend (rejeição de `alg: none` e proteção contra chave assimétrica/simétrica HMAC spoofing).
  - [ ] Verificação de expiração (`exp`), audiência (`aud`) e emissor (`iss`).
  - [ ] Assinatura validada com chave privada/segredo de alta entropia.
- [ ] **2.5. Configuração de CORS**: Ausência de reflexão arbitrária do header `Origin` com `Access-Control-Allow-Credentials: true`. Domínios confiáveis explicitamente listados.
- [ ] **2.6. Rate Limiting e Throttling por Endpoint**: Proteção contra sobrecarga e abuso em rotas computacionalmente pesadas ou de busca.
- [ ] **2.7. GraphQL — Introspecção e Limites de Consulta**: Introspecção (`__schema`) desabilitada em produção; limites máximos de profundidade de query (query depth) e complexidade de custo.
- [ ] **2.8. GraphQL — Prevenção de Batching Attacks**: Limite de aliases e requisições agrupadas para evitar bypass de rate limit de login.
- [ ] **2.9. Tratamento de Exceções**: Supressão de stack traces técnicos, logs do framework ou versões de bibliotecas nas mensagens de erro da API.
- [ ] **2.10. Filtragem de Dados de Saída**: Ocultação de atributos sensíveis (ex: senhas, chaves privadas, campos de auditoria interna) antes do envio da resposta JSON.

---

## 3. Segurança de Código-Fonte e SAST

- [ ] **3.1. Injeção de SQL (SQLi)**: Utilização universal de Prepared Statements / ORM seguro; ausência de concatenação de strings em cláusulas `WHERE`, `ORDER BY` ou `TABLE`.
- [ ] **3.2. Cross-Site Scripting (XSS)**: Sanitização e escape contextual de entradas refletidas no DOM; uso de frameworks com auto-escaping (React, Vue, Angular).
- [ ] **3.3. Injeção de Comandos (Command Injection)**: Ausência de chamadas a `eval()`, `exec()`, `system()`, `child_process.exec()` com argumentos fornecidos pelo usuário.
- [ ] **3.4. Server-Side Request Forgery (SSRF)**: Validação de URLs externas contra lista de permissões; bloqueio de requisições a endereços locais (`localhost`, `127.0.0.1`, `169.254.169.254`, faixas privadas RFC 1918).
- [ ] **3.5. Desserialização Insegura**: Proibição de módulos vulneráveis (`pickle`, `yaml.load` sem `SafeLoader`, `unserialize` nativo) sobre payloads não confiáveis.
- [ ] **3.6. Segredos no Código e no Git**: Ausência de API keys, senhas, certificados ou tokens hardcoded no código ou no histórico de commits (validado com Gitleaks).
- [ ] **3.7. Validação de Dependências (SCA)**: Varredura de dependências de terceiros com Trivy/npm audit/pip-audit em busca de CVEs conhecidas sem correção.
- [ ] **3.8. Manipulação Segura de Arquivos / Path Traversal**: Validação de nomes de arquivos sanitizados, ausência de sequências `../`, armazenamento fora do web root.
- [ ] **3.9. Concorrência e Race Conditions**: Transações atômicas com bloqueio adequado (`SELECT ... FOR UPDATE`) em fluxos de débito/crédito e resgate de vouchers.

---

## 4. Bancos de Dados e Persistência

- [ ] **4.1. PostgreSQL / Supabase — Row Level Security (RLS)**: RLS habilitado explicitamente em todas as tabelas com dados de múltiplos locatários (`ALTER TABLE ... ENABLE ROW LEVEL SECURITY`).
- [ ] **4.2. Supabase — Políticas de RLS Granulares**: Políticas separadas para `SELECT`, `INSERT`, `UPDATE` e `DELETE` validando `auth.uid() = user_id`.
- [ ] **4.3. Supabase — Exposição de Chaves**: Apenas a chave `anon` pública no frontend; a chave `service_role` protegida estritamente em backends confidenciais.
- [ ] **4.4. Princípio do Menor Privilégio nas Contas de Banco**: Usuário da aplicação sem privilégios de `SUPERUSER`, `CREATEROLE` ou `DROP DATABASE`.
- [ ] **4.5. Criptografia em Trânsito (TLS/SSL)**: Conexões de banco exigindo SSL obrigatório (`sslmode=require` ou `verify-full`).
- [ ] **4.6. Criptografia em Repouso (TDE)**: Volumes de dados e backups criptografados com chaves gerenciadas de forma segura.
- [ ] **4.7. Exposição de Portas de Banco**: Portas de banco (ex: 5432, 3306, 27017) restritas a redes privadas, nunca expostas diretamente na internet pública.

---

## 5. Rede, Infraestrutura e Serviços Expostos

- [ ] **5.1. Inventário de Portas Abertas**: Apenas portas estritamente necessárias abertas (ex: 80, 443). Portas de gerência (SSH 22, RDP 3389) restritas via VPN/Bastion.
- [ ] **5.2. Configuração de TLS/SSL**: TLS 1.2 e 1.3 habilitados; SSL v2/v3 e TLS 1.0/1.1 desativados. Ciphers modernos com Forward Secrecy (ECDHE).
- [ ] **5.3. Certificados Digitais**: Certificados válidos, emitidos por CA confiável, cobrindo os nomes corretos (SAN) e sem expiração iminente.
- [ ] **5.4. Headers de Proteção HTTP**:
  - `Strict-Transport-Security: max-age=31536000; includeSubDomains; preload`
  - `X-Content-Type-Options: nosniff`
  - `X-Frame-Options: DENY` ou `SAMEORIGIN`
  - `Content-Security-Policy` restritiva
  - `Referrer-Policy: strict-origin-when-cross-origin`
- [ ] **5.5. Segmentação de Rede**: Isolamento entre camada de apresentação, serviços de aplicação e bases de dados.
- [ ] **5.6. Configurações de DNS**: Registros SPF, DKIM e DMARC adequadamente configurados para prevenção de spoofing e phishing.

---

## 6. Cloud, SaaS e Containers

- [ ] **6.1. Gestão de Identidades e Acessos (IAM)**: Princípio de menor privilégio aplicado; ausência de credenciais com permissões coringa (`*`).
- [ ] **6.2. Buckets e Armazenamento em Objeto**: Políticas de acesso público bloqueadas (S3 Block Public Access / GCP bucket-level access) em dados confidenciais.
- [ ] **6.3. Segurança de Containers**: Containers rodando como usuário não-root; imagens base mínimas e escaneadas com Trivy.
- [ ] **6.4. Pipelines de CI/CD**: Segredos injetados via variáveis protegidas de ambiente; permissões restritas em runners e branches protegidas.
- [ ] **6.5. Monitoramento e Detecção**: Logs de auditoria (AWS CloudTrail, GCP Cloud Audit Logs, Supabase Logs) ativados com retenção adequada.
