# Relatório de Auditoria de Segurança — [Nome do Projeto]

---

## Metadados da Auditoria

| Campo | Valor |
| :--- | :--- |
| **Identificador do Relatório** | `REP-YYYYMMDD-001` |
| **Identificador do Escopo** | `AUD-YYYYMMDD-001` |
| **Data e Hora de Emissão** | `AAAA-MM-DDTHH:MM:SSZ` |
| **Auditor Responsável** | AI Security Auditor (Engenharia de Segurança) |
| **Ambiente Avaliado** | [Homologação / Staging / Produção / Laboratório] |
| **Modo de Auditoria** | [Passivo / Ativo Autorizado / Análise Estática de Código] |

---

## 1. Resumo Executivo

[Visão geral executiva em linguagem clara para tomada de decisão gerencial. Descreva o estado geral da segurança dos ativos analisados, a postura defensiva observada e as principais prioridades de remediação.]

### Matriz Consolidada de Riscos e Descobertas

| Severidade | Quantidade | Status Típico |
| :--- | :---: | :--- |
| 🔴 **Crítica (Critical)** | 0 | Ação imediata requerida |
| 🟠 **Alta (High)** | 0 | Correção no curto prazo |
| 🟡 **Média (Medium)** | 0 | Correção no ciclo de sprint regular |
| 🟢 **Baixa (Low)** | 0 | Endurecimento e hardening |
| 🔵 **Informativa (Info)** | 0 | Boas práticas de arquitetura |
| **Total de Achados** | **0** | |

---

## 2. Escopo Autorizado

A auditoria foi restrita estritamente aos ativos autorizados conforme documentado no arquivo de escopo aprovado:

- **Alvos Analisados**:
  - `[Alvo 1: URL / Domínio / Repositório]` (Ambiente: [Staging/Lab])
  - `[Alvo 2: API Endpoint / Base de Dados]` (Ambiente: [Staging/Lab])
- **Ações Proibidas e Respeitadas**:
  - Negação de serviço (DoS/DDoS)
  - Força bruta massiva de senhas e credential stuffing
  - Modificação ou exfiltração de dados reais
  - Exploração automática de alto impacto
- **Contatos Técnicos de Emergência**:
  - Responsável: `[Nome / E-mail]`

---

## 3. Metodologia Aplicada

A auditoria seguiu a metodologia do **AI Security Auditor**, em conformidade com:
- **OWASP Top 10 Web Application Security Risks**
- **OWASP API Security Top 10**
- **PTES (Penetration Testing Execution Standard)**
- **NIST SP 800-115 (Technical Guide to Information Security Testing and Assessment)**
- **CVSS v3.1** para mensuração de severidade

---

## 4. Ferramentas Utilizadas

| Ferramenta | Versão | Finalidade Específica |
| :--- | :--- | :--- |
| `Semgrep` | [versão ou "N/A"] | Análise estática de código-fonte (SAST) |
| `Trivy` | [versão ou "N/A"] | Varredura de dependências e vulnerabilidades conhecidas |
| `Gitleaks` | [versão ou "N/A"] | Detecção de segredos expostos no repositório |
| `Nmap` | [versão ou "N/A"] | Inventário restrito de portas e serviços autorizados |
| `Scripts Locais` | 1.0.0 | Validação de escopo e higienização de evidências |

---

## 5. Limitações Metodológicas da Auditoria

1. **Modo Não Destrutivo**: Testes de estresse, concorrência extrema e injeções com potencial destrutivo não foram executados para preservar a integridade dos serviços.
2. **Ambiente de Homologação**: Algumas proteções de borda (como CDN corporativa e WAF) presentes em produção podem não estar ativas no ambiente de testes.
3. **Restrição Temporal e de Taxa**: As verificações respeitaram o teto de requisições por segundo acordado, prevenindo exaustão de recursos.

---

## 6. Descobertas e Vulnerabilidades Detalhadas

*(Repetir a estrutura abaixo para cada achado identificado)*

### FIND-0001: [Título Descritivo da Vulnerabilidade]

* **Status**: `[confirmed | suspected | insecure_configuration | false_positive | not_tested | inconclusive]`
* **Severidade**: `[critical | high | medium | low | informational]`
* **Pontuação CVSS v3.1**: `X.X` (`CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N`)
* **Classificação CWE**: `CWE-XXX: [Nome do CWE]`
* **Probabilidade de Exploração**: `[high | medium | low]`

#### Descrição Técnica
[Explicação detalhada do mecanismo da vulnerabilidade, contexto da aplicação onde ela ocorre e fatores que facilitam sua ocorrência.]

#### Evidência Sanitizada
> ⚠️ **Nota de Higienização**: Todos os tokens, credenciais e dados pessoais foram estritamente mascarados antes da inclusão neste relatório.

```http
POST /api/v1/exemplo HTTP/1.1
Host: api-staging.exemplo.com.br
Authorization: Bearer eyJhbGciOi...[TOKEN REDACTED]...
Content-Type: application/json

{
  "usuario_id": "1002",
  "dado_solicitado": "financeiro"
}
```

#### Impacto
[Análise objetiva do impacto para confidencialidade, integridade e disponibilidade caso um atacante explore a vulnerabilidade.]

#### Recomendações de Correção
1. **Curto Prazo (Mitigação Imediata)**:
   - [Passo de contenção rápida, ex: ajustar regras de firewall ou desabilitar rota não utilizada]
2. **Longo Prazo (Correção Estrutural)**:
   - [Passo arquitetural definitivo, ex: implementar validação de propriedade do objeto na camada de serviço]

#### Referências Técnicas
- [Link de referência OWASP / CWE / NIST]

---

## 7. Resultados de Reteste (Se Aplicável)

| ID do Achado | Data do Reteste | Status | Observações |
| :--- | :--- | :--- | :--- |
| `FIND-0001` | AAAA-MM-DD | `[fixed / partially_fixed / not_fixed]` | [Resumo do comportamento no reteste] |

---

## 8. Conclusão e Próximos Passos

[Síntese das recomendações estratégicas, cronograma sugerido de correções e diretrizes para reteste de validação.]
