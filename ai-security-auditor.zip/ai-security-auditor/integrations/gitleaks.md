# Integração com Gitleaks

> **Requisito**: Esta integração requer que o [Gitleaks](https://gitleaks.io/) esteja instalado no sistema.

## Visão Geral

O Gitleaks é uma ferramenta especializada na detecção de segredos (senhas, chaves de API, tokens, certificados) em repositórios Git. Ele analisa o histórico completo de commits para encontrar informações sensíveis que foram acidentalmente commitadas, mesmo que já tenham sido removidas em commits posteriores.

### Por que usar o Gitleaks na auditoria de segurança?

- **Detecção em histórico Git**: Encontra segredos em todo o histórico de commits, não apenas no estado atual.
- **Regras extensivas**: Mais de 150 regras pré-configuradas para detectar diferentes tipos de segredos.
- **Modo pre-commit**: Pode ser usado como hook de pre-commit para prevenir vazamentos futuros.
- **Configuração customizável**: Regras personalizadas via TOML para padrões específicos da organização.
- **Rápido e eficiente**: Escrito em Go, com varredura paralela de alta performance.
- **Saída estruturada**: Resultados em JSON para fácil integração e processamento.

---

## Detecção e Verificação de Instalação

### Verificar se o Gitleaks está instalado

```bash
gitleaks version
```

**Saída esperada** (exemplo):
```
v8.18.2
```

### Versão mínima suportada

| Requisito         | Valor     |
|--------------------|-----------|
| Versão mínima      | `8.16.0`  |

### Instalação (referência rápida)

```bash
# Via Homebrew (macOS/Linux)
brew install gitleaks

# Via Go
go install github.com/gitleaks/gitleaks/v8@latest

# Via Chocolatey (Windows)
choco install gitleaks

# Via Docker
docker pull ghcr.io/gitleaks/gitleaks:latest

# Download binário direto (Linux)
wget https://github.com/gitleaks/gitleaks/releases/latest/download/gitleaks_8.18.2_linux_x64.tar.gz
tar -xzf gitleaks_8.18.2_linux_x64.tar.gz
sudo mv gitleaks /usr/local/bin/
```

---

## Modos de Varredura

### 1. Modo `detect` — Varredura do estado atual e histórico

O modo `detect` analisa o repositório Git, incluindo todo o histórico de commits, para encontrar segredos que foram commitados.

```bash
# Varredura completa do repositório (incluindo histórico)
gitleaks detect --source /caminho/do/repositorio --report-format json --report-path gitleaks-results.json

# Varredura apenas do estado atual (sem histórico)
gitleaks detect --source /caminho/do/repositorio --no-git --report-format json --report-path gitleaks-results.json

# Varredura verbosa com logs detalhados
gitleaks detect --source /caminho/do/repositorio --verbose --report-format json --report-path gitleaks-results.json

# Varredura de commits específicos (range)
gitleaks detect --source /caminho/do/repositorio --log-opts="--since=2024-01-01" --report-format json --report-path gitleaks-results.json
```

### 2. Modo `protect` — Proteção pre-commit

O modo `protect` verifica apenas as alterações que estão prestes a ser commitadas (*staged changes*), ideal para uso como hook de pre-commit.

```bash
# Verificar alterações staged
gitleaks protect --source /caminho/do/repositorio --report-format json --report-path protect-results.json

# Verificar alterações staged com verbose
gitleaks protect --source /caminho/do/repositorio --verbose
```

**Configuração como hook de pre-commit (`.pre-commit-config.yaml`):**
```yaml
repos:
  - repo: https://github.com/gitleaks/gitleaks
    rev: v8.18.2
    hooks:
      - id: gitleaks
```

### Comparação entre os modos

| Característica        | `detect`                            | `protect`                          |
|------------------------|--------------------------------------|------------------------------------|
| **Escopo**             | Todo o repositório + histórico      | Apenas alterações staged           |
| **Uso principal**      | Auditoria de segurança              | Prevenção em tempo de desenvolvimento |
| **Performance**        | Pode ser lento em repositórios grandes | Rápido — analisa apenas o diff   |
| **Quando usar**        | Durante auditorias                  | Como hook de pre-commit            |

---

## Configuração e Regras Customizadas

### Arquivo de configuração `.gitleaks.toml`

O Gitleaks pode ser configurado com um arquivo TOML para definir regras customizadas e exceções.

```toml
# .gitleaks.toml - Configuração customizada para auditoria

title = "Configuração Gitleaks - Auditoria de Segurança"

# Regras customizadas
[[rules]]
id = "internal-api-key"
description = "Chave de API interna detectada"
regex = '''(?i)INTERNAL[_-]?API[_-]?KEY\s*[=:]\s*['"]?([a-zA-Z0-9]{32,})['"]?'''
tags = ["api-key", "internal"]
keywords = ["internal_api_key", "INTERNAL-API-KEY"]

[[rules]]
id = "database-connection-string"
description = "String de conexão com banco de dados detectada"
regex = '''(?i)(mongodb|postgres|mysql|mssql):\/\/[^:\s]+:[^@\s]+@[^\/\s]+'''
tags = ["database", "connection-string"]
keywords = ["mongodb://", "postgres://", "mysql://"]

# Allowlist global - caminhos e padrões a ignorar
[allowlist]
description = "Exceções globais"
paths = [
    '''\.gitleaks\.toml$''',
    '''(.*?)test(.*?)\.go$''',
    '''vendor/''',
    '''node_modules/''',
    '''\.git/''',
    '''go\.sum$''',
    '''package-lock\.json$''',
]
```

### Usar configuração customizada

```bash
gitleaks detect --source /caminho/do/repositorio --config /caminho/para/.gitleaks.toml --report-format json --report-path results.json
```

### Listar regras disponíveis

Para ver todas as regras padrão que o Gitleaks utiliza:

```bash
gitleaks detect --source /caminho/do/repositorio --verbose 2>&1 | grep "rule:"
```

---

## Exemplos de Comandos para Auditoria

### Varredura completa de repositório

```bash
gitleaks detect \
  --source /caminho/do/repositorio \
  --report-format json \
  --report-path gitleaks-full-scan.json \
  --verbose
```

### Varredura apenas de commits recentes (últimos 30 dias)

```bash
gitleaks detect \
  --source /caminho/do/repositorio \
  --log-opts="--since='30 days ago'" \
  --report-format json \
  --report-path gitleaks-recent.json
```

### Varredura de branch específica

```bash
gitleaks detect \
  --source /caminho/do/repositorio \
  --log-opts="main..develop" \
  --report-format json \
  --report-path gitleaks-branch-diff.json
```

### Varredura sem histórico Git (apenas arquivos atuais)

```bash
gitleaks detect \
  --source /caminho/do/projeto \
  --no-git \
  --report-format json \
  --report-path gitleaks-files-only.json
```

### Varredura via Docker

```bash
docker run --rm \
  -v /caminho/do/repositorio:/repo \
  ghcr.io/gitleaks/gitleaks:latest \
  detect --source /repo \
  --report-format json \
  --report-path /repo/gitleaks-results.json
```

---

## Interpretação dos Resultados

### Estrutura de um achado

```json
{
  "Description": "AWS Access Key ID",
  "StartLine": 15,
  "EndLine": 15,
  "StartColumn": 20,
  "EndColumn": 40,
  "Match": "AKIA********************",
  "Secret": "AKIA********************",
  "File": "config/settings.py",
  "SymlinkFile": "",
  "Commit": "a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2",
  "Entropy": 3.684,
  "Author": "desenvolvedor@exemplo.com.br",
  "Email": "desenvolvedor@exemplo.com.br",
  "Date": "2024-03-15T10:30:00Z",
  "Message": "feat: adicionar configuração da AWS",
  "Tags": ["aws", "access-key"],
  "RuleID": "aws-access-key-id",
  "Fingerprint": "a1b2c3d4:config/settings.py:aws-access-key-id:15"
}
```

### Campos importantes para auditoria

| Campo          | Descrição                                                           |
|-----------------|---------------------------------------------------------------------|
| `RuleID`        | Identificador da regra que detectou o segredo                      |
| `Description`   | Descrição do tipo de segredo encontrado                            |
| `File`          | Arquivo onde o segredo foi encontrado                              |
| `StartLine`     | Linha onde o segredo inicia                                        |
| `Secret`        | O valor do segredo encontrado (deve ser redatado no relatório!)     |
| `Commit`        | Hash do commit onde o segredo foi introduzido                      |
| `Author`        | Autor do commit que introduziu o segredo                           |
| `Date`          | Data do commit                                                     |
| `Entropy`       | Entropia de Shannon do segredo (valores altos = mais aleatório)    |
| `Fingerprint`   | Identificador único do achado                                      |

### Entropia (Shannon Entropy)

A entropia mede a aleatoriedade de uma string. Valores mais altos indicam maior probabilidade de ser um segredo real.

| Faixa de Entropia | Interpretação                                      |
|---------------------|-----------------------------------------------------|
| `> 4.5`             | Alta aleatoriedade — muito provavelmente um segredo |
| `3.5 - 4.5`         | Aleatoriedade moderada — requer validação manual    |
| `< 3.5`             | Baixa aleatoriedade — pode ser falso positivo       |

---

## Tratamento de Falsos Positivos e Allowlists

### Allowlist via arquivo de configuração

```toml
# .gitleaks.toml

[allowlist]
description = "Exceções documentadas"

# Ignorar caminhos específicos
paths = [
    '''tests/fixtures/''',
    '''docs/examples/''',
    '''\.env\.example$''',
]

# Ignorar commits específicos
commits = [
    "abc123def456...",
]

# Ignorar regex específicos
regexTarget = "match"
regexes = [
    '''EXEMPLO_DE_CHAVE_FAKE''',
    '''test-api-key-12345''',
]
```

### Allowlist por regra específica

```toml
[[rules]]
id = "aws-access-key-id"
description = "AWS Access Key ID"
regex = '''(A3T[A-Z0-9]|AKIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ASIA)[A-Z0-9]{16}'''

[rules.allowlist]
description = "Exceções para AWS Access Key"
regexes = [
    '''AKIAEXEMPLO12345678''',
]
paths = [
    '''tests/mock_aws\.py''',
]
```

### Documentação de falsos positivos

Para cada falso positivo identificado, documente:

1. **RuleID**: Regra que disparou o alerta
2. **Arquivo e linha**: Localização do achado
3. **Commit**: Hash do commit relevante
4. **Justificativa**: Por que é um falso positivo (ex: "valor de exemplo na documentação", "chave de teste sem permissões reais")
5. **Ação tomada**: Se foi adicionado à allowlist e por quem
6. **Data da validação**: Quando foi revisado

---

## Formatos de Saída

### JSON (recomendado)

```bash
gitleaks detect --source /repo --report-format json --report-path results.json
```

### CSV

```bash
gitleaks detect --source /repo --report-format csv --report-path results.csv
```

### SARIF (para integração com plataformas de código)

```bash
gitleaks detect --source /repo --report-format sarif --report-path results.sarif
```

### Parsing dos resultados (Python)

```python
import json

with open("gitleaks-results.json", "r") as f:
    findings = json.load(f)

print(f"Total de segredos encontrados: {len(findings)}")
print()

# Agrupar por tipo de segredo
from collections import Counter
tipos = Counter(f["RuleID"] for f in findings)

print("Segredos por tipo:")
for tipo, contagem in tipos.most_common():
    print(f"  {tipo}: {contagem}")

print()
print("Detalhes dos achados:")
for finding in findings:
    print(f"  [{finding['RuleID']}] {finding['File']}:{finding['StartLine']}")
    print(f"    Commit: {finding['Commit'][:12]}...")
    print(f"    Autor: {finding['Author']}")
    print(f"    Data: {finding['Date']}")
    # NUNCA imprimir o valor do segredo em logs ou relatórios!
    print(f"    Segredo: [REDATADO]")
    print()
```

---

## Segurança e Boas Práticas

> ⚠️ **REGRAS DE SEGURANÇA CRÍTICAS** para uso do Gitleaks na auditoria.

### 1. Varredura somente leitura

O Gitleaks opera exclusivamente em modo de leitura. Ele **não** modifica arquivos, commits ou configurações do repositório.

### 2. NUNCA exfiltrar segredos encontrados

- **Nunca** copie, compartilhe ou armazene os valores reais dos segredos encontrados.
- Nos relatórios, **sempre** redatar os segredos, mostrando apenas os primeiros e últimos caracteres (ex: `AKIA****XYZ`).
- Os resultados brutos do Gitleaks contêm os valores completos — proteja esses arquivos adequadamente.

### 3. Redação nos relatórios

Ao incluir achados do Gitleaks no relatório de auditoria:

```
❌ INCORRETO:
Encontrada chave AWS: AKIAIOSFODNN7EXEMPLO

✅ CORRETO:
Encontrada chave AWS: AKIA************MPLO
Arquivo: config/settings.py, linha 15
Commit: a1b2c3d4 (2024-03-15)
```

### 4. Comunicação responsável

- Notifique imediatamente o responsável pela segurança quando segredos válidos forem encontrados.
- Recomende a rotação imediata de todos os segredos expostos.
- Verifique se os segredos encontrados ainda são válidos (sem testá-los em sistemas de produção).

### 5. Proteja os resultados da varredura

- Armazene os arquivos de resultado em local seguro com controle de acesso.
- Exclua os resultados brutos após a conclusão da auditoria.
- Nunca envie resultados por canais não criptografados.

### 6. Documente tudo

Registre para cada varredura:
- Data e hora
- Versão do Gitleaks utilizada
- Modo de varredura (`detect` ou `protect`)
- Repositório e branches escaneados
- Configurações customizadas aplicadas
- Número total de achados
- Número de falsos positivos identificados

---

## Fluxo de Trabalho Recomendado

```
1. Verificar instalação e versão do Gitleaks
   ↓
2. Confirmar escopo autorizado (repositórios e branches)
   ↓
3. Preparar configuração customizada (se necessário)
   ↓
4. Executar varredura detect no repositório completo
   ↓
5. Executar varredura sem histórico (--no-git) para estado atual
   ↓
6. Coletar e consolidar resultados em JSON
   ↓
7. Triar achados: validar quais são segredos reais vs. falsos positivos
   ↓
8. Redatar segredos nos relatórios
   ↓
9. Documentar falsos positivos com justificativa
   ↓
10. Comunicar segredos válidos encontrados ao responsável de segurança
   ↓
11. Recomendar rotação dos segredos expostos
   ↓
12. Incluir achados redatados no relatório de auditoria
```
