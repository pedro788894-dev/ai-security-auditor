# Integração com OWASP ZAP

> **Requisito**: Esta integração requer que o [OWASP ZAP](https://www.zaproxy.org/) esteja instalado e em execução no sistema.

## Visão Geral

O OWASP ZAP (*Zed Attack Proxy*) é um scanner de segurança para aplicações web, mantido pela OWASP Foundation. Ele funciona como um proxy intermediário entre o navegador e a aplicação alvo, permitindo interceptar, inspecionar e modificar o tráfego HTTP/HTTPS para identificar vulnerabilidades.

### Por que usar o ZAP na auditoria de segurança?

- **Scanner DAST completo**: Testes dinâmicos de segurança de aplicações web (*Dynamic Application Security Testing*).
- **Varredura passiva e ativa**: Dois modos complementares de detecção de vulnerabilidades.
- **API REST**: Automação completa via API para integração com scripts e pipelines.
- **Modo daemon**: Execução em segundo plano para automação contínua.
- **Gratuito e open source**: Sem custos de licenciamento.
- **Extensível**: Suporte a marketplace de extensões e scripts personalizados.

---

## Detecção e Verificação de Instalação

### Verificar se o ZAP está instalado

**Linux/macOS:**
```bash
# Verificar o binário
which zap.sh || which zaproxy

# Ou via Java
java -jar /caminho/para/zap.jar -version
```

**Windows:**
```powershell
# Verificar se o executável existe
Get-Command zap.exe -ErrorAction SilentlyContinue

# Ou verificar o processo em execução
Get-Process -Name "ZAP" -ErrorAction SilentlyContinue
```

### Verificar se o ZAP está em execução (modo daemon)

```bash
curl -s http://localhost:8080/JSON/core/view/version/
```

**Resposta esperada:**
```json
{"version": "2.15.0"}
```

### Versão mínima suportada

| Requisito         | Valor     |
|--------------------|-----------|
| Versão mínima      | `2.14.0`  |
| Java               | `>= 11`   |

### Instalação (referência rápida)

```bash
# Via pacote oficial (Linux)
sudo apt install zaproxy

# Via Homebrew (macOS)
brew install --cask zap

# Via Docker (recomendado para automação)
docker pull zaproxy/zap-stable

# Windows: baixar instalador em https://www.zaproxy.org/download/
```

---

## Varredura Passiva vs. Varredura Ativa

### Varredura Passiva

A varredura passiva **observa** o tráfego sem modificá-lo. Ela analisa requisições e respostas HTTP que passam pelo proxy para identificar problemas de segurança.

| Característica             | Descrição                                                    |
|-----------------------------|--------------------------------------------------------------|
| **Risco para o alvo**       | Nenhum — não envia requisições adicionais                   |
| **Velocidade**              | Rápida — análise em tempo real do tráfego existente         |
| **Detecções típicas**       | Headers de segurança ausentes, cookies inseguros, informações expostas |
| **Autorização necessária**  | Mínima — apenas navegação normal na aplicação               |
| **Quando usar**             | **Sempre como primeiro passo** da auditoria web             |

> ✅ **Recomendação**: Sempre inicie com varredura passiva antes de considerar a varredura ativa.

### Varredura Ativa

A varredura ativa **envia requisições modificadas** ao alvo para testar vulnerabilidades de forma mais agressiva.

| Característica             | Descrição                                                    |
|-----------------------------|--------------------------------------------------------------|
| **Risco para o alvo**       | Médio a alto — pode causar instabilidade ou efeitos colaterais |
| **Velocidade**              | Lenta — envia milhares de requisições de teste              |
| **Detecções típicas**       | SQL Injection, XSS, CSRF, Path Traversal, Command Injection |
| **Autorização necessária**  | **Explícita e documentada** — requer autorização formal     |
| **Quando usar**             | Somente após autorização explícita do responsável           |

> ⚠️ **ATENÇÃO**: A varredura ativa **nunca** deve ser executada sem autorização formal e documentada do proprietário do sistema alvo.

---

## Modo Daemon para Automação

### Iniciar o ZAP em modo daemon

```bash
# Linux/macOS
zap.sh -daemon -port 8080 -config api.key=sua-chave-api-segura

# Windows
zap.exe -daemon -port 8080 -config api.key=sua-chave-api-segura

# Docker
docker run -d --name zap \
  -p 8080:8080 \
  zaproxy/zap-stable \
  zap.sh -daemon -host 0.0.0.0 -port 8080 \
  -config api.key=sua-chave-api-segura
```

### Verificar status do daemon

```bash
curl -s "http://localhost:8080/JSON/core/view/version/?apikey=sua-chave-api-segura"
```

---

## Uso da API REST

### Endpoints principais

| Operação                    | Método | Endpoint                                              |
|------------------------------|--------|-------------------------------------------------------|
| Versão                       | GET    | `/JSON/core/view/version/`                            |
| Abrir URL (spider)           | GET    | `/JSON/spider/action/scan/`                           |
| Status do spider             | GET    | `/JSON/spider/view/status/`                           |
| Varredura passiva — status   | GET    | `/JSON/pscan/view/recordsToScan/`                     |
| Varredura ativa — iniciar    | GET    | `/JSON/ascan/action/scan/`                            |
| Varredura ativa — status     | GET    | `/JSON/ascan/view/status/`                            |
| Listar alertas               | GET    | `/JSON/alert/view/alerts/`                            |
| Relatório HTML               | GET    | `/OTHER/core/other/htmlreport/`                       |
| Relatório JSON               | GET    | `/JSON/core/view/alerts/`                             |

### Exemplos de chamadas à API

**Iniciar spider (rastreamento):**
```bash
curl -s "http://localhost:8080/JSON/spider/action/scan/?apikey=sua-chave-api-segura&url=https://alvo.exemplo.com.br&maxChildren=10&recurse=true&subtreeOnly=true"
```

**Verificar progresso do spider:**
```bash
curl -s "http://localhost:8080/JSON/spider/view/status/?apikey=sua-chave-api-segura&scanId=0"
```

**Aguardar conclusão da varredura passiva:**
```bash
curl -s "http://localhost:8080/JSON/pscan/view/recordsToScan/?apikey=sua-chave-api-segura"
# Esperar até que retorne {"recordsToScan":"0"}
```

**Obter alertas:**
```bash
curl -s "http://localhost:8080/JSON/alert/view/alerts/?apikey=sua-chave-api-segura&baseurl=https://alvo.exemplo.com.br&start=0&count=100"
```

**Gerar relatório HTML:**
```bash
curl -s "http://localhost:8080/OTHER/core/other/htmlreport/?apikey=sua-chave-api-segura" > relatorio-zap.html
```

---

## Configuração de Restrições de Escopo

### Definir o contexto e escopo no ZAP

O escopo no ZAP define quais URLs podem ser rastreadas e testadas. **Sempre configure o escopo antes de qualquer varredura.**

**Criar um contexto:**
```bash
curl -s "http://localhost:8080/JSON/context/action/newContext/?apikey=sua-chave-api-segura&contextName=auditoria-2024"
```

**Incluir URLs no escopo:**
```bash
# Incluir domínio específico
curl -s "http://localhost:8080/JSON/context/action/includeInContext/?apikey=sua-chave-api-segura&contextName=auditoria-2024&regex=https://alvo\.exemplo\.com\.br.*"
```

**Excluir URLs do escopo:**
```bash
# Excluir endpoints de logout e administração
curl -s "http://localhost:8080/JSON/context/action/excludeFromContext/?apikey=sua-chave-api-segura&contextName=auditoria-2024&regex=.*logout.*"
curl -s "http://localhost:8080/JSON/context/action/excludeFromContext/?apikey=sua-chave-api-segura&contextName=auditoria-2024&regex=.*admin/delete.*"
```

### Restrições do Spider (rastreamento)

```bash
# Limitar profundidade de rastreamento
curl -s "http://localhost:8080/JSON/spider/action/setOptionMaxDepth/?apikey=sua-chave-api-segura&Integer=5"

# Limitar número de filhos por nó
curl -s "http://localhost:8080/JSON/spider/action/setOptionMaxChildren/?apikey=sua-chave-api-segura&Integer=10"

# Restringir ao subdomínio do alvo
curl -s "http://localhost:8080/JSON/spider/action/scan/?apikey=sua-chave-api-segura&url=https://alvo.exemplo.com.br&subtreeOnly=true"
```

---

## Configuração de Rate Limiting

Para evitar sobrecarregar o alvo durante a auditoria:

```bash
# Limitar requisições por segundo na varredura ativa
curl -s "http://localhost:8080/JSON/ascan/action/setOptionMaxRuleDurationInMins/?apikey=sua-chave-api-segura&Integer=5"

# Definir delay entre requisições (em milissegundos)
curl -s "http://localhost:8080/JSON/ascan/action/setOptionDelayInMs/?apikey=sua-chave-api-segura&Integer=200"

# Limitar threads da varredura ativa
curl -s "http://localhost:8080/JSON/ascan/action/setOptionThreadPerHost/?apikey=sua-chave-api-segura&Integer=2"
```

**Valores recomendados para auditoria:**

| Parâmetro              | Valor Recomendado | Descrição                              |
|-------------------------|-------------------|----------------------------------------|
| Delay entre requisições | 200–500 ms        | Evita sobrecarga do servidor           |
| Threads por host        | 1–2               | Minimiza impacto no desempenho         |
| Profundidade do spider  | 3–5               | Rastreamento controlado                |
| Max filhos por nó       | 10–20             | Limita a amplitude do rastreamento     |

---

## Interpretação dos Alertas

### Estrutura de um alerta ZAP

```json
{
  "alert": "Cross-Site Scripting (Reflected)",
  "risk": "High",
  "confidence": "Medium",
  "url": "https://alvo.exemplo.com.br/busca?q=teste",
  "param": "q",
  "attack": "<script>alert(1)</script>",
  "evidence": "<script>alert(1)</script>",
  "description": "Cross-site scripting (XSS) refletido encontrado...",
  "solution": "Validar e sanitizar todas as entradas do usuário...",
  "reference": "https://owasp.org/www-community/attacks/xss/",
  "cweid": "79",
  "wascid": "8",
  "pluginId": "40012"
}
```

### Níveis de Risco

| Risco ZAP         | Nível na Auditoria | Ação Recomendada                                  |
|---------------------|--------------------|----------------------------------------------------|
| `High` (3)          | **Crítico/Alto**   | Correção imediata obrigatória                     |
| `Medium` (2)        | **Médio**          | Correção recomendada antes do próximo release     |
| `Low` (1)           | **Baixo**          | Correção planejada, avaliar risco residual        |
| `Informational` (0) | **Informativo**    | Revisão e melhoria contínua                       |

### Níveis de Confiança

| Confiança ZAP  | Significado                                              |
|-----------------|----------------------------------------------------------|
| `Confirmed`     | Vulnerabilidade confirmada com evidência sólida          |
| `High`          | Alta probabilidade — evidência forte                     |
| `Medium`        | Probabilidade moderada — requer validação manual         |
| `Low`           | Baixa probabilidade — pode ser falso positivo            |
| `False Positive`| Marcado como falso positivo após revisão                 |

---

## Formatos de Saída e Parsing

### Relatório JSON

```bash
curl -s "http://localhost:8080/JSON/alert/view/alerts/?apikey=sua-chave-api-segura&baseurl=https://alvo.exemplo.com.br" > alertas-zap.json
```

**Parsing com Python:**
```python
import json

with open("alertas-zap.json", "r") as f:
    data = json.load(f)

for alerta in data.get("alerts", []):
    risco = alerta.get("risk", "Desconhecido")
    nome = alerta.get("alert", "Sem nome")
    url = alerta.get("url", "N/A")
    confianca = alerta.get("confidence", "N/A")
    print(f"[{risco}] {nome}")
    print(f"  URL: {url}")
    print(f"  Confiança: {confianca}")
    print()
```

### Relatório HTML

```bash
curl -s "http://localhost:8080/OTHER/core/other/htmlreport/?apikey=sua-chave-api-segura" > relatorio-zap.html
```

### Relatório XML

```bash
curl -s "http://localhost:8080/OTHER/core/other/xmlreport/?apikey=sua-chave-api-segura" > relatorio-zap.xml
```

### Relatório Markdown

```bash
curl -s "http://localhost:8080/OTHER/core/other/mdreport/?apikey=sua-chave-api-segura" > relatorio-zap.md
```

---

## Segurança e Boas Práticas

> ⚠️ **REGRAS DE SEGURANÇA OBRIGATÓRIAS** para uso do ZAP na auditoria.

### 1. Sempre comece com varredura passiva

A varredura passiva é segura e não envia requisições adicionais ao alvo. Use-a como ponto de partida para qualquer auditoria web.

### 2. Autorização explícita para varredura ativa

**Nunca** execute varredura ativa sem:
- Autorização formal e documentada do proprietário do sistema
- Escopo claramente definido e aprovado
- Janela de manutenção acordada (se necessário)
- Contato de emergência disponível para interrupção

### 3. Nunca escaneie fora do escopo

- Configure o contexto do ZAP **antes** de iniciar qualquer varredura.
- Utilize `subtreeOnly=true` no spider para restringir o rastreamento.
- Verifique as exclusões de escopo antes de iniciar.

### 4. Proteja a chave de API

- Use uma chave de API forte e única para cada auditoria.
- Nunca exponha a chave em logs ou relatórios.
- Restrinja o acesso à API por endereço IP quando possível.

### 5. Controle o rate limiting

- Sempre configure delays entre requisições.
- Monitore o impacto no desempenho do alvo.
- Esteja preparado para interromper a varredura a qualquer momento.

### 6. Documente tudo

Registre para cada varredura executada:
- Data, hora de início e término
- Versão do ZAP utilizada
- Configurações do contexto e escopo
- Tipo de varredura (passiva/ativa)
- Configurações de rate limiting aplicadas
- Número de alertas por nível de risco

---

## Fluxo de Trabalho Recomendado

```
1. Verificar instalação e versão do ZAP
   ↓
2. Iniciar ZAP em modo daemon
   ↓
3. Configurar contexto e escopo (incluir/excluir URLs)
   ↓
4. Configurar rate limiting e limites do spider
   ↓
5. Executar spider com restrição de escopo
   ↓
6. Aguardar conclusão da varredura passiva
   ↓
7. Coletar e analisar alertas da varredura passiva
   ↓
8. [Se autorizado] Executar varredura ativa com escopo restrito
   ↓
9. Coletar e consolidar todos os alertas
   ↓
10. Gerar relatório e incluir no documento de auditoria
   ↓
11. Encerrar o daemon ZAP e limpar dados temporários
```
