# Integração com Nmap

> **Requisito**: Esta integração requer que o [Nmap](https://nmap.org/) esteja instalado no sistema.

## Visão Geral

O Nmap (*Network Mapper*) é a ferramenta de código aberto mais utilizada para descoberta de rede e auditoria de segurança de infraestrutura. Ele permite identificar hosts ativos, portas abertas, serviços em execução e versões de software em alvos de rede.

### Por que usar o Nmap na auditoria de segurança?

- **Descoberta de rede**: Identificação de hosts ativos e topologia de rede.
- **Enumeração de portas**: Detecção de portas abertas, fechadas e filtradas.
- **Detecção de serviços**: Identificação de serviços em execução e suas versões.
- **Detecção de SO**: Identificação do sistema operacional (com autorização).
- **Scripts NSE**: Milhares de scripts para testes específicos de segurança.
- **Flexibilidade**: Múltiplos tipos de scan para diferentes cenários e níveis de autorização.

---

## Detecção e Verificação de Instalação

### Verificar se o Nmap está instalado

```bash
nmap --version
```

**Saída esperada** (exemplo):
```
Nmap version 7.94 ( https://nmap.org )
```

### Versão mínima suportada

| Requisito         | Valor     |
|--------------------|-----------|
| Versão mínima      | `7.80`    |
| Npcap (Windows)    | `1.70+`   |

### Instalação (referência rápida)

```bash
# Linux (Debian/Ubuntu)
sudo apt-get install nmap

# Linux (CentOS/RHEL)
sudo yum install nmap

# macOS (Homebrew)
brew install nmap

# Windows: baixar instalador em https://nmap.org/download.html
# Inclui Npcap para captura de pacotes
```

---

## ⚠️ Requisitos ESTRITOS de Escopo

> **ATENÇÃO MÁXIMA**: O uso do Nmap em redes sem autorização explícita é **ilegal** em muitas jurisdições e pode ser considerado crime cibernético.

### Antes de QUALQUER varredura, você DEVE:

1. **Ter autorização formal e documentada** do proprietário do sistema/rede alvo.
2. **Verificar o escopo autorizado** — IPs, ranges, domínios e portas permitidos.
3. **Confirmar restrições** — quais tipos de scan são permitidos.
4. **Ter um contato de emergência** — para interromper caso haja impacto.
5. **Documentar tudo** — cada varredura executada deve ser registrada.

### Checklist pré-varredura

```
□ Autorização formal obtida e arquivada
□ Escopo de IPs/domínios confirmado e documentado
□ Tipos de varredura permitidos definidos
□ Janela de tempo para varredura acordada
□ Contato de emergência disponível
□ Ferramenta de registro de logs ativa
```

---

## Tipos de Varredura Recomendados (Seguros)

### 1. TCP Connect Scan (`-sT`) — **Recomendado como padrão**

Varredura TCP completa, mais lenta porém mais segura e discreta.

```bash
nmap -sT -p 80,443,8080,8443 -T3 --reason -oX resultados.xml alvo.exemplo.com.br
```

| Característica        | Descrição                                           |
|------------------------|------------------------------------------------------|
| **Privilégios**        | Não requer root/admin                               |
| **Detecção**           | Facilmente detectada por IDS/IPS                    |
| **Impacto no alvo**    | Baixo — conexões TCP normais                        |
| **Uso recomendado**    | Varredura padrão de auditoria                       |

### 2. Detecção de Versão de Serviço (`-sV`)

Identifica serviços e suas versões nas portas abertas.

```bash
nmap -sT -sV --version-intensity 5 -p 22,80,443,3306,5432 -T3 -oX versoes.xml alvo.exemplo.com.br
```

| Parâmetro              | Descrição                                           |
|------------------------|------------------------------------------------------|
| `--version-intensity`  | 0-9, controla a profundidade da detecção (5 = padrão)|
| **Privilégios**        | Não requer root para `-sT -sV`                      |
| **Uso recomendado**    | Identificar software desatualizado                   |

### 3. Varredura de Portas Específicas

```bash
# Portas web comuns
nmap -sT -sV -p 80,443,8080,8443,8000,3000,5000 -T3 -oX web-ports.xml alvo.exemplo.com.br

# Portas de banco de dados
nmap -sT -sV -p 3306,5432,1433,27017,6379,5984 -T3 -oX db-ports.xml alvo.exemplo.com.br

# Portas de administração
nmap -sT -sV -p 22,3389,5900,5985,5986 -T3 -oX admin-ports.xml alvo.exemplo.com.br

# Portas de e-mail
nmap -sT -sV -p 25,465,587,993,995,143,110 -T3 -oX mail-ports.xml alvo.exemplo.com.br
```

### 4. Ping Sweep (Descoberta de Hosts)

```bash
# Descobrir hosts ativos em uma sub-rede (sem port scan)
nmap -sn -T3 -oX hosts-ativos.xml 192.168.1.0/24
```

---

## Configuração de Rate Limiting e Timing

### Templates de Timing

O Nmap oferece templates de timing de `-T0` (paranóico) a `-T5` (insano).

| Template | Nome       | Descrição                                    | Uso na Auditoria       |
|----------|------------|----------------------------------------------|------------------------|
| `-T0`    | Paranoid   | Extremamente lento, evita detecção por IDS   | Raramente necessário   |
| `-T1`    | Sneaky     | Muito lento, discreto                        | Redes sensíveis        |
| `-T2`    | Polite     | Lento, minimiza impacto na rede              | ✅ **Recomendado**     |
| `-T3`    | Normal     | Padrão do Nmap, equilíbrio                   | ✅ **Aceitável**       |
| `-T4`    | Aggressive | Rápido, pode sobrecarregar redes lentas      | ⚠️ Somente com aprovação |
| `-T5`    | Insane     | Muito agressivo, pode perder precisão        | 🚫 **PROIBIDO**        |

> 🚫 **PROIBIDO**: Nunca use `-T5` em auditorias. Pode causar negação de serviço e resultados imprecisos.

### Controle granular de timing

```bash
# Limitar taxa de pacotes por segundo
nmap -sT --max-rate 100 -p 1-1000 -T2 -oX resultados.xml alvo.exemplo.com.br

# Definir delay mínimo entre sondas
nmap -sT --scan-delay 200ms -p 80,443 -T2 -oX resultados.xml alvo.exemplo.com.br

# Limitar paralelismo
nmap -sT --max-parallelism 5 -p 80,443 -T2 -oX resultados.xml alvo.exemplo.com.br

# Timeout de host
nmap -sT --host-timeout 5m -p 80,443 -T2 -oX resultados.xml alvo.exemplo.com.br
```

---

## Restrições de Portas

### Boas práticas para especificação de portas

```bash
# ✅ CORRETO: Portas específicas e relevantes
nmap -sT -p 22,80,443,8080,3306 alvo.exemplo.com.br

# ✅ CORRETO: Top 100 portas mais comuns
nmap -sT --top-ports 100 alvo.exemplo.com.br

# ⚠️ COM CAUTELA: Range limitado (requer justificativa)
nmap -sT -p 1-1024 alvo.exemplo.com.br

# 🚫 EVITAR SEM AUTORIZAÇÃO EXPLÍCITA: Todas as portas
nmap -sT -p- alvo.exemplo.com.br
```

### Portas recomendadas por categoria

**Serviços Web:**
```
80, 443, 8080, 8443, 8000, 8888, 3000, 5000, 9090
```

**Banco de Dados:**
```
3306 (MySQL), 5432 (PostgreSQL), 1433 (MSSQL), 27017 (MongoDB), 6379 (Redis), 9200 (Elasticsearch)
```

**Acesso Remoto:**
```
22 (SSH), 3389 (RDP), 5900 (VNC), 5985/5986 (WinRM)
```

**Serviços de Rede:**
```
53 (DNS), 25/587 (SMTP), 110/995 (POP3), 143/993 (IMAP), 161 (SNMP)
```

---

## Formatos de Saída

### XML (`-oX`) — Recomendado para processamento

```bash
nmap -sT -sV -p 80,443 -T3 -oX resultados.xml alvo.exemplo.com.br
```

### Texto Normal (`-oN`) — Para leitura humana

```bash
nmap -sT -sV -p 80,443 -T3 -oN resultados.txt alvo.exemplo.com.br
```

### Grepable (`-oG`) — Para processamento com grep/awk

```bash
nmap -sT -sV -p 80,443 -T3 -oG resultados.gnmap alvo.exemplo.com.br
```

### Todos os formatos simultaneamente (`-oA`)

```bash
nmap -sT -sV -p 80,443 -T3 -oA resultados alvo.exemplo.com.br
# Gera: resultados.xml, resultados.nmap, resultados.gnmap
```

### Parsing do XML com Python

```python
import xml.etree.ElementTree as ET

tree = ET.parse("resultados.xml")
root = tree.getroot()

for host in root.findall("host"):
    # Obter endereço IP
    addr = host.find("address").get("addr")
    status = host.find("status").get("state")

    print(f"\nHost: {addr} ({status})")

    ports = host.find("ports")
    if ports is not None:
        for port in ports.findall("port"):
            portid = port.get("portid")
            protocol = port.get("protocol")
            state = port.find("state").get("state")

            service = port.find("service")
            svc_name = service.get("name", "desconhecido") if service is not None else "desconhecido"
            svc_version = service.get("version", "") if service is not None else ""

            print(f"  {portid}/{protocol} - {state} - {svc_name} {svc_version}")
```

### Parsing com PowerShell

```powershell
[xml]$nmap = Get-Content resultados.xml

foreach ($host in $nmap.nmaprun.host) {
    $addr = $host.address.addr
    $status = $host.status.state
    Write-Host "`nHost: $addr ($status)" -ForegroundColor Cyan

    foreach ($port in $host.ports.port) {
        $portid = $port.portid
        $protocol = $port.protocol
        $state = $port.state.state
        $service = $port.service.name
        $version = $port.service.version

        $color = if ($state -eq "open") { "Green" } elseif ($state -eq "filtered") { "Yellow" } else { "Red" }
        Write-Host "  $portid/$protocol - $state - $service $version" -ForegroundColor $color
    }
}
```

---

## Interpretação dos Resultados

### Estados de Portas

| Estado       | Descrição                                                        | Implicação de Segurança                      |
|--------------|------------------------------------------------------------------|----------------------------------------------|
| `open`       | Porta aceita conexões — serviço ativo                           | Possível superfície de ataque                |
| `closed`     | Porta acessível mas sem serviço escutando                       | Host ativo, porta não utilizada              |
| `filtered`   | Firewall/filtro impede a determinação do estado                 | Firewall ativo, boa prática                  |
| `unfiltered` | Porta acessível, mas não é possível determinar se open/closed   | Requer investigação adicional                |
| `open|filtered` | Não é possível determinar se open ou filtered                | Requer investigação adicional                |

### Razões (`--reason`)

Sempre use `--reason` para entender por que uma porta foi classificada de determinada forma:

```bash
nmap -sT --reason -p 80,443 alvo.exemplo.com.br
```

Saída exemplo:
```
PORT    STATE    SERVICE   REASON
80/tcp  open     http      syn-ack
443/tcp filtered https     no-response
```

---

## Documentação de Varreduras

### Requisito: documentar cada varredura

Cada varredura Nmap executada durante a auditoria **deve** ser documentada com as seguintes informações:

```markdown
### Registro de Varredura Nmap

| Campo                    | Valor                                          |
|---------------------------|-------------------------------------------------|
| Data/Hora                 | 2024-07-15 14:30:00 BRT                        |
| Analista                  | [Nome do Analista]                              |
| Alvo(s)                   | 192.168.1.100, 192.168.1.101                   |
| Portas                    | 22, 80, 443, 3306, 5432                        |
| Tipo de Scan              | TCP Connect (-sT) + Version Detection (-sV)    |
| Template de Timing        | -T3 (Normal)                                    |
| Comando Completo          | `nmap -sT -sV -p 22,80,443,3306,5432 -T3 ...` |
| Autorização               | Documento ABC-2024-001, assinado em 01/07/2024 |
| Arquivo de Resultados     | scan-001-resultados.xml                        |
| Portas Abertas Encontradas| 22/tcp (SSH), 80/tcp (HTTP), 443/tcp (HTTPS)   |
| Observações               | Sem impacto observado no alvo                  |
```

---

## Restrições de Timing e Performance

### Configurações recomendadas para auditoria

```bash
# Configuração conservadora (redes de produção)
nmap -sT -sV \
  -T2 \
  --max-rate 50 \
  --max-parallelism 3 \
  --scan-delay 500ms \
  --host-timeout 10m \
  -p 22,80,443,8080 \
  -oA scan-conservador \
  alvo.exemplo.com.br

# Configuração moderada (ambientes de teste)
nmap -sT -sV \
  -T3 \
  --max-rate 200 \
  --max-parallelism 10 \
  -p 1-1024 \
  -oA scan-moderado \
  alvo.exemplo.com.br
```

---

## Segurança e Regras Obrigatórias

> 🚫 **PROIBIÇÕES ABSOLUTAS** — Violações podem ter consequências legais.

### NUNCA faça:

| Ação Proibida                                  | Razão                                            |
|-------------------------------------------------|--------------------------------------------------|
| Escanear alvos não autorizados                  | Ilegal — pode ser considerado crime cibernético  |
| Usar `-T5` (Insane timing)                      | Pode causar negação de serviço                   |
| Usar `--script` com scripts de exploit          | Extrapola o escopo de reconhecimento             |
| OS fingerprinting (`-O`) sem autorização        | Pode gerar tráfego suspeito e alertas            |
| Scan completo de portas (`-p-`) sem autorização | Pode sobrecarregar o alvo e gerar alertas        |
| Escanear durante horários não acordados         | Pode impactar operações                          |
| Escanear redes de terceiros                     | Ilegal sem autorização explícita                 |

### Scripts NSE — Restrições

```bash
# ✅ PERMITIDO: Scripts seguros de enumeração
nmap -sT -sV --script=banner -p 80,443 -T3 alvo.exemplo.com.br
nmap -sT -sV --script=http-headers -p 80,443 -T3 alvo.exemplo.com.br
nmap -sT -sV --script=ssl-enum-ciphers -p 443 -T3 alvo.exemplo.com.br

# ⚠️ COM AUTORIZAÇÃO EXPLÍCITA: Scripts de detecção de vulnerabilidades
nmap -sT -sV --script=vuln -p 80,443 -T3 alvo.exemplo.com.br

# 🚫 PROIBIDO: Scripts de exploit
# nmap --script=exploit -p 80 alvo.exemplo.com.br  ← NUNCA USAR
# nmap --script=brute -p 22 alvo.exemplo.com.br    ← NUNCA USAR
```

### Sempre verifique o escopo primeiro

```bash
# ANTES de qualquer scan, confirme que o alvo está no escopo
# Verifique o documento de escopo da auditoria
# Confirme IP/domínio, portas e tipos de scan autorizados
# Somente então execute a varredura
```

---

## Fluxo de Trabalho Recomendado

```
1. Verificar instalação e versão do Nmap
   ↓
2. OBRIGATÓRIO: Verificar autorização formal e escopo documentado
   ↓
3. Confirmar alvos (IPs/domínios), portas e tipos de scan permitidos
   ↓
4. Verificar janela de tempo acordada para varredura
   ↓
5. Configurar timing conservador (-T2 ou -T3)
   ↓
6. Executar descoberta de hosts (-sn) se autorizado
   ↓
7. Executar varredura TCP Connect (-sT) nas portas autorizadas
   ↓
8. Executar detecção de versão (-sV) nas portas abertas
   ↓
9. [Se autorizado] Executar scripts NSE seguros de enumeração
   ↓
10. Documentar cada varredura com registro completo
   ↓
11. Exportar resultados em XML para processamento
   ↓
12. Analisar resultados: portas abertas, serviços, versões
   ↓
13. Correlacionar com vulnerabilidades conhecidas (usar Trivy/Semgrep)
   ↓
14. Incluir achados no relatório de auditoria
```
