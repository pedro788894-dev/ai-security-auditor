# Integração com Trivy

> **Requisito**: Esta integração requer que o [Trivy](https://trivy.dev/) esteja instalado no sistema.

## Visão Geral

O Trivy é um scanner de segurança abrangente e versátil, desenvolvido pela Aqua Security. Ele detecta vulnerabilidades, configurações incorretas e segredos expostos em múltiplos tipos de alvos, incluindo imagens de contêiner, sistemas de arquivos, repositórios Git e arquivos de Infraestrutura como Código (IaC).

### Por que usar o Trivy na auditoria de segurança?

- **Multi-alvo**: Escaneia contêineres, código-fonte, IaC e repositórios Git com uma única ferramenta.
- **Banco de dados de vulnerabilidades abrangente**: Utiliza múltiplas fontes (NVD, GitHub Advisory, Red Hat, Ubuntu, Alpine, etc.).
- **Detecção de misconfiguration**: Analisa Dockerfiles, Kubernetes manifests, Terraform, CloudFormation.
- **Detecção de segredos**: Identifica chaves, senhas e tokens expostos.
- **Sem agente**: Execução local, sem necessidade de infraestrutura adicional.
- **Integração nativa com CI/CD**: Suporte a múltiplos formatos de saída para pipelines.

---

## Detecção e Verificação de Instalação

### Verificar se o Trivy está instalado

```bash
trivy --version
```

**Saída esperada** (exemplo):
```
Version: 0.52.0
```

### Versão mínima suportada

| Requisito         | Valor     |
|--------------------|-----------|
| Versão mínima      | `0.45.0`  |

### Instalação (referência rápida)

```bash
# Via script de instalação (Linux/macOS)
curl -sfL https://raw.githubusercontent.com/aquasecurity/trivy/main/contrib/install.sh | sh -s -- -b /usr/local/bin

# Via Homebrew (macOS)
brew install trivy

# Via apt (Debian/Ubuntu)
sudo apt-get install trivy

# Via Chocolatey (Windows)
choco install trivy

# Via Docker
docker pull aquasec/trivy
```

---

## Modos de Varredura

O Trivy suporta diversos modos de varredura, cada um otimizado para um tipo específico de alvo.

### 1. Varredura de Sistema de Arquivos (`fs`)

Escaneia diretórios locais em busca de vulnerabilidades em dependências e segredos expostos.

```bash
# Varredura básica de diretório
trivy fs --severity HIGH,CRITICAL --format json --output fs-results.json /caminho/do/projeto

# Varredura com detecção de segredos
trivy fs --scanners vuln,secret --format json --output fs-results.json /caminho/do/projeto

# Varredura apenas de vulnerabilidades em dependências
trivy fs --scanners vuln --severity CRITICAL --format json --output vuln-results.json /caminho/do/projeto
```

**Casos de uso:**
- Auditar dependências de um projeto (package.json, requirements.txt, go.mod, pom.xml, etc.)
- Detectar segredos hardcoded em arquivos de código-fonte
- Verificar vulnerabilidades conhecidas (CVEs) em bibliotecas utilizadas

### 2. Varredura de Imagem de Contêiner (`image`)

Escaneia imagens Docker em busca de vulnerabilidades no SO base e em pacotes instalados.

```bash
# Varredura de imagem local
trivy image --severity HIGH,CRITICAL --format json --output image-results.json minha-app:latest

# Varredura de imagem de registro remoto
trivy image --severity HIGH,CRITICAL --format json --output image-results.json registry.exemplo.com.br/app:v1.2.3

# Varredura com informações de versão fixa disponível
trivy image --ignore-unfixed --format json --output image-results.json minha-app:latest

# Varredura incluindo segredos na imagem
trivy image --scanners vuln,secret --format json --output image-results.json minha-app:latest
```

**Casos de uso:**
- Auditar segurança de imagens Docker antes de deploy em produção
- Verificar se a imagem base contém vulnerabilidades conhecidas
- Validar conformidade com políticas de segurança corporativas

### 3. Varredura de Configuração / IaC (`config`)

Analisa arquivos de Infraestrutura como Código em busca de configurações incorretas ou inseguras.

```bash
# Varredura de Dockerfiles
trivy config --severity HIGH,CRITICAL --format json --output config-results.json /caminho/do/projeto

# Varredura de manifestos Kubernetes
trivy config --severity MEDIUM,HIGH,CRITICAL --format json --output k8s-results.json /caminho/dos/manifests

# Varredura de Terraform
trivy config --format json --output terraform-results.json /caminho/do/terraform

# Tipos específicos de IaC
trivy config --misconfig-scanners terraform --format json --output tf-results.json /caminho/do/terraform
```

**Tipos de IaC suportados:**
- Dockerfile
- Kubernetes manifests (YAML)
- Terraform (HCL)
- CloudFormation (JSON/YAML)
- Helm Charts
- Azure ARM Templates

### 4. Varredura de Repositório Git (`repo`)

Escaneia repositórios Git remotos diretamente, sem necessidade de clone manual.

```bash
# Varredura de repositório público
trivy repo --severity HIGH,CRITICAL --format json --output repo-results.json https://github.com/exemplo/projeto

# Varredura de branch específica
trivy repo --branch develop --format json --output repo-results.json https://github.com/exemplo/projeto

# Varredura com tag específica
trivy repo --tag v1.0.0 --format json --output repo-results.json https://github.com/exemplo/projeto
```

**Casos de uso:**
- Auditar repositórios de terceiros antes de integrá-los
- Verificar vulnerabilidades em branches específicas
- Varredura rápida sem necessidade de clonar o repositório

---

## Opções de Filtragem por Severidade

O Trivy classifica vulnerabilidades em cinco níveis de severidade:

| Severidade   | Descrição                                                    | CVSS Score   |
|--------------|--------------------------------------------------------------|--------------|
| `CRITICAL`   | Vulnerabilidade crítica com exploração conhecida ou trivial  | 9.0–10.0     |
| `HIGH`       | Vulnerabilidade de alto risco, exploração provável           | 7.0–8.9      |
| `MEDIUM`     | Vulnerabilidade de risco moderado                            | 4.0–6.9      |
| `LOW`        | Vulnerabilidade de baixo risco                               | 0.1–3.9      |
| `UNKNOWN`    | Severidade não determinada                                   | N/A          |

### Filtrar por severidade

```bash
# Somente críticas
trivy fs --severity CRITICAL /caminho/do/projeto

# Altas e críticas
trivy fs --severity HIGH,CRITICAL /caminho/do/projeto

# Todas exceto informativas
trivy fs --severity LOW,MEDIUM,HIGH,CRITICAL /caminho/do/projeto
```

### Ignorar vulnerabilidades sem correção disponível

```bash
trivy fs --ignore-unfixed --severity HIGH,CRITICAL /caminho/do/projeto
```

### Ignorar vulnerabilidades específicas

Crie um arquivo `.trivyignore`:

```text
# Falso positivo confirmado em 2024-01-15
CVE-2023-12345

# Vulnerabilidade sem impacto neste contexto (documentar justificativa)
CVE-2023-67890

# Aceitar risco temporariamente até próximo sprint
CVE-2024-11111
```

```bash
trivy fs --ignorefile .trivyignore --severity HIGH,CRITICAL /caminho/do/projeto
```

---

## Formatos de Saída

### Tabela (padrão — leitura humana)

```bash
trivy fs --format table /caminho/do/projeto
```

**Saída exemplo:**
```
library/alpine (alpine 3.18.4)
Total: 2 (HIGH: 1, CRITICAL: 1)

┌──────────────┬────────────────┬──────────┬────────────────┬───────────────┬─────────────────────────────────────┐
│   Library    │ Vulnerability  │ Severity │ Installed Ver  │  Fixed Ver    │               Title                 │
├──────────────┼────────────────┼──────────┼────────────────┼───────────────┼─────────────────────────────────────┤
│ libcrypto3   │ CVE-2024-0727  │ HIGH     │ 3.1.4-r1       │ 3.1.4-r3      │ openssl: denial of service...       │
│ libssl3      │ CVE-2024-0727  │ HIGH     │ 3.1.4-r1       │ 3.1.4-r3      │ openssl: denial of service...       │
└──────────────┴────────────────┴──────────┴────────────────┴───────────────┴─────────────────────────────────────┘
```

### JSON (recomendado para processamento automatizado)

```bash
trivy fs --format json --output results.json /caminho/do/projeto
```

**Parsing com Python:**
```python
import json

with open("results.json", "r") as f:
    data = json.load(f)

for result in data.get("Results", []):
    target = result.get("Target", "Desconhecido")
    vulns = result.get("Vulnerabilities", [])
    if vulns:
        print(f"\n=== {target} ===")
        for vuln in vulns:
            cve = vuln.get("VulnerabilityID", "N/A")
            sev = vuln.get("Severity", "UNKNOWN")
            pkg = vuln.get("PkgName", "N/A")
            installed = vuln.get("InstalledVersion", "N/A")
            fixed = vuln.get("FixedVersion", "Sem correção")
            title = vuln.get("Title", "Sem título")
            print(f"  [{sev}] {cve} - {pkg} {installed} -> {fixed}")
            print(f"    {title}")
```

**Parsing com PowerShell:**
```powershell
$data = Get-Content -Raw results.json | ConvertFrom-Json
foreach ($result in $data.Results) {
    if ($result.Vulnerabilities) {
        Write-Host "`n=== $($result.Target) ===" -ForegroundColor Cyan
        foreach ($vuln in $result.Vulnerabilities) {
            $color = switch ($vuln.Severity) {
                "CRITICAL" { "Red" }
                "HIGH" { "Yellow" }
                "MEDIUM" { "DarkYellow" }
                default { "White" }
            }
            Write-Host "  [$($vuln.Severity)] $($vuln.VulnerabilityID) - $($vuln.PkgName)" -ForegroundColor $color
        }
    }
}
```

### SARIF (para integração com GitHub/GitLab)

```bash
trivy fs --format sarif --output results.sarif /caminho/do/projeto
```

---

## Interpretação dos Resultados

### Estrutura de uma vulnerabilidade

```json
{
  "VulnerabilityID": "CVE-2024-0727",
  "PkgID": "libcrypto3@3.1.4-r1",
  "PkgName": "libcrypto3",
  "PkgIdentifier": {
    "PURL": "pkg:apk/alpine/libcrypto3@3.1.4-r1"
  },
  "InstalledVersion": "3.1.4-r1",
  "FixedVersion": "3.1.4-r3",
  "Status": "fixed",
  "Severity": "HIGH",
  "Title": "openssl: denial of service via null dereference",
  "Description": "Processamento de PKCS12 com campos malformados pode causar crash...",
  "PrimaryURL": "https://avd.aquasec.com/nvd/cve-2024-0727",
  "References": [
    "https://nvd.nist.gov/vuln/detail/CVE-2024-0727",
    "https://www.openssl.org/news/secadv/20240125.txt"
  ],
  "CVSS": {
    "nvd": {
      "V3Score": 7.5,
      "V3Vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:H"
    }
  },
  "CweIDs": ["CWE-476"],
  "PublishedDate": "2024-01-26T09:15:00Z",
  "LastModifiedDate": "2024-01-31T15:15:00Z"
}
```

### Campos importantes para auditoria

| Campo               | Descrição                                                    |
|-----------------------|--------------------------------------------------------------|
| `VulnerabilityID`    | Identificador CVE da vulnerabilidade                        |
| `PkgName`            | Nome do pacote afetado                                      |
| `InstalledVersion`   | Versão instalada (vulnerável)                               |
| `FixedVersion`       | Versão com a correção disponível                            |
| `Status`             | `fixed` (correção disponível) ou `affected` (sem correção)  |
| `Severity`           | Nível de severidade (CRITICAL, HIGH, MEDIUM, LOW)           |
| `CVSS.V3Score`       | Pontuação CVSS v3 (0.0 a 10.0)                             |
| `CweIDs`             | Classificações CWE relacionadas                             |
| `PrimaryURL`         | Link para detalhes da vulnerabilidade                       |

---

## Integração com CI/CD

### GitHub Actions

```yaml
name: Trivy Security Scan
on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  trivy-scan:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Trivy FS Scan
        uses: aquasecurity/trivy-action@master
        with:
          scan-type: 'fs'
          scan-ref: '.'
          severity: 'HIGH,CRITICAL'
          format: 'sarif'
          output: 'trivy-results.sarif'

      - name: Upload SARIF
        uses: github/codeql-action/upload-sarif@v3
        with:
          sarif_file: 'trivy-results.sarif'
```

### GitLab CI

```yaml
trivy-scan:
  stage: security
  image:
    name: aquasec/trivy
    entrypoint: [""]
  script:
    - trivy fs --severity HIGH,CRITICAL --format json --output trivy-results.json .
  artifacts:
    paths:
      - trivy-results.json
    when: always
```

### Azure DevOps

```yaml
- task: CmdLine@2
  displayName: 'Trivy Scan'
  inputs:
    script: |
      trivy fs --severity HIGH,CRITICAL --format json --output $(Build.ArtifactStagingDirectory)/trivy-results.json .

- task: PublishBuildArtifacts@1
  inputs:
    PathtoPublish: '$(Build.ArtifactStagingDirectory)/trivy-results.json'
    ArtifactName: 'SecurityScanResults'
```

---

## Limitações

| Limitação                              | Descrição                                                              |
|-----------------------------------------|------------------------------------------------------------------------|
| Varredura estática apenas               | Não testa vulnerabilidades em tempo de execução                       |
| Dependente do banco de dados            | Requer atualização do banco de dados de vulnerabilidades              |
| Sem análise de código customizado       | Foca em dependências e configurações, não em código proprietário      |
| Falsos positivos em detecção de segredos| Padrões genéricos podem gerar alertas para valores não sensíveis      |
| Imagens distroless                      | Cobertura limitada para imagens sem gerenciador de pacotes            |
| Vulnerabilidades zero-day               | Não detecta vulnerabilidades que ainda não possuem CVE atribuído      |

---

## Segurança e Boas Práticas

> ⚠️ **REGRAS DE SEGURANÇA** para uso do Trivy na auditoria.

1. **Varredura somente local**: O Trivy opera exclusivamente em modo de varredura local. Ele **não** executa exploits, não acessa redes remotas (exceto para baixar o banco de dados de vulnerabilidades) e não modifica os alvos analisados.

2. **Sem exploração de rede**: Diferentemente de ferramentas como Nmap ou ZAP, o Trivy não realiza testes ativos contra serviços em execução. Sua análise é baseada em comparação com bancos de dados de vulnerabilidades conhecidas.

3. **Proteja os resultados**: Os relatórios do Trivy podem conter informações sobre versões específicas de software e suas vulnerabilidades. Armazene-os de forma segura.

4. **Atualize o banco de dados**: Antes de cada auditoria, atualize o banco de dados de vulnerabilidades:
   ```bash
   trivy image --download-db-only
   ```

5. **Escopo restrito**: Escaneie apenas diretórios, imagens e repositórios autorizados no escopo da auditoria.

6. **Documente tudo**: Registre cada varredura executada, incluindo:
   - Data e hora
   - Versão do Trivy e do banco de dados utilizado
   - Modo de varredura utilizado
   - Alvos escaneados
   - Filtros de severidade aplicados
   - Número de vulnerabilidades por severidade

---

## Fluxo de Trabalho Recomendado

```
1. Verificar instalação e versão do Trivy
   ↓
2. Atualizar banco de dados de vulnerabilidades
   ↓
3. Confirmar escopo autorizado da auditoria
   ↓
4. Executar varredura de sistema de arquivos (dependências + segredos)
   ↓
5. Executar varredura de imagens de contêiner (se aplicável)
   ↓
6. Executar varredura de configuração/IaC (se aplicável)
   ↓
7. Consolidar resultados em JSON
   ↓
8. Filtrar por severidade e status de correção
   ↓
9. Validar achados e documentar falsos positivos
   ↓
10. Incluir achados confirmados no relatório de auditoria
```
