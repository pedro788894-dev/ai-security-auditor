# Integração com Semgrep

> **Requisito**: Esta integração requer que o [Semgrep](https://semgrep.dev/) esteja instalado no sistema.

## Visão Geral

O Semgrep é uma ferramenta de análise estática de código (SAST — *Static Application Security Testing*) que identifica vulnerabilidades, bugs e padrões de código inseguro em diversas linguagens de programação. Ele utiliza regras baseadas em padrões semânticos, o que o torna mais preciso que ferramentas baseadas em regex simples.

### Por que usar o Semgrep na auditoria de segurança?

- **Análise multi-linguagem**: Suporte a Python, JavaScript, TypeScript, Java, Go, Ruby, C, C++, PHP, entre outras.
- **Regras comunitárias e curadas**: Milhares de regras mantidas pela comunidade e pela equipe do Semgrep.
- **Baixa taxa de falsos positivos**: Análise semântica em vez de simples correspondência textual.
- **Execução local**: Todo o processamento ocorre localmente, sem envio de código para servidores externos.
- **Integração com CI/CD**: Fácil de integrar em pipelines de integração contínua.

---

## Detecção e Verificação de Instalação

### Verificar se o Semgrep está instalado

```bash
semgrep --version
```

**Saída esperada** (exemplo):
```
1.67.0
```

### Versão mínima suportada

| Requisito         | Valor     |
|--------------------|-----------|
| Versão mínima      | `1.50.0`  |
| Python (se via pip) | `>= 3.8`  |

### Instalação (referência rápida)

```bash
# Via pip (recomendado)
pip install semgrep

# Via Homebrew (macOS)
brew install semgrep

# Via Docker
docker run --rm -v "${PWD}:/src" returntocorp/semgrep semgrep --config=auto /src
```

---

## Conjuntos de Regras Recomendados

Para auditoria de segurança, os seguintes conjuntos de regras (*rulesets*) são recomendados:

| Conjunto de Regras    | Descrição                                                  | Uso Recomendado                     |
|------------------------|-------------------------------------------------------------|--------------------------------------|
| `p/security-audit`     | Regras abrangentes de auditoria de segurança               | Auditoria geral de código           |
| `p/owasp-top-ten`      | Regras baseadas no OWASP Top 10                            | Conformidade com padrões OWASP      |
| `p/secrets`            | Detecção de segredos hardcoded (chaves API, senhas, tokens)| Verificação de credenciais expostas |
| `p/ci`                 | Regras otimizadas para CI/CD com alta confiança            | Pipelines automatizados             |
| `p/default`            | Conjunto padrão balanceado                                 | Verificação rápida inicial          |
| `p/sql-injection`      | Detecção específica de injeção SQL                         | Aplicações com banco de dados       |
| `p/xss`                | Detecção de Cross-Site Scripting                           | Aplicações web                      |

### Combinando múltiplos conjuntos de regras

```bash
semgrep scan \
  --config=p/security-audit \
  --config=p/owasp-top-ten \
  --config=p/secrets \
  --json \
  --output=results.json \
  <diretorio_alvo>
```

---

## Exemplos de Comandos

### Varredura básica com configuração automática

```bash
semgrep scan --config=auto --json --output=results.json <diretorio_alvo>
```

### Varredura com conjunto de regras específico

```bash
semgrep scan --config=p/security-audit --json --output=security-results.json <diretorio_alvo>
```

### Varredura com múltiplas configurações e severidade mínima

```bash
semgrep scan \
  --config=p/owasp-top-ten \
  --config=p/secrets \
  --severity=WARNING \
  --json \
  --output=results.json \
  <diretorio_alvo>
```

### Varredura de arquivos específicos

```bash
semgrep scan \
  --config=p/security-audit \
  --include="*.py" \
  --include="*.js" \
  --json \
  --output=results.json \
  <diretorio_alvo>
```

### Varredura excluindo diretórios

```bash
semgrep scan \
  --config=auto \
  --exclude="node_modules" \
  --exclude="vendor" \
  --exclude="*.test.js" \
  --json \
  --output=results.json \
  <diretorio_alvo>
```

### Varredura com saída SARIF (para integração com GitHub/GitLab)

```bash
semgrep scan \
  --config=p/security-audit \
  --sarif \
  --output=results.sarif \
  <diretorio_alvo>
```

### Varredura somente de diferenças (baseline)

```bash
semgrep scan \
  --config=auto \
  --baseline-commit=main \
  --json \
  --output=diff-results.json \
  <diretorio_alvo>
```

---

## Restrições de Escopo

Sempre respeite os limites do escopo definido na auditoria:

- **Nunca** escaneie diretórios fora do escopo autorizado.
- Utilize `--include` e `--exclude` para restringir os alvos da varredura.
- Documente todos os caminhos escaneados no relatório.

```bash
# Exemplo: restringir a varredura apenas ao diretório src/
semgrep scan --config=auto --json --output=results.json ./src/
```

---

## Interpretação dos Resultados

### Estrutura do resultado JSON

Cada achado (*finding*) no JSON contém:

```json
{
  "results": [
    {
      "check_id": "python.lang.security.audit.dangerous-system-call",
      "path": "app/utils.py",
      "start": { "line": 42, "col": 5 },
      "end": { "line": 42, "col": 35 },
      "extra": {
        "message": "Chamada perigosa ao sistema detectada. Considere usar subprocess com shell=False.",
        "severity": "WARNING",
        "metadata": {
          "confidence": "HIGH",
          "impact": "HIGH",
          "likelihood": "MEDIUM",
          "category": "security",
          "cwe": ["CWE-78"],
          "owasp": ["A03:2021 - Injection"],
          "references": ["https://cwe.mitre.org/data/definitions/78.html"]
        },
        "lines": "os.system(user_input)"
      }
    }
  ],
  "errors": [],
  "stats": {
    "findings": 1,
    "errors": 0,
    "total_time": 2.5
  }
}
```

### Mapeamento de Severidade

| Severidade Semgrep | Nível de Risco na Auditoria | Ação Recomendada                          |
|---------------------|-----------------------------|-------------------------------------------|
| `ERROR`             | **Crítico / Alto**          | Correção imediata obrigatória             |
| `WARNING`           | **Médio**                   | Correção recomendada, avaliar contexto    |
| `INFO`              | **Baixo / Informativo**     | Revisão manual, pode ser falso positivo   |

### Níveis de Confiança

| Confiança Semgrep | Significado                                                    |
|--------------------|----------------------------------------------------------------|
| `HIGH`             | Alta probabilidade de ser uma vulnerabilidade real             |
| `MEDIUM`           | Provável vulnerabilidade, requer validação manual              |
| `LOW`              | Possível vulnerabilidade, alta chance de falso positivo        |

---

## Formatos de Saída

### JSON (recomendado para processamento automatizado)

```bash
semgrep scan --config=auto --json --output=results.json <alvo>
```

**Parsing com Python:**

```python
import json

with open("results.json", "r") as f:
    data = json.load(f)

for finding in data.get("results", []):
    print(f"[{finding['extra']['severity']}] {finding['check_id']}")
    print(f"  Arquivo: {finding['path']}:{finding['start']['line']}")
    print(f"  Mensagem: {finding['extra']['message']}")
    print()
```

**Parsing com PowerShell:**

```powershell
$results = Get-Content -Raw results.json | ConvertFrom-Json
foreach ($finding in $results.results) {
    Write-Host "[$($finding.extra.severity)] $($finding.check_id)"
    Write-Host "  Arquivo: $($finding.path):$($finding.start.line)"
    Write-Host "  Mensagem: $($finding.extra.message)"
    Write-Host ""
}
```

### SARIF (para integração com plataformas de código)

```bash
semgrep scan --config=auto --sarif --output=results.sarif <alvo>
```

O formato SARIF (*Static Analysis Results Interchange Format*) é suportado nativamente por GitHub Code Scanning, GitLab SAST e Azure DevOps.

### Texto (para leitura humana)

```bash
semgrep scan --config=auto --text <alvo>
```

---

## Tratamento de Falsos Positivos

### Inline (no código-fonte)

```python
# Supressão de regra específica
x = eval(safe_input)  # nosemgrep: python.lang.security.audit.eval-detected
```

### Via arquivo de configuração `.semgrepignore`

```text
# Diretórios de teste
tests/
test_*.py

# Arquivos gerados automaticamente
generated/
*.generated.js

# Dependências de terceiros
vendor/
node_modules/
```

### Documentação de falsos positivos

Ao identificar um falso positivo, documente:

1. **Regra**: ID da regra que disparou o alerta
2. **Arquivo e linha**: Localização do achado
3. **Justificativa**: Por que é um falso positivo
4. **Responsável pela validação**: Quem confirmou que é falso positivo
5. **Data da validação**: Quando foi revisado

---

## Limitações

| Limitação                         | Descrição                                                                   |
|------------------------------------|-----------------------------------------------------------------------------|
| Análise estática apenas            | Não detecta vulnerabilidades em tempo de execução                          |
| Sem análise de fluxo inter-procedural completa | Fluxos complexos entre funções podem não ser rastreados completamente |
| Dependências externas              | Não analisa vulnerabilidades em bibliotecas importadas (use Trivy para isso)|
| Código ofuscado                    | Código minificado ou ofuscado pode não ser analisado corretamente          |
| Configurações de infraestrutura    | Limitado na análise de IaC (use Trivy ou ferramentas especializadas)       |
| Lógica de negócio                  | Não detecta falhas de lógica de negócio                                    |

---

## Segurança e Boas Práticas

> ⚠️ **IMPORTANTE**: Regras de segurança para uso do Semgrep na auditoria.

1. **Nunca utilize auto-fix automaticamente**: O Semgrep oferece correção automática (`--autofix`), mas **nunca** aplique correções automaticamente durante uma auditoria. As correções devem ser revisadas e aplicadas manualmente pela equipe de desenvolvimento.

2. **Nunca escaneie fora do escopo**: Limite a varredura exclusivamente aos diretórios e repositórios autorizados no documento de escopo.

3. **Não envie código para servidores externos**: Use o modo local do Semgrep. Se utilizar `semgrep login`, esteja ciente de que métricas podem ser enviadas. Para auditoria sensível, desabilite telemetria:
   ```bash
   semgrep scan --config=auto --metrics=off --json --output=results.json <alvo>
   ```

4. **Proteja os resultados**: Os resultados da varredura podem conter trechos de código sensível. Armazene-os de forma segura e inclua-os apenas em relatórios classificados adequadamente.

5. **Documente tudo**: Registre cada varredura executada, incluindo:
   - Data e hora
   - Versão do Semgrep utilizada
   - Conjuntos de regras aplicados
   - Diretórios/arquivos escaneados
   - Número de achados por severidade

---

## Fluxo de Trabalho Recomendado

```
1. Verificar instalação e versão do Semgrep
   ↓
2. Confirmar escopo autorizado da auditoria
   ↓
3. Executar varredura inicial com --config=auto
   ↓
4. Executar varreduras direcionadas (p/owasp-top-ten, p/secrets)
   ↓
5. Coletar e consolidar resultados em JSON
   ↓
6. Filtrar e triar achados por severidade e confiança
   ↓
7. Validar manualmente achados de alta severidade
   ↓
8. Documentar falsos positivos com justificativa
   ↓
9. Incluir achados confirmados no relatório de auditoria
```
