# Política de Segurança

## Reportando Vulnerabilidades

Se você descobrir uma vulnerabilidade de segurança neste projeto, por favor:

1. **NÃO** abra uma issue pública.
2. Envie um e-mail para o mantenedor do projeto com:
   - Descrição da vulnerabilidade
   - Passos para reprodução
   - Impacto potencial
   - Sugestão de correção (se houver)

## Escopo da Política

Esta política cobre o código-fonte, scripts, schemas e documentação do projeto **AI Security Auditor**.

Esta política **NÃO** cobre:
- Vulnerabilidades encontradas por meio do uso da skill (essas devem ser reportadas ao responsável pelo sistema auditado)
- Vulnerabilidades em ferramentas de terceiros integradas (Semgrep, ZAP, Trivy, Gitleaks, Nmap)

## Práticas de Segurança do Projeto

### O que este projeto faz

- Fornece instruções e referências para auditoria defensiva
- Valida documentos de escopo e relatórios
- Detecta potenciais segredos em relatórios antes da distribuição
- Opera em modo somente leitura por padrão
- Exige autorização explícita para testes ativos

### O que este projeto NÃO faz

- Não armazena credenciais ou segredos
- Não realiza conexões de rede por conta própria
- Não executa exploits ou ataques
- Não instala software sem autorização
- Não acessa dados de produção sem autorização explícita

## Arquivos Sensíveis

Os seguintes tipos de arquivo **NUNCA** devem ser incluídos no repositório:

- Credenciais reais (senhas, tokens, chaves de API)
- Relatórios de auditoria com dados não sanitizados
- Escopos de auditoria com dados de clientes reais
- Certificados ou chaves privadas
- Dumps de banco de dados
- Logs com informações pessoais identificáveis

O arquivo `.gitignore` inclui padrões para prevenir a inclusão acidental desses arquivos.

## Versões Suportadas

| Versão | Suporte de Segurança |
|--------|---------------------|
| 1.0.x  | ✅ Ativo            |

## Atualizações

Correções de segurança serão disponibilizadas como patch releases (ex: 1.0.1) e documentadas no `CHANGELOG.md`.
