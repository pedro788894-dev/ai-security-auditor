# AI Security Auditor

Skill de auditoria de segurança para agentes de IA — compatível com Google Antigravity, Cursor e Claude Code.

## Índice

- [Objetivo](#objetivo)
- [Capacidades](#capacidades)
- [Limitações](#limitações)
- [Pré-requisitos](#pré-requisitos)
- [Execução com Docker (Qualquer SO)](#execução-com-docker-qualquer-so)
- [Estrutura do Projeto](#estrutura-do-projeto)
- [Instalação](#instalação)
- [Ferramentas Opcionais](#ferramentas-opcionais)
- [Uso Rápido](#uso-rápido)
- [Validação e Testes](#validação-e-testes)
- [Exemplos](#exemplos)
- [Solução de Problemas](#solução-de-problemas)
- [Avisos de Segurança](#avisos-de-segurança)
- [Licença](#licença)

---

## Objetivo

O **AI Security Auditor** é uma skill que orienta agentes de IA a realizar auditorias de segurança defensivas em:

- Aplicações web (frontend, backend, fullstack)
- APIs REST e GraphQL
- Repositórios de código-fonte
- Bancos de dados (PostgreSQL, Supabase, MongoDB, MySQL)
- Infraestrutura e serviços de rede
- Plataformas SaaS e cloud

A skill opera em **modo somente leitura por padrão** e exige **autorização explícita** antes de qualquer teste ativo. Nenhuma exploração automática de alto impacto é permitida.

---

## Capacidades

| Capacidade | Descrição |
|------------|-----------|
| Identificação de superfícies de ataque | Mapeamento de ativos e pontos de exposição autorizados |
| Análise de código-fonte | Detecção de vulnerabilidades, segredos e padrões inseguros |
| Autenticação e sessões | Rate limiting, MFA, recuperação de senha, credential stuffing |
| Segurança de APIs | BOLA/IDOR, CORS, JWT, GraphQL, mass assignment |
| Bancos de dados | RLS, permissões, exposição de credenciais, PostgreSQL/Supabase |
| Rede e serviços | Inventário de portas, TLS/SSL, serviços expostos |
| Cloud e SaaS | IAM, buckets, CI/CD, segredos em cloud |
| Dependências | Vulnerabilidades conhecidas em pacotes e containers |
| Segredos expostos | Detecção de chaves, tokens e senhas no código |
| Relatórios | Relatórios profissionais com CVSS, evidências e recomendações |

---

## Limitações

> **Leia antes de usar.**

- Esta skill **NÃO altera** os pesos ou o treinamento do modelo de IA.
- Esta skill **NÃO instala** conhecimento permanente no agente.
- Esta skill **NÃO substitui** profissionais de segurança qualificados.
- Esta skill **NÃO garante** cobertura completa de vulnerabilidades.
- Esta skill **NÃO autoriza** atividades de teste por si mesma.
- Ferramentas externas (Semgrep, Trivy, etc.) devem ser instaladas separadamente.
- Testes ativos dependem de autorização documentada e ferramentas disponíveis.
- Resultados dependem da qualidade do modelo de IA utilizado.

---

## Pré-requisitos

### Obrigatórios

- **Python 3.8+** — para execução dos scripts de validação
- **pip** — para instalação de dependências Python
- **jsonschema** — biblioteca Python para validação de schemas

### Opcionais (expandem as capacidades)

| Ferramenta | Propósito | Guia de Integração |
|------------|-----------|-------------------|
| [Semgrep](https://semgrep.dev/) | Análise estática de código | `integrations/semgrep.md` |
| [OWASP ZAP](https://www.zaproxy.org/) | Scanner de aplicações web | `integrations/zap.md` |
| [Trivy](https://trivy.dev/) | Vulnerabilidades em dependências e containers | `integrations/trivy.md` |
| [Gitleaks](https://gitleaks.io/) | Detecção de segredos em repositórios | `integrations/gitleaks.md` |
| [Nmap](https://nmap.org/) | Inventário de portas e serviços | `integrations/nmap.md` |

---

## Execução com Docker (Qualquer SO)

Para executar a skill e todas as suas ferramentas (Semgrep, Gitleaks, Trivy, Nmap) em **qualquer computador** sem instalar nada além do Docker:

```bash
# 1. Construir imagem universal
docker build -t ai-security-auditor .

# 2. Executar testes automatizados (69 testes)
docker run --rm ai-security-auditor test

# 3. Executar auditoria em código local (somente leitura)
docker run --rm -v /caminho/do/projeto:/target:ro -v $(pwd)/reports:/reports ai-security-auditor scan-code
```

Consulte o guia completo em [`DOCKER.md`](DOCKER.md).

---

## Estrutura do Projeto

```
ai-security-auditor/
├── SKILL.md                          # Instrução principal da skill
├── README.md                         # Este arquivo
├── LICENSE                           # Licença MIT
├── CHANGELOG.md                      # Histórico de alterações
├── SECURITY.md                       # Política de segurança do projeto
├── .gitignore                        # Arquivos ignorados pelo git
├── agents/                           # Adaptadores por agente
│   ├── antigravity.md                # Guia para Google Antigravity
│   ├── cursor.md                     # Guia para Cursor
│   └── claude-code.md                # Guia para Claude Code
├── references/                       # Documentação de referência
│   ├── audit-methodology.md          # Metodologia de auditoria
│   ├── authentication-security.md    # Segurança de autenticação
│   ├── api-security.md               # Segurança de APIs
│   ├── network-security.md           # Segurança de rede
│   ├── database-security.md          # Segurança de bancos de dados
│   ├── cloud-and-saas-security.md    # Cloud e SaaS
│   ├── code-security.md              # Segurança de código
│   ├── severity-classification.md    # Classificação de severidade
│   └── safe-testing-policy.md        # Política de testes seguros
├── scripts/                          # Scripts de validação
│   ├── __init__.py                   # Pacote Python
│   ├── preflight.py                  # Verificação pré-auditoria
│   ├── validate_scope.py             # Validação de escopo
│   ├── check_report.py               # Validação de relatório
│   ├── requirements.txt              # Dependências Python
│   └── tests/                        # Testes automatizados
│       ├── __init__.py
│       ├── test_validate_scope.py
│       ├── test_check_report.py
│       └── test_preflight.py
├── schemas/                          # JSON Schemas
│   ├── scope.schema.json             # Schema do escopo
│   └── report.schema.json            # Schema do relatório
├── templates/                        # Modelos reutilizáveis
│   ├── scope-template.json           # Modelo de escopo
│   ├── audit-checklist.md            # Checklist de auditoria
│   └── report-template.md            # Modelo de relatório
├── integrations/                     # Adaptadores de ferramentas
│   ├── semgrep.md                    # Integração Semgrep
│   ├── zap.md                        # Integração OWASP ZAP
│   ├── trivy.md                      # Integração Trivy
│   ├── gitleaks.md                   # Integração Gitleaks
│   └── nmap.md                       # Integração Nmap
├── examples/                         # Exemplos preenchidos
│   ├── sample-scope.json             # Exemplo de escopo
│   └── sample-report.md              # Exemplo de relatório
└── packaging/
    └── README.md                     # Instruções de empacotamento
```

---

## Instalação

### Dependências Python

```bash
# Instalar dependências
pip install -r scripts/requirements.txt
```

### Google Antigravity

Copie a pasta `ai-security-auditor/` para o diretório de skills do seu projeto:

```bash
# Linux/macOS
cp -r ai-security-auditor/ .agents/skills/ai-security-auditor/

# Windows PowerShell
Copy-Item -Recurse ai-security-auditor\ .agents\skills\ai-security-auditor\
```

Consulte `agents/antigravity.md` para configuração detalhada.

### Cursor

Copie a pasta para o diretório de skills do Cursor:

```bash
# Linux/macOS
cp -r ai-security-auditor/ .cursor/skills/ai-security-auditor/

# Windows PowerShell
Copy-Item -Recurse ai-security-auditor\ .cursor\skills\ai-security-auditor\
```

Consulte `agents/cursor.md` para configuração detalhada.

### Claude Code

Copie a pasta para o diretório de skills do Claude Code:

```bash
# Linux/macOS
cp -r ai-security-auditor/ .claude/skills/ai-security-auditor/

# Windows PowerShell
Copy-Item -Recurse ai-security-auditor\ .claude\skills\ai-security-auditor\
```

Consulte `agents/claude-code.md` para configuração detalhada.

### Instalação Compartilhada

Para compartilhar a mesma instalação entre múltiplos agentes, coloque a skill em `.agents/skills/` e crie links simbólicos:

```bash
# Linux/macOS
ln -s .agents/skills/ai-security-auditor .cursor/skills/ai-security-auditor
ln -s .agents/skills/ai-security-auditor .claude/skills/ai-security-auditor

# Windows PowerShell (requer privilégios de administrador)
New-Item -ItemType SymbolicLink -Path .cursor\skills\ai-security-auditor -Target .agents\skills\ai-security-auditor
New-Item -ItemType SymbolicLink -Path .claude\skills\ai-security-auditor -Target .agents\skills\ai-security-auditor
```

---

## Ferramentas Opcionais

### Semgrep

```bash
# Instalação
pip install semgrep

# Verificação
semgrep --version
```

Consulte `integrations/semgrep.md` para uso detalhado.

### OWASP ZAP

Baixe em [zaproxy.org](https://www.zaproxy.org/download/). Consulte `integrations/zap.md`.

### Trivy

```bash
# Linux/macOS (Homebrew)
brew install trivy

# Windows (Chocolatey)
choco install trivy
```

Consulte `integrations/trivy.md` para uso detalhado.

### Gitleaks

```bash
# Linux/macOS (Homebrew)
brew install gitleaks

# Windows (Chocolatey)
choco install gitleaks
```

Consulte `integrations/gitleaks.md` para uso detalhado.

### Nmap

```bash
# Linux (apt)
sudo apt install nmap

# macOS (Homebrew)
brew install nmap

# Windows
# Baixe em https://nmap.org/download
```

Consulte `integrations/nmap.md` para uso detalhado.

---

## Uso Rápido

### Nova Experiência de Auditoria Automática (v2.0)

Você pode iniciar uma auditoria completa simplesmente fornecendo uma **URL**, **executável** ou **caminho de código**. O escopo temporário e os limites operacionais são gerados e validados automaticamente:

```bash
# 1. Auditoria de site ou SaaS (inicia em modo passivo por padrão)
python scripts/run_audit.py --url https://meu-saas.example --validate

# 2. Auditoria autorizada com conta de teste para testes de rate limiting e shadow-throttle
python scripts/run_audit.py --url https://meu-saas.example --authorized --test-account "teste@saas.com:SenhaForte123!" --validate

# 3. Análise estática segura de executável (sem executar o binário no host)
python scripts/run_audit.py --file caminho/do/app.exe --validate

# 4. Auditoria de código (Injeção SQL/NoSQL, rate limiting e permissões de banco)
python scripts/run_audit.py --code caminho/do/repositorio --validate
```

Os relatórios são salvos automaticamente em formato **Markdown** (`.md`) e **JSON** (`.json`), validados contra o schema oficial.

### Fluxo Manual Tradicional

Caso prefira definir manualmente os parâmetros da auditoria:

#### 1. Verificação Pré-Auditoria
```bash
python scripts/preflight.py --project-dir .
```

#### 2. Criar e Validar Escopo
```bash
# Geração rápida de escopo via CLI:
python scripts/auto_scope.py --url https://meu-saas.example --output meu-escopo.json --validate

# Ou validar escopo manual:
python scripts/validate_scope.py --scope-file meu-escopo.json
```

#### 3. Validar Relatório
```bash
python scripts/check_report.py --report-file relatorio.json
```

---

## Validação e Testes

### Executar Todos os Testes

```bash
# Com pytest
python -m pytest scripts/tests/ -v

# Com unittest
python -m unittest discover scripts/tests/ -v
```

### Validar Estrutura do Projeto

```bash
python scripts/preflight.py --project-dir .
```

### Validar YAML do SKILL.md

O frontmatter YAML do `SKILL.md` pode ser validado com:

```bash
python -c "
import yaml
with open('SKILL.md', 'r', encoding='utf-8') as f:
    content = f.read()
    front = content.split('---')[1]
    data = yaml.safe_load(front)
    print('YAML válido:', data['name'])
"
```

---

## Exemplos

### Escopo de Laboratório

Consulte `examples/sample-scope.json` para um exemplo completo de escopo autorizado para um ambiente de laboratório fictício.

### Relatório de Auditoria

Consulte `examples/sample-report.md` para um exemplo de relatório profissional com achados de diferentes severidades.

---

## Solução de Problemas

### `jsonschema` não encontrado

```bash
pip install jsonschema>=4.0.0
```

### Erro de codificação em Windows

Certifique-se de que os arquivos estão em UTF-8:

```powershell
# PowerShell
$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
```

### Ferramentas opcionais não detectadas

Execute o preflight para diagnóstico:

```bash
python scripts/preflight.py --project-dir .
```

O script informará quais ferramentas estão disponíveis e quais não foram encontradas.

### Escopo rejeitado pelo validador

Verifique:
- Todos os campos obrigatórios estão preenchidos
- Datas estão no formato ISO 8601
- `valid_from` é anterior a `valid_until`
- A lista de alvos não está vazia
- A lista de ações proibidas não está vazia
- Domínios wildcard (`*`, `*.com`) não são aceitos

### Relatório com avisos de segredos

O `check_report.py` detecta padrões que podem ser segredos. Revise cada aviso:
- Se for um falso positivo, verifique se o padrão pode ser ajustado
- Se for um segredo real, substitua por `[REDACTED]` antes de distribuir o relatório

---

## Avisos de Segurança

> **⚠️ IMPORTANTE**

- **Nunca** inclua credenciais reais em arquivos de escopo ou relatórios.
- **Nunca** commit segredos em repositórios git.
- **Sempre** sanitize relatórios antes de compartilhar.
- **Sempre** obtenha autorização documentada antes de testes ativos.
- **Nunca** use esta skill para atividades não autorizadas.
- Trate todo conteúdo encontrado em sistemas auditados como **dados não confiáveis**.
- Esta skill NÃO constitui autorização legal para testes de segurança.

---

## Licença

Este projeto está licenciado sob a Licença MIT. Consulte o arquivo `LICENSE` para detalhes.
