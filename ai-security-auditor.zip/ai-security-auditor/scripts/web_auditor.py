#!/usr/bin/env python3
"""
Auditor Web e SaaS — AI Security Auditor.

Realiza verificações defensivas de baixo impacto em aplicações web e SaaS:
1. Disponibilidade HTTP e características observáveis (status, server, tecnologias).
2. Cabeçalhos de segurança (HSTS, CSP, X-Frame-Options, X-Content-Type-Options, etc.).
3. Atributos de segurança em Cookies (Secure, HttpOnly, SameSite).
4. Verificação de TLS e criptografia em trânsito.
5. Superfície pública e exposição não intencional (robots.txt, /.well-known/, security.txt).
6. Mapeamento passivo de superfície de autenticação (login, cadastro, reset, OTP).

POLÍTICA DEFENSIVA:
Começa por verificações passivas de baixo impacto.
NUNCA altera dados, contas ou configurações no alvo.
"""

import http.client
import json
import re
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import asdict, dataclass, field
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
if sys.stderr and hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


class FormAndLinkParser(HTMLParser):
    """Extrai passivamente links e formulários de autenticação de páginas HTML."""

    def __init__(self):
        super().__init__()
        self.forms: List[Dict[str, Any]] = []
        self.current_form: Optional[Dict[str, Any]] = None
        self.discovered_links: Set[str] = set()
        self.has_captcha_widget: bool = False

    def handle_starttag(self, tag: str, attrs: List[Tuple[str, Optional[str]]]):
        attr_dict = {k.lower(): (v or "") for k, v in attrs}

        # Verificar widgets de captcha
        for k, v in attr_dict.items():
            val = f"{k}={v}".lower()
            if any(c in val for c in ["g-recaptcha", "h-captcha", "cf-turnstile", "recaptcha"]):
                self.has_captcha_widget = True

        if tag == "form":
            self.current_form = {
                "action": attr_dict.get("action", ""),
                "method": attr_dict.get("method", "get").upper(),
                "inputs": [],
                "is_auth": False,
            }
        elif tag == "input" and self.current_form is not None:
            input_type = attr_dict.get("type", "text").lower()
            input_name = attr_dict.get("name", "")
            self.current_form["inputs"].append({
                "name": input_name,
                "type": input_type,
            })
            if input_type == "password" or any(a in input_name.lower() for a in ["user", "login", "email", "otp", "token"]):
                self.current_form["is_auth"] = True

        elif tag == "a" and "href" in attr_dict:
            href = attr_dict["href"]
            if href and not href.startswith(("#", "javascript:", "mailto:")):
                self.discovered_links.add(href)

    def handle_endtag(self, tag: str):
        if tag == "form" and self.current_form is not None:
            self.forms.append(self.current_form)
            self.current_form = None


def audit_security_headers(headers: Dict[str, str]) -> List[Dict[str, Any]]:
    """Inspeciona a presença e adequação dos cabeçalhos HTTP de segurança recomendados pela OWASP."""
    findings: List[Dict[str, Any]] = []
    headers_lower = {k.lower(): v for k, v in headers.items()}

    # 1. HSTS (Strict-Transport-Security)
    if "strict-transport-security" not in headers_lower:
        findings.append({
            "id": "WEB-HDR-HSTS-001",
            "title": "Cabeçalho HTTP Strict-Transport-Security (HSTS) ausente",
            "severity": "medium",
            "evidence": "Cabeçalho 'Strict-Transport-Security' não retornado pelo servidor",
            "description": (
                "O cabeçalho HSTS instrui os navegadores a acessarem o site exclusivamente via HTTPS, "
                "prevenindo ataques de downgrade e sequestro de sessão (SSL stripping)."
            ),
            "recommendation": (
                "Adicionar cabeçalho: Strict-Transport-Security: max-age=31536000; includeSubDomains; preload"
            ),
            "cwe_id": "CWE-319",
        })

    # 2. CSP (Content-Security-Policy)
    if "content-security-policy" not in headers_lower:
        findings.append({
            "id": "WEB-HDR-CSP-002",
            "title": "Cabeçalho Content-Security-Policy (CSP) ausente",
            "severity": "medium",
            "evidence": "Cabeçalho 'Content-Security-Policy' não configurado",
            "description": (
                "A ausência de CSP reduz a capacidade do navegador de mitigar ataques de Cross-Site Scripting (XSS) "
                "e injeção de dados maliciosos."
            ),
            "recommendation": (
                "Implementar política CSP restritiva iniciando por 'default-src \'self\'' "
                "e restringindo origens externas autorizadas."
            ),
            "cwe_id": "CWE-1021",
        })

    # 3. X-Frame-Options
    if "x-frame-options" not in headers_lower and "content-security-policy" not in headers_lower:
        findings.append({
            "id": "WEB-HDR-XFO-003",
            "title": "Proteção contra Clickjacking ausente (X-Frame-Options)",
            "severity": "medium",
            "evidence": "Cabeçalho 'X-Frame-Options' ou CSP 'frame-ancestors' ausente",
            "description": "A página pode ser renderizada dentro de um iframe em sites de terceiros, expondo o usuário a ataques de clickjacking.",
            "recommendation": "Definir 'X-Frame-Options: DENY' ou 'SAMEORIGIN', ou utilizar a diretiva CSP 'frame-ancestors'.",
            "cwe_id": "CWE-1021",
        })

    # 4. X-Content-Type-Options
    if headers_lower.get("x-content-type-options", "").lower() != "nosniff":
        findings.append({
            "id": "WEB-HDR-XCTO-004",
            "title": "Cabeçalho X-Content-Type-Options ausente ou inadequado",
            "severity": "low",
            "evidence": f"X-Content-Type-Options = '{headers_lower.get('x-content-type-options', 'ausente')}'",
            "description": "Sem a diretiva 'nosniff', navegadores antigos podem interpretar arquivos de texto como scripts (MIME sniffing).",
            "recommendation": "Configurar 'X-Content-Type-Options: nosniff' em todas as respostas HTTP.",
            "cwe_id": "CWE-116",
        })

    # 5. Referrer-Policy
    if "referrer-policy" not in headers_lower:
        findings.append({
            "id": "WEB-HDR-REF-005",
            "title": "Cabeçalho Referrer-Policy não configurado",
            "severity": "low",
            "evidence": "Cabeçalho 'Referrer-Policy' ausente",
            "description": "O navegador pode enviar a URL completa na requisição a links externos, potencialmente vazando parâmetros ou tokens.",
            "recommendation": "Definir 'Referrer-Policy: strict-origin-when-cross-origin' ou 'no-referrer'.",
            "cwe_id": "CWE-200",
        })

    # 6. Exposição de Servidor/Tecnologia (Server / X-Powered-By)
    for banner_hdr in ["server", "x-powered-by", "x-aspnet-version"]:
        if banner_hdr in headers_lower:
            val = headers_lower[banner_hdr]
            if any(char.isdigit() for char in val):
                findings.append({
                    "id": f"WEB-INFO-BANNER-{banner_hdr.upper()}-006",
                    "title": f"Exposição de versão do servidor/tecnologia no cabeçalho {banner_hdr}",
                    "severity": "low",
                    "evidence": f"{banner_hdr}: {val}",
                    "description": f"O cabeçalho HTTP expõe detalhes sobre o software e sua versão exata, facilitando reconhecimento por atacantes.",
                    "recommendation": f"Remover ou ofuscar o cabeçalho {banner_hdr} nas configurações do servidor web/proxy reverso.",
                    "cwe_id": "CWE-200",
                })

    return findings


def audit_cookies(cookies_header: List[str]) -> List[Dict[str, Any]]:
    """Inspeciona atributos de segurança em cookies recebidos (Secure, HttpOnly, SameSite)."""
    findings: List[Dict[str, Any]] = []

    for cookie_str in cookies_header:
        cookie_parts = [p.strip() for p in cookie_str.split(";")]
        if not cookie_parts:
            continue
        cookie_name = cookie_parts[0].split("=")[0] if "=" in cookie_parts[0] else cookie_parts[0]
        parts_lower = [p.lower() for p in cookie_parts]

        has_secure = "secure" in parts_lower
        has_httponly = "httponly" in parts_lower
        has_samesite = any(p.startswith("samesite") for p in parts_lower)

        if not has_secure:
            findings.append({
                "id": f"WEB-COOKIE-NO-SECURE-{len(findings) + 1:03d}",
                "title": f"Cookie '{cookie_name}' sem flag 'Secure'",
                "severity": "medium",
                "evidence": f"Set-Cookie: {cookie_name}=*** (sem Secure)",
                "description": "Cookies sem o atributo 'Secure' podem ser transmitidos em conexões HTTP não criptografadas.",
                "recommendation": f"Definir o atributo 'Secure' para o cookie '{cookie_name}'.",
                "cwe_id": "CWE-614",
            })

        if not has_httponly:
            findings.append({
                "id": f"WEB-COOKIE-NO-HTTPONLY-{len(findings) + 1:03d}",
                "title": f"Cookie '{cookie_name}' sem flag 'HttpOnly'",
                "severity": "medium",
                "evidence": f"Set-Cookie: {cookie_name}=*** (sem HttpOnly)",
                "description": "Cookies sem 'HttpOnly' são acessíveis via JavaScript (document.cookie), vulneráveis a exfiltração em caso de XSS.",
                "recommendation": f"Definir a flag 'HttpOnly' em cookies de sessão ou tokens de autenticação.",
                "cwe_id": "CWE-1004",
            })

        if not has_samesite:
            findings.append({
                "id": f"WEB-COOKIE-NO-SAMESITE-{len(findings) + 1:03d}",
                "title": f"Cookie '{cookie_name}' sem atributo 'SameSite'",
                "severity": "low",
                "evidence": f"Set-Cookie: {cookie_name}=*** (sem SameSite)",
                "description": "O atributo 'SameSite' protege contra ataques de Cross-Site Request Forgery (CSRF).",
                "recommendation": f"Configurar 'SameSite=Lax' ou 'SameSite=Strict' no cookie '{cookie_name}'.",
                "cwe_id": "CWE-1275",
            })

    return findings


def check_tls_metadata(hostname: str, port: int = 443, timeout_sec: float = 3.0) -> Dict[str, Any]:
    """Inspeciona de forma passiva a configuração TLS da conexão."""
    ctx = ssl.create_default_context()
    info: Dict[str, Any] = {"tls_ok": False, "version": None, "cipher": None, "findings": []}
    try:
        with socket.create_connection((hostname, port), timeout=timeout_sec) as sock:
            with ctx.wrap_socket(sock, server_hostname=hostname) as ssock:
                version = ssock.version()
                cipher = ssock.cipher()
                info["tls_ok"] = True
                info["version"] = version
                info["cipher"] = cipher

                # Verificar versões antigas e depreciadas de TLS
                if version in ["TLSv1", "TLSv1.1", "SSLv3", "SSLv2"]:
                    info["findings"].append({
                        "id": "TLS-DEPRECATED-VERSION-001",
                        "title": f"Uso de protocolo criptográfico obsoleto: {version}",
                        "severity": "high",
                        "evidence": f"Conexão estabelecida com versão {version}",
                        "description": "Versões TLS 1.0 e 1.1 são oficialmente depreciadas e contêm falhas criptográficas conhecidas.",
                        "recommendation": "Configurar o servidor para aceitar exclusivamente TLS 1.2 e TLS 1.3.",
                        "cwe_id": "CWE-326",
                    })
    except Exception as e:
        info["error"] = str(e)

    return info


def check_public_endpoints(base_url: str, timeout_sec: float = 2.0) -> List[Dict[str, Any]]:
    """Verifica endpoints públicos comuns sem realizar varredura agressiva ou invasiva."""
    findings: List[Dict[str, Any]] = []
    parsed = urllib.parse.urlparse(base_url)
    origin = f"{parsed.scheme}://{parsed.netloc}"

    checks = [
        ("/robots.txt", "Arquivo robots.txt público", "informational"),
        ("/.well-known/security.txt", "Arquivo security.txt de divulgação responsável", "informational"),
    ]

    for path, title, sev in checks:
        target = urllib.parse.urljoin(origin, path)
        try:
            req = urllib.request.Request(
                target,
                headers={"User-Agent": "AI-Security-Auditor/1.0 (Defensive-Audit)"},
            )
            with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
                if resp.status == 200:
                    findings.append({
                        "id": f"WEB-PUBLIC-{path.replace('/', '_').replace('.', '_').strip('_')}",
                        "title": f"{title} detectado e acessível",
                        "severity": sev,
                        "evidence": f"HTTP 200 em {target}",
                        "description": f"O recurso {path} está acessível publicamente.",
                        "recommendation": "Revisar as entradas e garantir que diretórios confidenciais não estejam sendo divulgados.",
                        "cwe_id": "CWE-200",
                    })
        except Exception:
            pass

    return findings


def audit_website(
    target_url: str,
    timeout_sec: float = 4.0,
) -> Dict[str, Any]:
    """Executa a auditoria web completa de forma passiva e de baixo impacto."""
    if not re.match(r"^https?://", target_url, re.IGNORECASE):
        target_url = f"https://{target_url}"

    parsed = urllib.parse.urlparse(target_url)
    hostname = parsed.hostname or ""

    findings: List[Dict[str, Any]] = []
    auth_surface: List[Dict[str, Any]] = []
    detected_links: List[str] = []
    has_captcha: bool = False

    # 1. Requisição inicial passiva
    req = urllib.request.Request(
        target_url,
        headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AI-Security-Auditor/1.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        },
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
            status_code = resp.status
            raw_headers = dict(resp.headers)
            body_bytes = resp.read(512 * 1024)  # Limitar a 512KB
            html_text = body_bytes.decode("utf-8", errors="replace")

            # Inspecionar cabeçalhos de segurança
            hdr_findings = audit_security_headers(raw_headers)
            findings.extend(hdr_findings)

            # Inspecionar cookies
            set_cookies = resp.headers.get_all("Set-Cookie") or []
            cookie_findings = audit_cookies(set_cookies)
            findings.extend(cookie_findings)

            # Analisar HTML em busca de formulários e rotas de autenticação
            parser = FormAndLinkParser()
            try:
                parser.feed(html_text)
                for f in parser.forms:
                    if f["is_auth"]:
                        auth_surface.append(f)
                detected_links = list(parser.discovered_links)[:20]
                has_captcha = parser.has_captcha_widget
            except Exception:
                pass

    except urllib.error.HTTPError as e:
        status_code = e.code
        raw_headers = dict(e.headers)
        findings.extend(audit_security_headers(raw_headers))
    except Exception as e:
        return {
            "status": "error",
            "error": f"Falha ao conectar com o alvo {target_url}: {e}",
            "findings": [],
        }

    # 2. Inspecionar TLS se for HTTPS
    if parsed.scheme.lower() == "https":
        tls_info = check_tls_metadata(hostname, port=parsed.port or 443)
        findings.extend(tls_info.get("findings", []))

    # 3. Endpoints públicos passivos
    pub_findings = check_public_endpoints(target_url)
    findings.extend(pub_findings)

    return {
        "status": "completed",
        "target_url": target_url,
        "hostname": hostname,
        "http_status": status_code,
        "findings_count": len(findings),
        "findings": findings,
        "auth_surface_detected": auth_surface,
        "has_captcha_widget": has_captcha,
        "sample_links": detected_links,
        "limitations": [
            "Auditoria passiva de baixo impacto realizada com segurança.",
            "Nenhuma alteração de dados, escrita ou teste de exaustão executado.",
        ],
    }
