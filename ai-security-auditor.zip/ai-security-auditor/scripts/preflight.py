#!/usr/bin/env python3
"""
Verificação pré-voo (preflight) do ambiente para o AI Security Auditor.

Este script verifica se o ambiente de execução possui os requisitos
mínimos para rodar o auditor de segurança, incluindo versão do Python,
estrutura de diretórios do projeto e ferramentas opcionais instaladas.

NÃO realiza nenhuma varredura ou atividade de rede.
"""

import argparse
import os
import platform
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
if sys.stderr and hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


@dataclass
class ToolStatus:
    """Representa o status de uma ferramenta externa.

    Attributes:
        name: Nome da ferramenta.
        installed: Se a ferramenta está instalada.
        version: Versão detectada, se disponível.
        path: Caminho do executável, se encontrado.
    """

    name: str
    installed: bool = False
    version: Optional[str] = None
    path: Optional[str] = None


@dataclass
class PreflightReport:
    """Relatório consolidado da verificação pré-voo.

    Attributes:
        python_ok: Se a versão do Python é compatível.
        python_version: Versão atual do Python.
        structure_ok: Se a estrutura de diretórios está correta.
        missing_dirs: Diretórios ausentes.
        missing_files: Arquivos ausentes.
        tools: Status de cada ferramenta verificada.
        critical_issues: Lista de problemas críticos encontrados.
        warnings: Lista de avisos não críticos.
    """

    python_ok: bool = False
    python_version: str = ""
    structure_ok: bool = False
    missing_dirs: List[str] = field(default_factory=list)
    missing_files: List[str] = field(default_factory=list)
    tools: List[ToolStatus] = field(default_factory=list)
    critical_issues: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


# Diretórios esperados na estrutura do projeto
EXPECTED_DIRS: List[str] = [
    "schemas",
    "scripts",
    "scripts/tests",
]

# Arquivos esperados na estrutura do projeto
EXPECTED_FILES: List[str] = [
    "schemas/scope.schema.json",
    "schemas/report.schema.json",
    "scripts/__init__.py",
    "scripts/preflight.py",
    "scripts/validate_scope.py",
    "scripts/check_report.py",
    "scripts/tests/__init__.py",
    "scripts/requirements.txt",
]

# Ferramentas opcionais e comandos de versão
OPTIONAL_TOOLS: Dict[str, List[str]] = {
    "semgrep": ["semgrep", "--version"],
    "zap-cli": ["zap-cli", "--version"],
    "trivy": ["trivy", "--version"],
    "gitleaks": ["gitleaks", "version"],
    "nmap": ["nmap", "--version"],
}


def check_python_version() -> Tuple[bool, str]:
    """Verifica se a versão do Python é compatível (>= 3.8).

    Returns:
        Tupla com (versão_ok, versão_atual).
    """
    version_info = sys.version_info
    version_str = f"{version_info.major}.{version_info.minor}.{version_info.micro}"
    is_ok = version_info >= (3, 8)
    return is_ok, version_str


def check_project_structure(project_dir: Path) -> Tuple[bool, List[str], List[str]]:
    """Verifica se a estrutura de diretórios e arquivos do projeto está correta.

    Args:
        project_dir: Caminho raiz do projeto.

    Returns:
        Tupla com (estrutura_ok, diretórios_ausentes, arquivos_ausentes).
    """
    missing_dirs: List[str] = []
    missing_files: List[str] = []

    for dir_name in EXPECTED_DIRS:
        dir_path = project_dir / dir_name
        if not dir_path.is_dir():
            missing_dirs.append(dir_name)

    for file_name in EXPECTED_FILES:
        file_path = project_dir / file_name
        if not file_path.is_file():
            missing_files.append(file_name)

    structure_ok = len(missing_dirs) == 0 and len(missing_files) == 0
    return structure_ok, missing_dirs, missing_files


def detect_tool(tool_name: str, version_command: List[str]) -> ToolStatus:
    """Detecta se uma ferramenta externa está instalada e obtém sua versão.

    Tenta localizar o executável no PATH do sistema e executar
    o comando de versão para obter informações detalhadas.

    Args:
        tool_name: Nome da ferramenta a ser verificada.
        version_command: Comando e argumentos para obter a versão.

    Returns:
        Objeto ToolStatus com as informações da ferramenta.
    """
    status = ToolStatus(name=tool_name)

    # Verificar se o executável existe no PATH
    executable_path = shutil.which(version_command[0])
    if executable_path is None:
        return status

    status.path = executable_path

    # Tentar obter a versão
    try:
        result = subprocess.run(
            version_command,
            capture_output=True,
            text=True,
            timeout=15,
        )
        output = result.stdout.strip() or result.stderr.strip()
        if output:
            # Pegar apenas a primeira linha significativa
            first_line = output.split("\n")[0].strip()
            status.version = first_line
        status.installed = True
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        # Ferramenta encontrada mas não conseguiu executar
        status.installed = True
        status.version = "versão não disponível"

    return status


def run_preflight(project_dir: Path) -> PreflightReport:
    """Executa todas as verificações pré-voo e retorna o relatório.

    Verifica versão do Python, estrutura do projeto e ferramentas
    opcionais instaladas no ambiente.

    Args:
        project_dir: Caminho raiz do projeto a ser verificado.

    Returns:
        Relatório completo da verificação pré-voo.
    """
    report = PreflightReport()

    # 1. Verificar versão do Python
    report.python_ok, report.python_version = check_python_version()
    if not report.python_ok:
        report.critical_issues.append(
            f"Versão do Python ({report.python_version}) é incompatível. "
            f"Requer >= 3.8."
        )

    # 2. Verificar estrutura do projeto
    if not project_dir.exists():
        report.structure_ok = False
        report.critical_issues.append(
            f"Diretório do projeto não encontrado: {project_dir}"
        )
    else:
        report.structure_ok, report.missing_dirs, report.missing_files = (
            check_project_structure(project_dir)
        )
        if report.missing_dirs:
            report.critical_issues.append(
                f"Diretórios ausentes: {', '.join(report.missing_dirs)}"
            )
        if report.missing_files:
            report.warnings.append(
                f"Arquivos ausentes: {', '.join(report.missing_files)}"
            )

    # 3. Verificar ferramentas opcionais
    for tool_name, version_cmd in OPTIONAL_TOOLS.items():
        tool_status = detect_tool(tool_name, version_cmd)
        report.tools.append(tool_status)
        if not tool_status.installed:
            report.warnings.append(
                f"Ferramenta opcional '{tool_name}' não encontrada no PATH."
            )

    return report


def print_report(report: PreflightReport) -> None:
    """Imprime o relatório de verificação pré-voo de forma formatada.

    Args:
        report: Relatório a ser exibido.
    """
    separator = "=" * 60
    print(separator)
    print("  VERIFICAÇÃO PRÉ-VOO — AI Security Auditor")
    print(separator)
    print()

    # Python
    status_icon = "✅" if report.python_ok else "❌"
    print(f"[Python] {status_icon} Versão: {report.python_version}")
    print(f"         Plataforma: {platform.platform()}")
    print()

    # Estrutura do projeto
    status_icon = "✅" if report.structure_ok else "❌"
    print(f"[Estrutura] {status_icon} {'OK' if report.structure_ok else 'Problemas encontrados'}")
    if report.missing_dirs:
        for d in report.missing_dirs:
            print(f"            ❌ Diretório ausente: {d}")
    if report.missing_files:
        for f in report.missing_files:
            print(f"            ⚠️  Arquivo ausente: {f}")
    print()

    # Ferramentas opcionais
    print("[Ferramentas Opcionais]")
    for tool in report.tools:
        if tool.installed:
            version_info = f" (v{tool.version})" if tool.version else ""
            print(f"  ✅ {tool.name}{version_info}")
            if tool.path:
                print(f"     Caminho: {tool.path}")
        else:
            print(f"  ⬜ {tool.name} — não instalada")
    print()

    # Problemas críticos
    if report.critical_issues:
        print("[Problemas Críticos]")
        for issue in report.critical_issues:
            print(f"  ❌ {issue}")
        print()

    # Avisos
    if report.warnings:
        print("[Avisos]")
        for warning in report.warnings:
            print(f"  ⚠️  {warning}")
        print()

    # Resultado final
    print(separator)
    has_critical = len(report.critical_issues) > 0
    if has_critical:
        print("  RESULTADO: ❌ Problemas críticos encontrados.")
        print("  Corrija os problemas acima antes de prosseguir.")
    else:
        installed_count = sum(1 for t in report.tools if t.installed)
        total_count = len(report.tools)
        print(f"  RESULTADO: ✅ Ambiente pronto para uso.")
        print(f"  Ferramentas opcionais: {installed_count}/{total_count} detectadas.")
    print(separator)


def main() -> int:
    """Ponto de entrada principal do script de verificação pré-voo.

    Analisa os argumentos da linha de comando, executa a verificação
    e retorna o código de saída apropriado.

    Returns:
        0 se a estrutura básica está OK, 1 se há problemas críticos.
    """
    parser = argparse.ArgumentParser(
        description="Verificação pré-voo do ambiente para o AI Security Auditor.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Exemplos de uso:\n"
            "  python preflight.py --project-dir /caminho/do/projeto\n"
            "  python preflight.py  (usa o diretório pai do script)\n"
        ),
    )
    parser.add_argument(
        "--project-dir",
        type=str,
        default=None,
        help="Caminho do diretório raiz do projeto. Se não informado, "
        "usa o diretório pai do script.",
    )

    args = parser.parse_args()

    if args.project_dir:
        project_dir = Path(args.project_dir).resolve()
    else:
        # Usar o diretório pai do script como padrão
        project_dir = Path(__file__).resolve().parent.parent

    report = run_preflight(project_dir)
    print_report(report)

    # Retornar código de saída
    has_critical = len(report.critical_issues) > 0
    return 1 if has_critical else 0


if __name__ == "__main__":
    sys.exit(main())
