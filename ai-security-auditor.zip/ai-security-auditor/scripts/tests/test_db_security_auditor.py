#!/usr/bin/env python3
"""
Testes unitários para auditoria de segurança de banco de dados (db_security_auditor.py).
"""

import sys
import tempfile
import unittest
from pathlib import Path

# Adicionar scripts ao path
TESTS_DIR = Path(__file__).resolve().parent
SCRIPTS_DIR = TESTS_DIR.parent
PROJECT_ROOT = SCRIPTS_DIR.parent
sys.path.insert(0, str(SCRIPTS_DIR))

from db_security_auditor import (
    analyze_nosql_injection_patterns,
    analyze_sql_injection_patterns,
    check_db_configuration_and_secrets,
    run_database_security_audit,
)


class TestDBSecurityAuditor(unittest.TestCase):
    """Testes para detecção estática de injeção SQL/NoSQL e exposição de banco de dados."""

    def test_detect_sql_injection_concatenation_and_fstrings(self):
        """Detecta concatenação de strings e f-strings em queries SQL."""
        with tempfile.TemporaryDirectory() as tmpdir:
            file_py = Path(tmpdir) / "queries.py"
            file_py.write_text(
                """
                def get_user(user_id):
                    # Injeção por concatenação
                    query = "SELECT * FROM users WHERE id = '" + user_id + "'"
                    # Injeção por f-string
                    cursor.execute(f"SELECT * FROM accounts WHERE name = {user_id}")
                    # Injeção por ORDER BY
                    order_query = "SELECT * FROM products ORDER BY " + user_id
                """,
                encoding="utf-8",
            )

            findings = analyze_sql_injection_patterns(tmpdir)
            titles = [f["title"] for f in findings]

            self.assertTrue(any("Concatenação de string em query SQL" in t for t in titles))
            self.assertTrue(any("Interpolação de f-string em query SQL" in t for t in titles))
            self.assertTrue(any("ORDER BY" in t for t in titles))

    def test_detect_nosql_injection_patterns(self):
        """Detecta vulnerabilidades de injeção NoSQL no MongoDB/Mongoose."""
        with tempfile.TemporaryDirectory() as tmpdir:
            file_js = Path(tmpdir) / "userController.js"
            file_js.write_text(
                """
                app.post('/api/login', async (req, res) => {
                    // Passagem direta de objeto não sanitizado
                    const user = await User.find(req.body);
                    
                    // Propriedade sem coerção de tipo
                    const auth = await User.findOne({ username: req.body.username, password: req.body.password });
                });
                """,
                encoding="utf-8",
            )

            findings = analyze_nosql_injection_patterns(tmpdir)
            titles = [f["title"] for f in findings]

            self.assertTrue(any("Objeto de requisição não sanitizado" in t for t in titles))
            self.assertTrue(any("Propriedade de autenticação sem validação" in t for t in titles))

    def test_detect_exposed_db_backups_and_superusers(self):
        """Detecta arquivos de dump .sql expostos e conexões com usuário superadmin."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Arquivo de dump exposto
            dump_file = Path(tmpdir) / "backup_2026.sql"
            dump_file.write_text("CREATE TABLE users (id INT, pass TEXT);", encoding="utf-8")

            # Arquivo de configuração com usuário root e MD5
            conf_file = Path(tmpdir) / "config.env"
            conf_file.write_text(
                """
                DATABASE_URL=postgres://root:supersecret@10.0.0.5:5432/production
                HASH_ALGO=hashlib.md5(password)
                """,
                encoding="utf-8",
            )

            findings = check_db_configuration_and_secrets(tmpdir)
            finding_ids = [f["id"] for f in findings]

            self.assertTrue(any("DB-BACKUP-EXPOSED" in fid for fid in finding_ids))
            self.assertTrue(any("DB-SUPERUSER-CONN" in fid for fid in finding_ids))

    def test_run_database_security_audit_read_only(self):
        """Garante que a auditoria é executada em modo estritamente somente leitura."""
        with tempfile.TemporaryDirectory() as tmpdir:
            res = run_database_security_audit(code_dir=tmpdir)
            self.assertEqual(res["status"], "completed")
            self.assertTrue(res["read_only_verified"])
            self.assertTrue(any("somente leitura" in lim.lower() for lim in res["limitations"]))


if __name__ == "__main__":
    unittest.main()
