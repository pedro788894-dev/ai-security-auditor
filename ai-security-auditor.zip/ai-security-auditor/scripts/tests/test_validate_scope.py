#!/usr/bin/env python3
"""
Testes automatizados para o script de validação de escopo.

Cobre cenários de escopos válidos, datas inválidas, domínios curinga,
faixas CIDR excessivamente amplas, alvos dentro/fora do escopo,
e diversos casos de validação semântica.

Todos os testes são locais — nenhuma atividade de rede é realizada.
"""

import json
import unittest
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict

# Adicionar o diretório pai ao path para importação
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from validate_scope import (
    is_target_in_scope,
    validate_against_schema,
    validate_date_range,
    validate_domain,
    validate_ip_or_range,
    validate_prohibited_actions,
    validate_scope,
    validate_targets,
)

# Caminho do schema
SCHEMA_PATH = Path(__file__).resolve().parent.parent.parent / "schemas" / "scope.schema.json"


def _load_schema() -> Dict[str, Any]:
    """Carrega o schema de escopo para uso nos testes."""
    with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def _make_valid_scope() -> Dict[str, Any]:
    """Cria um escopo válido para uso como base nos testes.

    Returns:
        Dicionário com todos os campos obrigatórios preenchidos corretamente.
    """
    now = datetime.now(timezone.utc)
    valid_from = now - timedelta(hours=1)
    valid_until = now + timedelta(days=30)

    return {
        "audit_id": "AUDIT-2024-001",
        "audit_name": "Teste de Segurança - Aplicação Web",
        "authorized_by": "João Silva",
        "authorization_date": now.strftime("%Y-%m-%d"),
        "valid_from": valid_from.isoformat(),
        "valid_until": valid_until.isoformat(),
        "contact": {
            "name": "Maria Santos",
            "email": "maria@example.com",
            "role": "CISO",
        },
        "targets": [
            {
                "type": "domain",
                "identifier": "example.com",
                "description": "Domínio principal da aplicação web",
                "includes_subdomains": False,
                "protocols": ["https"],
                "ports": [443],
                "environment": "staging",
            }
        ],
        "constraints": {
            "max_requests_per_second": 10,
            "max_duration_minutes": 480,
            "allowed_hours": "09:00-18:00",
            "concurrent_connections": 5,
        },
        "prohibited_actions": [
            "Negação de serviço (DoS/DDoS)",
            "Engenharia social contra funcionários",
            "Acesso a dados de produção de clientes reais",
        ],
        "testing_mode": "passive_and_active",
        "notes": "Auditoria agendada para o período de manutenção.",
    }


class TestValidScopePassesValidation(unittest.TestCase):
    """Testes para verificar que escopos válidos passam na validação."""

    def setUp(self) -> None:
        """Configura o schema e escopo base para os testes."""
        self.schema = _load_schema()
        self.valid_scope = _make_valid_scope()

    def test_valid_scope_passes_schema_validation(self) -> None:
        """Verifica que um escopo válido passa na validação do schema."""
        errors = validate_against_schema(self.valid_scope, self.schema)
        self.assertEqual(errors, [], f"Escopo válido gerou erros: {errors}")

    def test_valid_scope_passes_full_validation(self) -> None:
        """Verifica que um escopo válido passa na validação completa."""
        errors, warnings = validate_scope(self.valid_scope, schema=self.schema)
        self.assertEqual(errors, [], f"Escopo válido gerou erros: {errors}")


class TestExpiredScope(unittest.TestCase):
    """Testes para verificar que escopos expirados são rejeitados."""

    def test_expired_scope_is_rejected(self) -> None:
        """Verifica que um escopo com valid_until no passado é rejeitado."""
        scope = _make_valid_scope()
        past = datetime.now(timezone.utc) - timedelta(days=1)
        scope["valid_from"] = (past - timedelta(days=30)).isoformat()
        scope["valid_until"] = past.isoformat()

        errors = validate_date_range(scope)
        self.assertTrue(
            any("expirado" in e.lower() for e in errors),
            f"Escopo expirado deveria ser rejeitado. Erros: {errors}",
        )


class TestEmptyTargets(unittest.TestCase):
    """Testes para verificar que listas de alvos vazias são rejeitadas."""

    def test_empty_targets_list_is_rejected(self) -> None:
        """Verifica que uma lista de alvos vazia gera erro."""
        scope = _make_valid_scope()
        scope["targets"] = []

        errors = validate_targets(scope)
        self.assertTrue(
            any("vazia" in e.lower() or "targets" in e.lower() for e in errors),
            f"Lista de alvos vazia deveria ser rejeitada. Erros: {errors}",
        )

    def test_schema_rejects_empty_targets(self) -> None:
        """Verifica que o schema também rejeita lista de alvos vazia."""
        schema = _load_schema()
        scope = _make_valid_scope()
        scope["targets"] = []

        errors = validate_against_schema(scope, schema)
        self.assertTrue(len(errors) > 0, "Schema deveria rejeitar targets vazio.")


class TestMissingRequiredFields(unittest.TestCase):
    """Testes para verificar que campos obrigatórios ausentes são detectados."""

    def setUp(self) -> None:
        """Configura o schema para os testes."""
        self.schema = _load_schema()

    def test_missing_audit_id(self) -> None:
        """Verifica que ausência de audit_id gera erro de schema."""
        scope = _make_valid_scope()
        del scope["audit_id"]

        errors = validate_against_schema(scope, self.schema)
        self.assertTrue(len(errors) > 0, "Deveria rejeitar sem audit_id.")

    def test_missing_authorized_by(self) -> None:
        """Verifica que ausência de authorized_by gera erro de schema."""
        scope = _make_valid_scope()
        del scope["authorized_by"]

        errors = validate_against_schema(scope, self.schema)
        self.assertTrue(len(errors) > 0, "Deveria rejeitar sem authorized_by.")

    def test_missing_testing_mode(self) -> None:
        """Verifica que ausência de testing_mode gera erro de schema."""
        scope = _make_valid_scope()
        del scope["testing_mode"]

        errors = validate_against_schema(scope, self.schema)
        self.assertTrue(len(errors) > 0, "Deveria rejeitar sem testing_mode.")

    def test_missing_contact(self) -> None:
        """Verifica que ausência de contact gera erro de schema."""
        scope = _make_valid_scope()
        del scope["contact"]

        errors = validate_against_schema(scope, self.schema)
        self.assertTrue(len(errors) > 0, "Deveria rejeitar sem contact.")


class TestWildcardDomains(unittest.TestCase):
    """Testes para verificar que domínios curinga genéricos são rejeitados."""

    def test_pure_wildcard_is_rejected(self) -> None:
        """Verifica que o domínio '*' é rejeitado."""
        errors = validate_domain("*")
        self.assertTrue(
            any("curinga" in e.lower() or "proibido" in e.lower() for e in errors),
            f"Domínio '*' deveria ser rejeitado. Erros: {errors}",
        )

    def test_wildcard_tld_is_rejected(self) -> None:
        """Verifica que '*.com' é rejeitado."""
        errors = validate_domain("*.com")
        self.assertTrue(
            any("curinga" in e.lower() or "proibido" in e.lower() for e in errors),
            f"Domínio '*.com' deveria ser rejeitado. Erros: {errors}",
        )

    def test_wildcard_net_is_rejected(self) -> None:
        """Verifica que '*.net' é rejeitado."""
        errors = validate_domain("*.net")
        self.assertTrue(
            any("curinga" in e.lower() or "proibido" in e.lower() for e in errors),
            f"Domínio '*.net' deveria ser rejeitado. Erros: {errors}",
        )

    def test_specific_subdomain_wildcard_is_allowed(self) -> None:
        """Verifica que '*.example.com' é permitido (curinga parcial válido)."""
        errors = validate_domain("*.example.com")
        self.assertEqual(
            errors, [],
            f"Domínio '*.example.com' deveria ser permitido. Erros: {errors}",
        )


class TestBroadCIDRRanges(unittest.TestCase):
    """Testes para verificar que faixas CIDR excessivamente amplas são rejeitadas."""

    def test_slash_zero_is_rejected(self) -> None:
        """Verifica que 0.0.0.0/0 é rejeitado."""
        errors = validate_ip_or_range("0.0.0.0/0", "ip_range")
        self.assertTrue(
            any("ampla" in e.lower() for e in errors),
            f"Faixa /0 deveria ser rejeitada. Erros: {errors}",
        )

    def test_slash_eight_is_rejected(self) -> None:
        """Verifica que 10.0.0.0/8 é rejeitado."""
        errors = validate_ip_or_range("10.0.0.0/8", "ip_range")
        self.assertTrue(
            any("ampla" in e.lower() for e in errors),
            f"Faixa /8 deveria ser rejeitada. Erros: {errors}",
        )

    def test_slash_24_is_allowed(self) -> None:
        """Verifica que 192.168.1.0/24 é permitido."""
        errors = validate_ip_or_range("192.168.1.0/24", "ip_range")
        self.assertEqual(
            errors, [],
            f"Faixa /24 deveria ser permitida. Erros: {errors}",
        )

    def test_slash_16_is_allowed(self) -> None:
        """Verifica que 172.16.0.0/16 é permitido."""
        errors = validate_ip_or_range("172.16.0.0/16", "ip_range")
        self.assertEqual(
            errors, [],
            f"Faixa /16 deveria ser permitida. Erros: {errors}",
        )


class TestInvalidIPAddresses(unittest.TestCase):
    """Testes para verificar que endereços IP inválidos são detectados."""

    def test_invalid_ip_is_caught(self) -> None:
        """Verifica que um IP inválido gera erro."""
        errors = validate_ip_or_range("999.999.999.999", "ip")
        self.assertTrue(len(errors) > 0, "IP inválido deveria gerar erro.")

    def test_invalid_cidr_is_caught(self) -> None:
        """Verifica que um CIDR inválido gera erro."""
        errors = validate_ip_or_range("not_an_ip/24", "ip_range")
        self.assertTrue(len(errors) > 0, "CIDR inválido deveria gerar erro.")

    def test_valid_ipv4_is_accepted(self) -> None:
        """Verifica que um IPv4 válido é aceito."""
        errors = validate_ip_or_range("192.168.1.100", "ip")
        self.assertEqual(errors, [], f"IPv4 válido gerou erros: {errors}")

    def test_valid_ipv6_is_accepted(self) -> None:
        """Verifica que um IPv6 válido é aceito."""
        errors = validate_ip_or_range("::1", "ip")
        self.assertEqual(errors, [], f"IPv6 válido gerou erros: {errors}")


class TestTargetInScope(unittest.TestCase):
    """Testes para verificar a função de checagem de alvos dentro do escopo."""

    def setUp(self) -> None:
        """Configura o escopo base para os testes."""
        self.scope = _make_valid_scope()
        # Adicionar mais alvos ao escopo para testes
        self.scope["targets"].extend([
            {
                "type": "ip_range",
                "identifier": "192.168.1.0/24",
                "description": "Rede interna",
                "environment": "development",
            },
            {
                "type": "domain",
                "identifier": "api.example.com",
                "description": "API principal",
                "includes_subdomains": True,
                "protocols": ["https"],
                "ports": [443],
                "environment": "staging",
            },
        ])

    def test_exact_domain_match(self) -> None:
        """Verifica que correspondência exata de domínio funciona."""
        result = is_target_in_scope("example.com", "domain", self.scope)
        self.assertTrue(result, "Domínio exato deveria estar no escopo.")

    def test_ip_in_range(self) -> None:
        """Verifica que IP dentro da faixa autorizada é reconhecido."""
        result = is_target_in_scope("192.168.1.50", "ip", self.scope)
        self.assertTrue(result, "IP dentro da faixa deveria estar no escopo.")

    def test_ip_outside_range(self) -> None:
        """Verifica que IP fora da faixa autorizada é rejeitado."""
        result = is_target_in_scope("10.0.0.1", "ip", self.scope)
        self.assertFalse(result, "IP fora da faixa não deveria estar no escopo.")

    def test_subdomain_when_not_included(self) -> None:
        """Verifica que subdomínios não são incluídos por padrão."""
        result = is_target_in_scope("sub.example.com", "domain", self.scope)
        self.assertFalse(
            result,
            "Subdomínio não deveria estar no escopo quando includes_subdomains=False.",
        )

    def test_subdomain_when_included(self) -> None:
        """Verifica que subdomínios são incluídos quando configurado."""
        result = is_target_in_scope("v2.api.example.com", "domain", self.scope)
        self.assertTrue(
            result,
            "Subdomínio deveria estar no escopo quando includes_subdomains=True.",
        )

    def test_unrelated_domain_not_in_scope(self) -> None:
        """Verifica que domínios não relacionados não estão no escopo."""
        result = is_target_in_scope("evil.com", "domain", self.scope)
        self.assertFalse(result, "Domínio não autorizado não deveria estar no escopo.")


class TestDateRanges(unittest.TestCase):
    """Testes para validação de faixas de datas."""

    def test_valid_date_range(self) -> None:
        """Verifica que um intervalo de datas válido é aceito."""
        scope = _make_valid_scope()
        errors = validate_date_range(scope)
        self.assertEqual(errors, [], f"Datas válidas geraram erros: {errors}")

    def test_valid_from_after_valid_until(self) -> None:
        """Verifica que valid_from posterior a valid_until é rejeitado."""
        scope = _make_valid_scope()
        now = datetime.now(timezone.utc)
        scope["valid_from"] = (now + timedelta(days=30)).isoformat()
        scope["valid_until"] = now.isoformat()

        errors = validate_date_range(scope)
        self.assertTrue(
            any("anterior" in e.lower() for e in errors),
            f"valid_from > valid_until deveria ser rejeitado. Erros: {errors}",
        )


class TestProhibitedActions(unittest.TestCase):
    """Testes para validação de ações proibidas."""

    def test_empty_prohibited_actions_is_rejected(self) -> None:
        """Verifica que lista de ações proibidas vazia é rejeitada."""
        scope = _make_valid_scope()
        scope["prohibited_actions"] = []

        errors = validate_prohibited_actions(scope)
        self.assertTrue(
            len(errors) > 0,
            "Lista vazia de ações proibidas deveria ser rejeitada.",
        )

    def test_valid_prohibited_actions(self) -> None:
        """Verifica que lista de ações proibidas não vazia é aceita."""
        scope = _make_valid_scope()
        errors = validate_prohibited_actions(scope)
        self.assertEqual(
            errors, [],
            f"Lista válida de ações proibidas gerou erros: {errors}",
        )


class TestSubdomainExplicitSetting(unittest.TestCase):
    """Testes para verificar que includes_subdomains é exigido para domínios."""

    def test_missing_includes_subdomains_for_domain(self) -> None:
        """Verifica que ausência de includes_subdomains em domínio gera erro."""
        scope = _make_valid_scope()
        # Remover includes_subdomains do alvo de domínio
        del scope["targets"][0]["includes_subdomains"]

        errors = validate_targets(scope)
        self.assertTrue(
            any("includes_subdomains" in e for e in errors),
            f"Ausência de includes_subdomains deveria gerar erro. Erros: {errors}",
        )


class TestDomainFormat(unittest.TestCase):
    """Testes para validação de formato de domínios."""

    def test_valid_domain(self) -> None:
        """Verifica que domínios válidos são aceitos."""
        errors = validate_domain("example.com")
        self.assertEqual(errors, [], f"Domínio válido gerou erros: {errors}")

    def test_valid_subdomain(self) -> None:
        """Verifica que subdomínios válidos são aceitos."""
        errors = validate_domain("sub.example.com")
        self.assertEqual(errors, [], f"Subdomínio válido gerou erros: {errors}")

    def test_invalid_domain_format(self) -> None:
        """Verifica que domínios com formato inválido são rejeitados."""
        errors = validate_domain("not a domain")
        self.assertTrue(len(errors) > 0, "Domínio inválido deveria gerar erro.")

    def test_domain_with_underscore(self) -> None:
        """Verifica que domínios com caracteres inválidos são tratados."""
        # Underscores geralmente não são válidos em domínios públicos
        # mas a validação depende do regex
        errors = validate_domain("ex_ample.com")
        # Pode ou não gerar erro dependendo do regex - o importante é não falhar
        self.assertIsInstance(errors, list)


if __name__ == "__main__":
    unittest.main()
