#!/usr/bin/env python3
"""
Testes de integração para o orquestrador de auditoria (run_audit.py).
"""

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

# Adicionar scripts ao path
TESTS_DIR = Path(__file__).resolve().parent
SCRIPTS_DIR = TESTS_DIR.parent
PROJECT_ROOT = SCRIPTS_DIR.parent
sys.path.insert(0, str(SCRIPTS_DIR))

from check_report import validate_report
from run_audit import run_full_audit


class TestRunAudit(unittest.TestCase):
    """Testes de ponta a ponta do fluxo de auditoria e geração de relatórios."""

    def test_run_audit_code_generates_valid_report(self):
        """Auditoria em código gera relatórios JSON e MD válidos conforme report.schema.json."""
        with tempfile.TemporaryDirectory() as tmpdir:
            src_dir = Path(tmpdir) / "src"
            src_dir.mkdir()
            (src_dir / "db.py").write_text(
                """
                def fetch_user(uid):
                    # Query SQL com concatenação
                    sql = "SELECT id, name FROM users WHERE id = '" + uid + "'"
                    cursor.execute(sql)
                """,
                encoding="utf-8",
            )

            out_dir = Path(tmpdir) / "output"
            report_data, md_content, json_path, md_path = run_full_audit(
                code_path=str(src_dir),
                authorized=True,
                output_dir=str(out_dir),
            )

            # Verificar arquivos no disco
            self.assertTrue(json_path.exists())
            self.assertTrue(md_path.exists())

            # Validar integridade contra o schema oficial de relatório
            errors, warnings = validate_report(report_data)
            self.assertEqual(errors, [], f"Erros no relatório JSON: {errors}")

            # Verificar seções do Markdown
            self.assertIn("# Relatório de Auditoria de Segurança", md_content)
            self.assertIn("## Metadados da Auditoria", md_content)
            self.assertIn("## 1. Resumo Executivo", md_content)
            self.assertIn("## 6. Descobertas e Vulnerabilidades Detalhadas", md_content)
            self.assertIn("## 7. Conclusão e Próximos Passos", md_content)

    def test_run_audit_executable_generates_valid_report(self):
        """Auditoria em binário executável gera relatório estático e seguro válido."""
        from test_executable_auditor import create_minimal_pe_binary

        with tempfile.TemporaryDirectory() as tmpdir:
            exe_file = Path(tmpdir) / "app.exe"
            exe_file.write_bytes(create_minimal_pe_binary(has_aslr=False, has_dep=False))

            out_dir = Path(tmpdir) / "output"
            report_data, md_content, json_path, md_path = run_full_audit(
                file_path=str(exe_file),
                authorized=False,
                output_dir=str(out_dir),
            )

            errors, warnings = validate_report(report_data)
            self.assertEqual(errors, [], f"Erros no relatório JSON: {errors}")
            self.assertEqual(report_data["scope"]["testing_mode"], "passive_only")

    @patch("web_auditor.urllib.request.urlopen")
    def test_run_audit_url_passive_mode(self, mock_urlopen):
        """Auditoria em URL opera em modo passivo sem autorização e produz relatório válido."""
        mock_headers = MagicMock()
        mock_headers.__iter__.return_value = ["Server", "Content-Type"]
        mock_headers.items.return_value = [("Server", "nginx/1.18.0"), ("Content-Type", "text/html")]
        mock_headers.get.side_effect = lambda k, d=None: {"server": "nginx/1.18.0", "content-type": "text/html"}.get(k.lower(), d)
        mock_headers.__getitem__.side_effect = lambda k: {"server": "nginx/1.18.0", "content-type": "text/html"}[k.lower()]
        mock_headers.__contains__.side_effect = lambda k: k.lower() in ["server", "content-type"]
        mock_headers.get_all.return_value = ["session_id=123; path=/"]

        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = mock_headers
        mock_resp.read.return_value = b"<html><form action='/login'><input type='password' name='p'></form></html>"
        mock_resp.__enter__.return_value = mock_resp
        mock_urlopen.return_value = mock_resp

        with tempfile.TemporaryDirectory() as tmpdir:
            out_dir = Path(tmpdir) / "output"
            report_data, md_content, json_path, md_path = run_full_audit(
                url="https://saas-exemplo.com",
                authorized=False,
                output_dir=str(out_dir),
            )

            errors, warnings = validate_report(report_data)
            self.assertEqual(errors, [], f"Erros no relatório: {errors}")
            self.assertEqual(report_data["scope"]["testing_mode"], "passive_only")
            # Verificar que limitações incluem a ausência de autorização ativa
            limitations_str = " ".join(report_data["limitations"])
            self.assertIn("passivas", limitations_str.lower())

    def test_run_audit_requires_target(self):
        """Rejeita execução sem nenhum alvo especificado."""
        with self.assertRaises(ValueError):
            run_full_audit(url=None, file_path=None, code_path=None)


if __name__ == "__main__":
    unittest.main()
