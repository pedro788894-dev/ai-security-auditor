#!/usr/bin/env python3
"""
Testes unitários para auditoria de força bruta e autenticação (brute_force_auditor.py).
"""

import sys
import unittest
from pathlib import Path

# Adicionar scripts ao path
TESTS_DIR = Path(__file__).resolve().parent
SCRIPTS_DIR = TESTS_DIR.parent
PROJECT_ROOT = SCRIPTS_DIR.parent
sys.path.insert(0, str(SCRIPTS_DIR))

from brute_force_auditor import (
    ResponseSample,
    analyze_timing_side_channel,
    audit_code_for_brute_force_flaws,
    classify_defense_state,
    execute_controlled_burst_test,
)


class TestBruteForceAuditor(unittest.TestCase):
    """Testes de classificação de defesas de força bruta e side-channels."""

    def test_classify_hard_lockout_by_status_403(self):
        """Classifica Hard Lockout quando status 403 é retornado após tentativas."""
        samples = [
            ResponseSample(index=1, status_code=401, latency_ms=100.0, body_length=50, body_snippet="Invalid"),
            ResponseSample(index=2, status_code=401, latency_ms=102.0, body_length=50, body_snippet="Invalid"),
            ResponseSample(index=3, status_code=403, latency_ms=90.0, body_length=70, body_snippet="Forbidden"),
        ]
        result = classify_defense_state(samples)
        self.assertEqual(result.state, "Hard lockout")
        self.assertEqual(result.confidence, "high")
        self.assertTrue(any("403" in s for s in result.signals))

    def test_classify_hard_lockout_by_message(self):
        """Classifica Hard Lockout quando mensagem textual explícita de bloqueio é retornada."""
        samples = [
            ResponseSample(index=1, status_code=401, latency_ms=100.0, body_length=50, body_snippet="Invalid"),
            ResponseSample(
                index=2,
                status_code=401,
                latency_ms=105.0,
                body_length=120,
                body_snippet="Too many failed login attempts. Account temporarily locked for 15 minutes.",
            ),
        ]
        result = classify_defense_state(samples)
        self.assertEqual(result.state, "Hard lockout")
        self.assertTrue(any("Account temporarily locked" in s or "bloqueio de conta" in s for s in result.signals))

    def test_classify_soft_ip_throttle_429(self):
        """Classifica Soft IP Throttle quando status 429 é observado."""
        samples = [
            ResponseSample(index=1, status_code=401, latency_ms=120.0, body_length=50),
            ResponseSample(index=2, status_code=429, latency_ms=120.0, body_length=60, headers={"Retry-After": "60"}),
        ]
        result = classify_defense_state(samples)
        self.assertEqual(result.state, "Soft IP throttle")
        self.assertTrue(any("429" in s for s in result.signals))

    def test_classify_soft_throttle_by_latency_escalation(self):
        """Classifica Soft Throttle quando latência aumenta progressivamente com retry-after."""
        samples = [
            ResponseSample(index=1, status_code=200, latency_ms=100.0, body_length=50, headers={"retry-after": "5"}),
            ResponseSample(index=2, status_code=200, latency_ms=120.0, body_length=50, headers={"retry-after": "5"}),
            ResponseSample(index=3, status_code=200, latency_ms=300.0, body_length=50, headers={"retry-after": "10"}),
            ResponseSample(index=4, status_code=200, latency_ms=600.0, body_length=50, headers={"retry-after": "15"}),
            ResponseSample(index=5, status_code=200, latency_ms=900.0, body_length=50, headers={"retry-after": "20"}),
            ResponseSample(index=6, status_code=200, latency_ms=1200.0, body_length=50, headers={"retry-after": "30"}),
        ]
        result = classify_defense_state(samples)
        self.assertEqual(result.state, "Soft IP throttle")

    def test_classify_captcha_injection(self):
        """Classifica CAPTCHA Injection quando formulário passa a exigir captcha."""
        samples = [
            ResponseSample(index=1, status_code=200, latency_ms=100.0, body_length=500, body_snippet="<form action='/login'></form>"),
            ResponseSample(index=2, status_code=200, latency_ms=100.0, body_length=500, body_snippet="<form action='/login'></form>"),
            ResponseSample(
                index=3,
                status_code=200,
                latency_ms=105.0,
                body_length=800,
                body_snippet="<form action='/login'><div class='g-recaptcha' data-sitekey='xxx'></div></form>",
            ),
        ]
        result = classify_defense_state(samples)
        self.assertEqual(result.state, "CAPTCHA injection")

    def test_classify_silent_shadow_throttle_via_seed_test(self):
        """Confirma Silent Shadow-Throttle via falha no Shadow-Throttle Seed Test sob carga."""
        samples = [
            ResponseSample(index=i, status_code=401, latency_ms=110.0, body_length=50, body_snippet="Bad password")
            for i in range(1, 15)
        ]
        # Injeção de credencial sabidamente válida na sequência
        # Ela retorna 401 ou falha silenciosamente
        seed_sample = ResponseSample(
            index=15,
            status_code=401,
            latency_ms=112.0,
            body_length=50,
            is_seed=True,
            is_success=False,  # Credencial válida falhou sob carga!
        )

        result = classify_defense_state(samples, seed_sample=seed_sample)
        self.assertEqual(result.state, "Silent shadow-throttle")
        self.assertTrue(result.seed_tested)
        self.assertFalse(result.seed_succeeded)
        self.assertTrue(any("Teste de semente" in s for s in result.signals))

    def test_classify_no_rate_limiting_via_successful_seed_test(self):
        """Classifica No rate limiting quando a credencial válida autentica normalmente sob carga."""
        samples = [
            ResponseSample(index=i, status_code=401, latency_ms=100.0, body_length=50, body_snippet="Bad")
            for i in range(1, 20)
        ]
        # Credencial válida injetada obtém 200 OK / sucesso
        seed_sample = ResponseSample(
            index=20,
            status_code=200,
            latency_ms=105.0,
            body_length=200,
            is_seed=True,
            is_success=True,  # Credencial válida autenticou com sucesso
        )

        result = classify_defense_state(samples, seed_sample=seed_sample)
        self.assertEqual(result.state, "No rate limiting")
        self.assertTrue(result.seed_tested)
        self.assertTrue(result.seed_succeeded)

    def test_timing_side_channel_requires_at_least_30_samples(self):
        """Garante que conclusões de timing exigem medianas de pelo menos 30 amostras por usuário."""
        # Menos de 30 amostras (ex: 20)
        user_a_times = [50.0] * 20
        user_b_times = [150.0] * 20

        result = analyze_timing_side_channel(user_a_times, user_b_times, min_samples=30)
        self.assertFalse(result.difference_detected)
        self.assertIn("Amostras insuficientes", result.details)

        # Com 30 ou mais amostras e variação significativa (ex: delta 70ms)
        user_a_30 = [50.0 + (i % 3) for i in range(32)]  # mediana ~51ms
        user_b_30 = [120.0 + (i % 3) for i in range(32)]  # mediana ~121ms

        result_30 = analyze_timing_side_channel(user_a_30, user_b_30, significance_threshold_ms=35.0, min_samples=30)
        self.assertTrue(result_30.difference_detected)
        self.assertTrue(result_30.potential_enumeration)
        self.assertGreaterEqual(result_30.delta_ms, 35.0)

    def test_audit_code_detects_brute_force_vulnerabilities(self):
        """Testa análise estática de padrões de código inseguro para autenticação."""
        # Criar arquivo temporário com código vulnerável
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            vuln_file = Path(tmpdir) / "auth.js"
            vuln_file.write_text(
                """
                const express = require('express');
                const router = express.Router();

                // Rota de login sem rate limiter
                router.post('/login', async (req, res) => {
                    const { username, password } = req.body;
                    
                    // Bloqueio apenas por IP
                    if (failed_attempts[req.ip] > 5) {
                        return res.status(429).send("Too many tries");
                    }

                    // Token de reset com Math.random
                    const reset_token = Math.random().toString(36);

                    // MFA bypass flag
                    if (req.body.remember_device) {
                        return res.json({ token: "bypass" });
                    }
                });
                """,
                encoding="utf-8",
            )

            findings = audit_code_for_brute_force_flaws(tmpdir)
            finding_ids = [f["id"] for f in findings]

            self.assertTrue(any("AUTH-NO-RATELIMIT" in fid for fid in finding_ids))
            self.assertTrue(any("AUTH-IP-ONLY-LOCKOUT" in fid for fid in finding_ids))
            self.assertTrue(any("AUTH-WEAK-TOKEN-ENTROPY" in fid for fid in finding_ids))
            self.assertTrue(any("AUTH-MFA-BYPASS" in fid for fid in finding_ids))


    def test_burst_test_aborts_immediately_on_server_error_500(self):
        """Interrompe imediatamente o teste de burst ao receber status 5xx para proteger o alvo."""
        call_count = 0

        def sender(idx, is_seed):
            nonlocal call_count
            call_count += 1
            if idx == 3:
                return ResponseSample(index=idx, status_code=500, latency_ms=100.0, body_length=20)
            return ResponseSample(index=idx, status_code=401, latency_ms=100.0, body_length=20)

        classification, samples, aborted = execute_controlled_burst_test(
            request_sender=sender,
            max_attempts=30,
        )
        self.assertTrue(aborted)
        self.assertEqual(call_count, 3)

    def test_burst_test_aborts_immediately_on_latency_explosion(self):
        """Interrompe imediatamente se a latência ultrapassar o limite seguro (3000ms)."""
        call_count = 0

        def sender(idx, is_seed):
            nonlocal call_count
            call_count += 1
            if idx == 2:
                return ResponseSample(index=idx, status_code=401, latency_ms=3500.0, body_length=20)
            return ResponseSample(index=idx, status_code=401, latency_ms=150.0, body_length=20)

        classification, samples, aborted = execute_controlled_burst_test(
            request_sender=sender,
            max_attempts=20,
            latency_abort_ms=3000.0,
        )
        self.assertTrue(aborted)
        self.assertEqual(call_count, 2)

    def test_burst_test_with_seed_test_execution(self):
        """Executa seed test em posição fixa e classifica shadow-throttle se falhar."""
        def sender(idx, is_seed):
            if is_seed:
                # Credencial válida falhou sob carga
                return ResponseSample(index=idx, status_code=401, latency_ms=100.0, body_length=20, is_seed=True, is_success=False)
            return ResponseSample(index=idx, status_code=401, latency_ms=100.0, body_length=20)

        classification, samples, aborted = execute_controlled_burst_test(
            request_sender=sender,
            max_attempts=10,
            seed_position=5,
        )
        self.assertFalse(aborted)
        self.assertEqual(classification.state, "Silent shadow-throttle")
        self.assertTrue(classification.seed_tested)


if __name__ == "__main__":
    unittest.main()
