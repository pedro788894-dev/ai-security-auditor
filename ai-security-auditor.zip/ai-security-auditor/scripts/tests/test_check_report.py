#!/usr/bin/env python3
"""
Testes automatizados para o script de validação de relatórios.

Cobre cenários de relatórios válidos, campos obrigatórios ausentes,
IDs duplicados, detecção de segredos (AWS keys, JWT, chaves privadas,
strings de conexão), validação de CVSS e padrão de finding IDs.

Todos os testes são locais — nenhuma atividade de rede é realizada.
"""

import json
import unittest
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from check_report import (
    detect_secrets_in_text,
    validate_against_schema,
    validate_cvss_severity_consistency,
    validate_finding_ids,
    validate_report,
    check_findings_for_secrets,
)

# Caminho do schema
SCHEMA_PATH = (
    Path(__file__).resolve().parent.parent.parent / "schemas" / "report.schema.json"
)


def _load_schema() -> Dict[str, Any]:
    """Carrega o schema de relatório para uso nos testes."""
    with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def _make_valid_report() -> Dict[str, Any]:
    """Cria um relatório válido para uso como base nos testes.

    Returns:
        Dicionário com todos os campos obrigatórios preenchidos corretamente.
    """
    now = datetime.now(timezone.utc)

    return {
        "report_id": "RPT-2024-001",
        "audit_id": "AUDIT-2024-001",
        "title": "Relatório de Auditoria de Segurança - Aplicação Web",
        "generated_at": now.isoformat(),
        "auditor": "AI Security Auditor v1.0",
        "executive_summary": (
            "A auditoria identificou 2 vulnerabilidades de severidade média "
            "e 1 de severidade baixa. Nenhuma vulnerabilidade crítica foi encontrada."
        ),
        "scope": {
            "description": "Aplicação web em ambiente de staging",
            "targets_count": 1,
            "testing_mode": "passive_and_active",
        },
        "methodology": "OWASP Testing Guide v4.2, PTES, NIST SP 800-115",
        "tools_used": [
            {
                "name": "Semgrep",
                "version": "1.50.0",
                "purpose": "Análise estática de código",
            },
            {
                "name": "Trivy",
                "version": "0.48.0",
                "purpose": "Verificação de vulnerabilidades em dependências",
            },
        ],
        "limitations": [
            "Testes realizados apenas em ambiente de staging",
            "Sem acesso ao código-fonte completo do backend",
        ],
        "findings": [
            {
                "finding_id": "FIND-0001",
                "title": "Cabeçalhos de segurança HTTP ausentes",
                "status": "confirmed",
                "severity": "medium",
                "cvss_score": 5.3,
                "cvss_vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N",
                "description": (
                    "A aplicação não define cabeçalhos de segurança HTTP "
                    "como X-Content-Type-Options, X-Frame-Options e CSP."
                ),
                "evidence": (
                    "Resposta HTTP do endpoint /api/v1/health:\n"
                    "HTTP/1.1 200 OK\n"
                    "Content-Type: application/json\n"
                    "(cabeçalhos de segurança ausentes)"
                ),
                "impact": (
                    "Possibilidade de ataques de clickjacking, MIME sniffing "
                    "e injeção de scripts."
                ),
                "likelihood": "medium",
                "recommendation": (
                    "Configurar cabeçalhos de segurança HTTP: "
                    "X-Content-Type-Options: nosniff, "
                    "X-Frame-Options: DENY, "
                    "Content-Security-Policy: default-src 'self'"
                ),
                "references": [
                    "https://owasp.org/www-project-secure-headers/",
                    "https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers",
                ],
                "cwe_id": "CWE-693",
            },
            {
                "finding_id": "FIND-0002",
                "title": "Versão do servidor exposta",
                "status": "confirmed",
                "severity": "low",
                "cvss_score": 2.1,
                "description": (
                    "O servidor expõe informações de versão nos cabeçalhos HTTP."
                ),
                "evidence": "Header: Server: nginx/1.21.3",
                "impact": (
                    "Informação de versão pode auxiliar atacantes a "
                    "identificar vulnerabilidades conhecidas."
                ),
                "likelihood": "low",
                "recommendation": "Remover ou ofuscar o cabeçalho Server.",
                "references": [],
            },
        ],
        "conclusion": (
            "A aplicação apresenta um nível de segurança adequado, "
            "com melhorias recomendadas na configuração de cabeçalhos HTTP "
            "e na exposição de informações do servidor."
        ),
    }


class TestValidReport(unittest.TestCase):
    """Testes para verificar que relatórios válidos passam na validação."""

    def setUp(self) -> None:
        """Configura o schema e relatório base para os testes."""
        self.schema = _load_schema()
        self.valid_report = _make_valid_report()

    def test_valid_report_passes_schema_validation(self) -> None:
        """Verifica que um relatório válido passa na validação do schema."""
        errors = validate_against_schema(self.valid_report, self.schema)
        self.assertEqual(errors, [], f"Relatório válido gerou erros: {errors}")

    def test_valid_report_passes_full_validation(self) -> None:
        """Verifica que um relatório válido passa na validação completa."""
        errors, warnings = validate_report(self.valid_report, schema=self.schema)
        self.assertEqual(errors, [], f"Relatório válido gerou erros: {errors}")


class TestMissingRequiredFields(unittest.TestCase):
    """Testes para verificar que campos obrigatórios ausentes são detectados."""

    def setUp(self) -> None:
        """Configura o schema para os testes."""
        self.schema = _load_schema()

    def test_missing_report_id(self) -> None:
        """Verifica que ausência de report_id gera erro de schema."""
        report = _make_valid_report()
        del report["report_id"]

        errors = validate_against_schema(report, self.schema)
        self.assertTrue(len(errors) > 0, "Deveria rejeitar sem report_id.")

    def test_missing_executive_summary(self) -> None:
        """Verifica que ausência de executive_summary gera erro de schema."""
        report = _make_valid_report()
        del report["executive_summary"]

        errors = validate_against_schema(report, self.schema)
        self.assertTrue(len(errors) > 0, "Deveria rejeitar sem executive_summary.")

    def test_missing_conclusion(self) -> None:
        """Verifica que ausência de conclusion gera erro de schema."""
        report = _make_valid_report()
        del report["conclusion"]

        errors = validate_against_schema(report, self.schema)
        self.assertTrue(len(errors) > 0, "Deveria rejeitar sem conclusion.")

    def test_missing_methodology(self) -> None:
        """Verifica que ausência de methodology gera erro de schema."""
        report = _make_valid_report()
        del report["methodology"]

        errors = validate_against_schema(report, self.schema)
        self.assertTrue(len(errors) > 0, "Deveria rejeitar sem methodology.")


class TestDuplicateFindingIDs(unittest.TestCase):
    """Testes para verificar que IDs duplicados de achados são detectados."""

    def test_duplicate_finding_ids_are_detected(self) -> None:
        """Verifica que finding IDs duplicados geram erro."""
        findings = [
            {
                "finding_id": "FIND-0001",
                "title": "Achado 1",
                "status": "confirmed",
                "severity": "medium",
                "description": "Desc 1",
                "evidence": "Ev 1",
                "impact": "Imp 1",
                "likelihood": "medium",
                "recommendation": "Rec 1",
            },
            {
                "finding_id": "FIND-0001",  # Duplicado!
                "title": "Achado 2",
                "status": "confirmed",
                "severity": "low",
                "description": "Desc 2",
                "evidence": "Ev 2",
                "impact": "Imp 2",
                "likelihood": "low",
                "recommendation": "Rec 2",
            },
        ]

        errors = validate_finding_ids(findings)
        self.assertTrue(
            any("duplicado" in e.lower() for e in errors),
            f"IDs duplicados deveriam ser detectados. Erros: {errors}",
        )


class TestFindingIDPattern(unittest.TestCase):
    """Testes para verificar validação do padrão de finding IDs."""

    def test_valid_finding_id_pattern(self) -> None:
        """Verifica que IDs no padrão FIND-XXXX são aceitos."""
        findings = [
            {
                "finding_id": "FIND-0001",
                "title": "Achado",
                "status": "confirmed",
                "severity": "low",
                "description": "Desc",
                "evidence": "Ev",
                "impact": "Imp",
                "likelihood": "low",
                "recommendation": "Rec",
            }
        ]

        errors = validate_finding_ids(findings)
        self.assertEqual(errors, [], f"ID válido gerou erros: {errors}")

    def test_invalid_finding_id_pattern(self) -> None:
        """Verifica que IDs fora do padrão são rejeitados."""
        findings = [
            {
                "finding_id": "VULN-001",  # Padrão errado
                "title": "Achado",
                "status": "confirmed",
                "severity": "low",
                "description": "Desc",
                "evidence": "Ev",
                "impact": "Imp",
                "likelihood": "low",
                "recommendation": "Rec",
            }
        ]

        errors = validate_finding_ids(findings)
        self.assertTrue(
            any("padrão" in e.lower() or "FIND-" in e for e in errors),
            f"ID fora do padrão deveria ser rejeitado. Erros: {errors}",
        )

    def test_finding_id_too_few_digits(self) -> None:
        """Verifica que FIND-001 (3 dígitos) é rejeitado."""
        findings = [
            {
                "finding_id": "FIND-001",
                "title": "Achado",
                "status": "confirmed",
                "severity": "low",
                "description": "Desc",
                "evidence": "Ev",
                "impact": "Imp",
                "likelihood": "low",
                "recommendation": "Rec",
            }
        ]

        errors = validate_finding_ids(findings)
        self.assertTrue(len(errors) > 0, "FIND-001 deveria ser rejeitado (3 dígitos).")


class TestSecretDetection(unittest.TestCase):
    """Testes para verificar a detecção de segredos em texto."""

    def test_detects_aws_access_key(self) -> None:
        """Verifica que chaves AWS Access Key são detectadas."""
        text = "Encontrada credencial AKIAIOSFODNN7EXAMPLE na configuração."
        warnings = detect_secrets_in_text(text)
        self.assertTrue(
            len(warnings) > 0,
            f"Chave AWS deveria ser detectada. Avisos: {warnings}",
        )

    def test_detects_jwt_token(self) -> None:
        """Verifica que tokens JWT são detectados."""
        # JWT mínimo válido (header.payload.signature)
        text = (
            "Token encontrado: "
            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
            "eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIn0."
            "SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
        )
        warnings = detect_secrets_in_text(text)
        self.assertTrue(
            len(warnings) > 0,
            f"Token JWT deveria ser detectado. Avisos: {warnings}",
        )

    def test_detects_private_key(self) -> None:
        """Verifica que chaves privadas PEM são detectadas."""
        text = (
            "Chave encontrada:\n"
            "-----BEGIN RSA PRIVATE KEY-----\n"
            "MIIEpAIBAAKCAQEA...\n"
            "-----END RSA PRIVATE KEY-----"
        )
        warnings = detect_secrets_in_text(text)
        self.assertTrue(
            len(warnings) > 0,
            f"Chave privada deveria ser detectada. Avisos: {warnings}",
        )

    def test_detects_connection_string(self) -> None:
        """Verifica que strings de conexão com credenciais são detectadas."""
        text = "Database URL: mongodb://admin:p4ssw0rd@db.example.com:27017/production"
        warnings = detect_secrets_in_text(text)
        self.assertTrue(
            len(warnings) > 0,
            f"String de conexão deveria ser detectada. Avisos: {warnings}",
        )

    def test_detects_password_pattern(self) -> None:
        """Verifica que padrões de senha são detectados."""
        text = 'Configuração: password=minha_senha_secreta'
        warnings = detect_secrets_in_text(text)
        self.assertTrue(
            len(warnings) > 0,
            f"Padrão de senha deveria ser detectado. Avisos: {warnings}",
        )

    def test_clean_text_has_no_warnings(self) -> None:
        """Verifica que texto limpo não gera avisos de segredos."""
        text = (
            "A aplicação retornou um código HTTP 200 com cabeçalhos padrão. "
            "Nenhuma informação sensível foi encontrada nos cabeçalhos de resposta."
        )
        warnings = detect_secrets_in_text(text)
        self.assertEqual(
            warnings, [],
            f"Texto limpo não deveria gerar avisos. Avisos: {warnings}",
        )

    def test_detects_ec_private_key(self) -> None:
        """Verifica que chaves privadas EC são detectadas."""
        text = "-----BEGIN EC PRIVATE KEY-----\nMHQCAQE..."
        warnings = detect_secrets_in_text(text)
        self.assertTrue(
            len(warnings) > 0,
            f"Chave EC privada deveria ser detectada. Avisos: {warnings}",
        )


class TestCVSSValidation(unittest.TestCase):
    """Testes para verificar a validação de coerência CVSS/severidade."""

    def test_consistent_cvss_score(self) -> None:
        """Verifica que pontuação CVSS consistente com severidade não gera aviso."""
        findings = [
            {
                "finding_id": "FIND-0001",
                "severity": "medium",
                "cvss_score": 5.3,
            }
        ]
        warnings = validate_cvss_severity_consistency(findings)
        self.assertEqual(
            warnings, [],
            f"CVSS consistente gerou avisos: {warnings}",
        )

    def test_inconsistent_cvss_score(self) -> None:
        """Verifica que CVSS alto com severidade baixa gera aviso."""
        findings = [
            {
                "finding_id": "FIND-0001",
                "severity": "low",
                "cvss_score": 9.8,  # Crítico, mas marcado como 'low'
            }
        ]
        warnings = validate_cvss_severity_consistency(findings)
        self.assertTrue(
            any("inconsistente" in w.lower() for w in warnings),
            f"CVSS inconsistente deveria gerar aviso. Avisos: {warnings}",
        )

    def test_no_cvss_score_no_warning(self) -> None:
        """Verifica que ausência de cvss_score não gera aviso."""
        findings = [
            {
                "finding_id": "FIND-0001",
                "severity": "medium",
            }
        ]
        warnings = validate_cvss_severity_consistency(findings)
        self.assertEqual(
            warnings, [],
            f"Ausência de CVSS não deveria gerar aviso. Avisos: {warnings}",
        )

    def test_informational_zero_cvss(self) -> None:
        """Verifica que severidade informational com CVSS 0.0 é aceito."""
        findings = [
            {
                "finding_id": "FIND-0001",
                "severity": "informational",
                "cvss_score": 0.0,
            }
        ]
        warnings = validate_cvss_severity_consistency(findings)
        self.assertEqual(
            warnings, [],
            f"Informational com CVSS 0.0 não deveria gerar aviso. Avisos: {warnings}",
        )


class TestFindingsSecretDetection(unittest.TestCase):
    """Testes para verificar detecção de segredos em achados do relatório."""

    def test_clean_evidence_passes(self) -> None:
        """Verifica que evidência limpa não gera avisos."""
        findings = [
            {
                "finding_id": "FIND-0001",
                "evidence": "Resposta HTTP 200 OK com cabeçalhos padrão.",
                "description": "Cabeçalhos de segurança ausentes na resposta.",
            }
        ]
        warnings = check_findings_for_secrets(findings)
        self.assertEqual(
            warnings, [],
            f"Evidência limpa gerou avisos: {warnings}",
        )

    def test_evidence_with_aws_key_generates_warning(self) -> None:
        """Verifica que evidência com chave AWS gera aviso."""
        findings = [
            {
                "finding_id": "FIND-0001",
                "evidence": "Config file: aws_access_key_id = AKIAIOSFODNN7EXAMPLE",
                "description": "Credencial exposta em arquivo de configuração.",
            }
        ]
        warnings = check_findings_for_secrets(findings)
        self.assertTrue(
            len(warnings) > 0,
            f"Evidência com AWS key deveria gerar aviso. Avisos: {warnings}",
        )


if __name__ == "__main__":
    unittest.main()
