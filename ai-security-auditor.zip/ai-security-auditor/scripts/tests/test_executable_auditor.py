#!/usr/bin/env python3
"""
Testes unitários para auditoria estática de executáveis (executable_auditor.py).
"""

import struct
import sys
import tempfile
import unittest
from pathlib import Path

# Adicionar scripts ao path
TESTS_DIR = Path(__file__).resolve().parent
SCRIPTS_DIR = TESTS_DIR.parent
PROJECT_ROOT = SCRIPTS_DIR.parent
sys.path.insert(0, str(SCRIPTS_DIR))

from executable_auditor import (
    IMAGE_DLLCHARACTERISTICS_DYNAMIC_BASE,
    IMAGE_DLLCHARACTERISTICS_NX_COMPAT,
    IMAGE_DOS_SIGNATURE,
    IMAGE_NT_SIGNATURE,
    audit_executable,
    extract_ascii_strings,
    parse_pe_headers,
)


def create_minimal_pe_binary(has_aslr: bool = True, has_dep: bool = True) -> bytes:
    """Gera bytes simulando uma estrutura de cabeçalho PE mínima para teste estático."""
    # 0x3C aponta para PE offset (vamos colocar em 0x80)
    pe_offset = 0x80
    data = bytearray(512)

    # DOS Header: MZ signature em offset 0
    struct.pack_into("<H", data, 0, IMAGE_DOS_SIGNATURE)
    # e_lfanew em 0x3C
    struct.pack_into("<I", data, 0x3C, pe_offset)

    # PE Signature
    struct.pack_into("<I", data, pe_offset, IMAGE_NT_SIGNATURE)

    # COFF File Header (offset pe_offset + 4)
    # Machine: x86 (0x014C), NumSections: 1, OptHeaderSize: 96
    coff_offset = pe_offset + 4
    struct.pack_into("<HHIIIHH", data, coff_offset, 0x014C, 1, 0, 0, 0, 96, 0x0102)

    # Optional Header PE32 (offset coff_offset + 20)
    opt_offset = coff_offset + 20
    # Magic PE32 (0x010B)
    struct.pack_into("<H", data, opt_offset, 0x010B)

    # Subsystem em opt_offset + 68
    struct.pack_into("<H", data, opt_offset + 68, 3)  # Console

    # DllCharacteristics em opt_offset + 70
    dll_char = 0
    if has_aslr:
        dll_char |= IMAGE_DLLCHARACTERISTICS_DYNAMIC_BASE
    if has_dep:
        dll_char |= IMAGE_DLLCHARACTERISTICS_NX_COMPAT
    struct.pack_into("<H", data, opt_offset + 70, dll_char)

    return bytes(data)


class TestExecutableAuditor(unittest.TestCase):
    """Testes para o módulo de análise estática de binários."""

    def test_extract_ascii_strings(self):
        """Verifica extração correta de strings legíveis."""
        blob = b"\x00\x00Hello_World\x00https://api.example.com/v1\x00\xff"
        strings = extract_ascii_strings(blob, min_len=4)
        self.assertIn("Hello_World", strings)
        self.assertIn("https://api.example.com/v1", strings)

    def test_parse_pe_headers_mitigations(self):
        """Testa leitura estática de flags ASLR e DEP no cabeçalho PE."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # 1. Binário com ASLR e DEP
            pe_data_safe = create_minimal_pe_binary(has_aslr=True, has_dep=True)
            safe_file = Path(tmpdir) / "safe_app.exe"
            safe_file.write_bytes(pe_data_safe)

            mitigations, notes = parse_pe_headers(safe_file)
            self.assertIsNotNone(mitigations)
            self.assertTrue(mitigations.has_aslr)
            self.assertTrue(mitigations.has_dep)

            # 2. Binário vulnerável sem ASLR e sem DEP
            pe_data_vuln = create_minimal_pe_binary(has_aslr=False, has_dep=False)
            vuln_file = Path(tmpdir) / "vuln_app.exe"
            vuln_file.write_bytes(pe_data_vuln)

            mitigations_vuln, _ = parse_pe_headers(vuln_file)
            self.assertIsNotNone(mitigations_vuln)
            self.assertFalse(mitigations_vuln.has_aslr)
            self.assertFalse(mitigations_vuln.has_dep)

    def test_audit_executable_findings_and_safety(self):
        """Auditoria completa gera achados de mitigação e strings suspeitas sem executar binário."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Executável com API suspeita embutida e sem ASLR
            raw_pe = create_minimal_pe_binary(has_aslr=False, has_dep=False)
            extra_payload = (
                b"\x00VirtualAllocEx\x00WriteProcessMemory\x00powershell.exe -enc AAAA\x00https://c2.example.org\x00"
            )
            full_data = raw_pe + extra_payload

            test_bin = Path(tmpdir) / "target.exe"
            test_bin.write_bytes(full_data)

            result = audit_executable(str(test_bin))
            self.assertEqual(result["status"], "completed")
            self.assertTrue(result["static_only"])

            finding_ids = [f["id"] for f in result["findings"]]
            # Mitigações ausentes detectadas
            self.assertIn("BIN-NO-ASLR-001", finding_ids)
            self.assertIn("BIN-NO-DEP-002", finding_ids)

            # APIs e comandos suspeitos detectados
            titles = [f["title"] for f in result["findings"]]
            self.assertTrue(any("VirtualAllocEx" in t for t in titles))
            self.assertTrue(any("WriteProcessMemory" in t for t in titles))
            self.assertTrue(any("PowerShell" in t for t in titles))

    def test_audit_executable_nonexistent_file(self):
        """Trata adequadamente arquivo não existente."""
        result = audit_executable("C:/nao_existe/arquivo.exe")
        self.assertEqual(result["status"], "error")


if __name__ == "__main__":
    unittest.main()
