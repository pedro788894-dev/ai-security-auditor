#!/usr/bin/env python3
"""
Testes automatizados para o script de verificação pré-voo (preflight).

Cobre cenários de validação de estrutura de projeto com diretórios
válidos e ausentes, e detecção de ferramentas.

Todos os testes são locais — nenhuma atividade de rede é realizada.
"""

import tempfile
import unittest
from pathlib import Path
from typing import Any, Dict, List

import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from preflight import (
    ToolStatus,
    check_project_structure,
    check_python_version,
    detect_tool,
    run_preflight,
    EXPECTED_DIRS,
    EXPECTED_FILES,
)


class TestPythonVersionCheck(unittest.TestCase):
    """Testes para verificação de versão do Python."""

    def test_python_version_is_compatible(self) -> None:
        """Verifica que a versão atual do Python é compatível (>= 3.8).

        Como este teste roda em Python 3.8+, deve sempre passar.
        """
        is_ok, version_str = check_python_version()
        self.assertTrue(
            is_ok,
            f"Versão do Python ({version_str}) deveria ser compatível.",
        )

    def test_python_version_returns_string(self) -> None:
        """Verifica que a versão retornada é uma string formatada."""
        _, version_str = check_python_version()
        parts = version_str.split(".")
        self.assertEqual(
            len(parts), 3,
            f"Versão deveria ter 3 partes (major.minor.micro): {version_str}",
        )


class TestProjectStructureValidation(unittest.TestCase):
    """Testes para validação de estrutura de diretórios do projeto."""

    def test_valid_structure_passes(self) -> None:
        """Verifica que uma estrutura de projeto completa é aceita."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_dir = Path(tmpdir)

            # Criar todos os diretórios esperados
            for dir_name in EXPECTED_DIRS:
                (project_dir / dir_name).mkdir(parents=True, exist_ok=True)

            # Criar todos os arquivos esperados
            for file_name in EXPECTED_FILES:
                file_path = project_dir / file_name
                file_path.parent.mkdir(parents=True, exist_ok=True)
                file_path.touch()

            is_ok, missing_dirs, missing_files = check_project_structure(project_dir)

            self.assertTrue(is_ok, "Estrutura completa deveria ser aceita.")
            self.assertEqual(missing_dirs, [], f"Não deveria ter diretórios ausentes: {missing_dirs}")
            self.assertEqual(missing_files, [], f"Não deveria ter arquivos ausentes: {missing_files}")

    def test_missing_directories_are_detected(self) -> None:
        """Verifica que diretórios ausentes são detectados."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_dir = Path(tmpdir)
            # Não criar nenhum diretório

            is_ok, missing_dirs, missing_files = check_project_structure(project_dir)

            self.assertFalse(is_ok, "Estrutura incompleta não deveria ser aceita.")
            self.assertTrue(
                len(missing_dirs) > 0,
                "Deveria detectar diretórios ausentes.",
            )

    def test_missing_files_are_detected(self) -> None:
        """Verifica que arquivos ausentes são detectados."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_dir = Path(tmpdir)
            # Criar apenas os diretórios, sem os arquivos
            for dir_name in EXPECTED_DIRS:
                (project_dir / dir_name).mkdir(parents=True, exist_ok=True)

            is_ok, missing_dirs, missing_files = check_project_structure(project_dir)

            self.assertFalse(is_ok, "Estrutura sem arquivos não deveria ser aceita.")
            self.assertTrue(
                len(missing_files) > 0,
                "Deveria detectar arquivos ausentes.",
            )


class TestToolDetection(unittest.TestCase):
    """Testes para detecção de ferramentas externas."""

    def test_detect_python_as_tool(self) -> None:
        """Verifica que o Python em si é detectável como ferramenta.

        Usa 'python' ou 'python3' como ferramenta de teste, já que
        sabemos que está instalada no ambiente de execução.
        """
        # Usar sys.executable para garantir que funciona
        import os

        python_name = os.path.basename(sys.executable)
        status = detect_tool("python", [sys.executable, "--version"])
        self.assertTrue(
            status.installed,
            f"Python deveria ser detectado como instalado. Status: {status}",
        )
        self.assertIsNotNone(status.version, "Versão do Python deveria ser detectada.")

    def test_nonexistent_tool_not_detected(self) -> None:
        """Verifica que uma ferramenta inexistente não é detectada."""
        status = detect_tool(
            "ferramenta_inexistente_xyz_123",
            ["ferramenta_inexistente_xyz_123", "--version"],
        )
        self.assertFalse(
            status.installed,
            "Ferramenta inexistente não deveria ser detectada.",
        )
        self.assertIsNone(status.path, "Caminho deveria ser None para ferramenta inexistente.")

    def test_tool_status_has_correct_name(self) -> None:
        """Verifica que o ToolStatus retornado tem o nome correto."""
        status = detect_tool("minha_ferramenta", ["echo", "test"])
        self.assertEqual(
            status.name, "minha_ferramenta",
            "Nome da ferramenta deveria corresponder ao informado.",
        )


class TestRunPreflight(unittest.TestCase):
    """Testes para a execução completa do preflight."""

    def test_preflight_with_nonexistent_directory(self) -> None:
        """Verifica que diretório inexistente gera problemas críticos."""
        fake_dir = Path("/caminho/inexistente/projeto_fake_xyz")
        report = run_preflight(fake_dir)

        self.assertFalse(
            report.structure_ok,
            "Estrutura com diretório inexistente não deveria ser OK.",
        )
        self.assertTrue(
            len(report.critical_issues) > 0,
            "Deveria haver problemas críticos com diretório inexistente.",
        )

    def test_preflight_report_has_tool_entries(self) -> None:
        """Verifica que o relatório de preflight inclui verificações de ferramentas."""
        with tempfile.TemporaryDirectory() as tmpdir:
            report = run_preflight(Path(tmpdir))
            self.assertTrue(
                len(report.tools) > 0,
                "Relatório deveria incluir verificações de ferramentas.",
            )


if __name__ == "__main__":
    unittest.main()
