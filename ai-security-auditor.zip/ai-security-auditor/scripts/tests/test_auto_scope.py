#!/usr/bin/env python3
"""
Testes unitários para geração e validação automática de escopo (auto_scope.py).
"""

import sys
import unittest
from pathlib import Path

# Adicionar scripts ao path
TESTS_DIR = Path(__file__).resolve().parent
SCRIPTS_DIR = TESTS_DIR.parent
PROJECT_ROOT = SCRIPTS_DIR.parent
sys.path.insert(0, str(SCRIPTS_DIR))

from auto_scope import generate_scope_from_file, generate_scope_from_url, sanitize_identifier
from validate_scope import validate_scope


class TestAutoScope(unittest.TestCase):
    """Testes para o módulo de escopo automático."""

    def test_sanitize_identifier(self):
        """Verifica higienização de identificadores."""
        self.assertEqual(sanitize_identifier("https://app.example.com/login"), "app_example_com_login")
        self.assertEqual(sanitize_identifier("my-test_app.123"), "my-test_app_123")

    def test_generate_scope_from_url_unauthorized(self):
        """URL sem autorização gera escopo em modo passive_only e limites seguros."""
        scope = generate_scope_from_url("https://meu-saas.example", authorized=False)
        self.assertEqual(scope["testing_mode"], "passive_only")
        self.assertEqual(scope["targets"][0]["identifier"], "meu-saas.example")
        self.assertFalse(scope["targets"][0]["includes_subdomains"])
        self.assertEqual(scope["constraints"]["max_requests_per_second"], 2)

        # Validação contra o schema oficial
        errors, warnings = validate_scope(scope)
        self.assertEqual(errors, [], f"Erros de validação de escopo: {errors}")

    def test_generate_scope_from_url_authorized(self):
        """URL com autorização ativa gera modo passive_and_active."""
        scope = generate_scope_from_url(
            "https://meu-saas.example:8443/login",
            authorized=True,
            authorized_by="Admin de Seguranca",
        )
        self.assertEqual(scope["testing_mode"], "passive_and_active")
        self.assertEqual(scope["authorized_by"], "Admin de Seguranca")
        self.assertEqual(scope["targets"][0]["identifier"], "meu-saas.example")
        self.assertEqual(scope["targets"][0]["ports"], [8443])
        self.assertEqual(scope["constraints"]["max_requests_per_second"], 5)

        errors, warnings = validate_scope(scope)
        self.assertEqual(errors, [], f"Erros de validação de escopo: {errors}")

    def test_scope_does_not_expand_boundaries(self):
        """Garante que o escopo proíbe explicitamente expansão de alvos a terceiros."""
        scope = generate_scope_from_url("https://app.exemplo.com", authorized=True)
        # O alvo não deve incluir subdomínios genericos
        self.assertFalse(scope["targets"][0]["includes_subdomains"])
        prohibited_str = " ".join(scope["prohibited_actions"])
        self.assertIn("terceiros", prohibited_str.lower())
        self.assertIn("força bruta irrestrita", prohibited_str.lower())

    def test_generate_scope_from_file_executable(self):
        """Gera escopo para arquivo de executável local em laboratório."""
        fake_exe = PROJECT_ROOT / "fake_app.exe"
        scope = generate_scope_from_file(str(fake_exe), file_type="application", authorized=True)
        self.assertEqual(scope["targets"][0]["type"], "application")
        self.assertEqual(scope["targets"][0]["environment"], "laboratory")
        self.assertIn("Execução direta e não isolada", " ".join(scope["prohibited_actions"]))

        errors, warnings = validate_scope(scope)
        self.assertEqual(errors, [], f"Erros de validação de escopo: {errors}")


if __name__ == "__main__":
    unittest.main()
