#!/usr/bin/env python3
"""
Validação de escopo de auditoria de segurança.

Este script carrega e valida documentos de escopo de auditoria contra o
JSON Schema definido, além de realizar validações semânticas adicionais
como verificação de datas, formatos de IP/domínio, e restrições de
segurança contra escopos excessivamente amplos.

NÃO realiza resolução de DNS ou qualquer atividade de rede.
"""

import argparse
import ipaddress
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
if sys.stderr and hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

try:
    import jsonschema
    from jsonschema import Draft7Validator, ValidationError
except ImportError:
    print(
        "ERRO: Biblioteca 'jsonschema' não encontrada. "
        "Instale com: pip install jsonschema>=4.0.0",
        file=sys.stderr,
    )
    sys.exit(1)


# Caminho padrão do schema de escopo
DEFAULT_SCHEMA_PATH = (
    Path(__file__).resolve().parent.parent / "schemas" / "scope.schema.json"
)

# Expressão regular para validação básica de domínio
# Aceita domínios válidos como "example.com", "sub.example.co.uk"
DOMAIN_REGEX = re.compile(
    r"^(?!-)[A-Za-z0-9-]{1,63}(?<!-)(\.[A-Za-z0-9-]{1,63})*\.[A-Za-z]{2,}$"
)

# Prefixos de CIDR considerados excessivamente amplos
MAX_BROAD_IPV4_PREFIX = 8   # /8 ou menor (mais amplo)
MAX_BROAD_IPV6_PREFIX = 32  # /32 ou menor para IPv6

# Domínios curinga proibidos
WILDCARD_PATTERNS = [
    r"^\*$",           # Somente "*"
    r"^\*\.\w{2,4}$",  # "*.com", "*.net", "*.org", etc.
    r"^\*\.\*",         # "*.*"
]


@property
def _compiled_wildcards() -> List[re.Pattern]:
    """Padrões de curinga compilados (cache)."""
    return [re.compile(p) for p in WILDCARD_PATTERNS]


def load_schema(schema_path: Optional[Path] = None) -> Dict[str, Any]:
    """Carrega o JSON Schema do escopo a partir do arquivo.

    Args:
        schema_path: Caminho para o arquivo de schema. Se None, usa o padrão.

    Returns:
        Dicionário com o schema carregado.

    Raises:
        FileNotFoundError: Se o arquivo de schema não for encontrado.
        json.JSONDecodeError: Se o arquivo não for um JSON válido.
    """
    path = schema_path or DEFAULT_SCHEMA_PATH
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_scope(scope_path: Path) -> Dict[str, Any]:
    """Carrega o documento de escopo a partir do arquivo JSON.

    Args:
        scope_path: Caminho para o arquivo de escopo.

    Returns:
        Dicionário com o escopo carregado.

    Raises:
        FileNotFoundError: Se o arquivo de escopo não for encontrado.
        json.JSONDecodeError: Se o arquivo não for um JSON válido.
    """
    with open(scope_path, "r", encoding="utf-8") as f:
        return json.load(f)


def validate_against_schema(
    scope_data: Dict[str, Any], schema: Dict[str, Any]
) -> List[str]:
    """Valida o documento de escopo contra o JSON Schema.

    Args:
        scope_data: Dados do escopo a serem validados.
        schema: JSON Schema para validação.

    Returns:
        Lista de erros de validação encontrados (vazia se válido).
    """
    errors: List[str] = []
    validator = Draft7Validator(schema)

    for error in sorted(validator.iter_errors(scope_data), key=lambda e: list(e.path)):
        path = ".".join(str(p) for p in error.absolute_path) or "(raiz)"
        errors.append(f"Erro de schema em '{path}': {error.message}")

    return errors


def validate_date_range(scope_data: Dict[str, Any]) -> List[str]:
    """Valida que as datas do escopo são coerentes.

    Verifica que:
    - valid_from é anterior a valid_until
    - O escopo não está expirado (valid_until não passou)

    Args:
        scope_data: Dados do escopo.

    Returns:
        Lista de erros encontrados.
    """
    errors: List[str] = []

    valid_from_str = scope_data.get("valid_from", "")
    valid_until_str = scope_data.get("valid_until", "")

    if not valid_from_str or not valid_until_str:
        return errors  # Schema validation vai pegar campos faltantes

    try:
        valid_from = datetime.fromisoformat(valid_from_str.replace("Z", "+00:00"))
    except ValueError:
        errors.append(f"Formato de data inválido em 'valid_from': {valid_from_str}")
        return errors

    try:
        valid_until = datetime.fromisoformat(valid_until_str.replace("Z", "+00:00"))
    except ValueError:
        errors.append(f"Formato de data inválido em 'valid_until': {valid_until_str}")
        return errors

    if valid_from >= valid_until:
        errors.append(
            f"A data 'valid_from' ({valid_from_str}) deve ser anterior a "
            f"'valid_until' ({valid_until_str})."
        )

    now = datetime.now(timezone.utc)
    if valid_until < now:
        errors.append(
            f"O escopo está expirado. 'valid_until' ({valid_until_str}) "
            f"é anterior ao momento atual ({now.isoformat()})."
        )

    return errors


def validate_domain(domain: str) -> List[str]:
    """Valida o formato de um domínio (sem resolução DNS).

    Verifica se o domínio segue o formato esperado e rejeita
    domínios curinga excessivamente amplos.

    Args:
        domain: String do domínio a ser validado.

    Returns:
        Lista de erros encontrados.
    """
    errors: List[str] = []

    # Verificar domínios curinga proibidos
    for pattern_str in WILDCARD_PATTERNS:
        pattern = re.compile(pattern_str)
        if pattern.match(domain):
            errors.append(
                f"Domínio curinga proibido: '{domain}'. "
                f"Domínios curinga genéricos não são permitidos no escopo."
            )
            return errors

    # Verificar formato básico do domínio (se não for curinga)
    if not domain.startswith("*."):
        if not DOMAIN_REGEX.match(domain):
            errors.append(
                f"Formato de domínio inválido: '{domain}'. "
                f"Esperado um domínio válido (ex: example.com)."
            )
    else:
        # Curinga parcial como *.example.com — validar a parte do domínio
        base_domain = domain[2:]  # Remove "*."
        if not DOMAIN_REGEX.match(base_domain):
            errors.append(
                f"Formato de domínio base inválido no curinga: '{domain}'."
            )

    return errors


def validate_ip_or_range(identifier: str, target_type: str) -> List[str]:
    """Valida endereços IP e faixas CIDR.

    Rejeita faixas CIDR excessivamente amplas (ex: /8, /0).

    Args:
        identifier: String do IP ou faixa CIDR.
        target_type: Tipo do alvo ('ip' ou 'ip_range').

    Returns:
        Lista de erros encontrados.
    """
    errors: List[str] = []

    if target_type == "ip":
        try:
            ipaddress.ip_address(identifier)
        except ValueError:
            errors.append(
                f"Endereço IP inválido: '{identifier}'. "
                f"Esperado um endereço IPv4 ou IPv6 válido."
            )
    elif target_type == "ip_range":
        try:
            network = ipaddress.ip_network(identifier, strict=False)
            # Verificar se a faixa é excessivamente ampla
            if isinstance(network, ipaddress.IPv4Network):
                if network.prefixlen <= MAX_BROAD_IPV4_PREFIX:
                    errors.append(
                        f"Faixa de IP excessivamente ampla: '{identifier}' "
                        f"(/{network.prefixlen}). Faixas /{MAX_BROAD_IPV4_PREFIX} "
                        f"ou mais amplas não são permitidas."
                    )
            elif isinstance(network, ipaddress.IPv6Network):
                if network.prefixlen <= MAX_BROAD_IPV6_PREFIX:
                    errors.append(
                        f"Faixa de IPv6 excessivamente ampla: '{identifier}' "
                        f"(/{network.prefixlen}). Faixas /{MAX_BROAD_IPV6_PREFIX} "
                        f"ou mais amplas não são permitidas."
                    )
        except ValueError:
            errors.append(
                f"Faixa de IP/CIDR inválida: '{identifier}'. "
                f"Esperado formato como 192.168.1.0/24."
            )

    return errors


def validate_targets(scope_data: Dict[str, Any]) -> List[str]:
    """Valida todos os alvos definidos no escopo.

    Verifica formato de domínios, IPs e faixas CIDR, além de
    rejeitar configurações inseguras ou excessivamente amplas.

    Args:
        scope_data: Dados do escopo.

    Returns:
        Lista de erros encontrados.
    """
    errors: List[str] = []
    targets = scope_data.get("targets", [])

    if not targets:
        errors.append("A lista de alvos ('targets') não pode estar vazia.")
        return errors

    for i, target in enumerate(targets):
        target_type = target.get("type", "")
        identifier = target.get("identifier", "")
        prefix = f"Alvo #{i + 1} ({identifier})"

        if target_type == "domain":
            domain_errors = validate_domain(identifier)
            errors.extend(f"{prefix}: {e}" for e in domain_errors)

            # Verificar se includes_subdomains está explicitamente definido
            if "includes_subdomains" not in target:
                errors.append(
                    f"{prefix}: O campo 'includes_subdomains' deve ser "
                    f"explicitamente definido para alvos do tipo 'domain'."
                )

        elif target_type in ("ip", "ip_range"):
            ip_errors = validate_ip_or_range(identifier, target_type)
            errors.extend(f"{prefix}: {e}" for e in ip_errors)

    return errors


def validate_prohibited_actions(scope_data: Dict[str, Any]) -> List[str]:
    """Valida que a lista de ações proibidas não está vazia.

    Args:
        scope_data: Dados do escopo.

    Returns:
        Lista de erros encontrados.
    """
    errors: List[str] = []
    prohibited = scope_data.get("prohibited_actions", [])

    if not prohibited:
        errors.append(
            "A lista de ações proibidas ('prohibited_actions') não pode estar vazia. "
            "Defina explicitamente as ações que NÃO devem ser executadas."
        )

    return errors


def is_target_in_scope(
    target_identifier: str,
    target_type: str,
    scope_data: Dict[str, Any],
) -> bool:
    """Verifica se um determinado alvo está dentro do escopo autorizado.

    Realiza comparação direta de identificadores e, para IPs,
    verifica se o endereço está dentro das faixas autorizadas.

    Args:
        target_identifier: Identificador do alvo a verificar.
        target_type: Tipo do alvo ('domain', 'ip', 'ip_range', etc.).
        scope_data: Dados do escopo completo.

    Returns:
        True se o alvo está no escopo, False caso contrário.
    """
    targets = scope_data.get("targets", [])

    for authorized_target in targets:
        auth_type = authorized_target.get("type", "")
        auth_id = authorized_target.get("identifier", "")

        # Correspondência direta de tipo e identificador
        if auth_type == target_type and auth_id == target_identifier:
            return True

        # Verificar se um IP está dentro de uma faixa autorizada
        if target_type == "ip" and auth_type == "ip_range":
            try:
                ip = ipaddress.ip_address(target_identifier)
                network = ipaddress.ip_network(auth_id, strict=False)
                if ip in network:
                    return True
            except ValueError:
                continue

        # Verificar subdomínios se permitido
        if target_type == "domain" and auth_type == "domain":
            includes_sub = authorized_target.get("includes_subdomains", False)
            if includes_sub and target_identifier.endswith(f".{auth_id}"):
                return True

    return False


def validate_scope(
    scope_data: Dict[str, Any],
    schema: Optional[Dict[str, Any]] = None,
    schema_path: Optional[Path] = None,
) -> Tuple[List[str], List[str]]:
    """Executa a validação completa do escopo.

    Realiza validação contra o schema JSON e todas as validações
    semânticas adicionais.

    Args:
        scope_data: Dados do escopo a serem validados.
        schema: Schema JSON carregado. Se None, será carregado do arquivo.
        schema_path: Caminho para o arquivo de schema (usado se schema é None).

    Returns:
        Tupla com (lista_de_erros, lista_de_avisos).
    """
    errors: List[str] = []
    warnings: List[str] = []

    # Carregar schema se necessário
    if schema is None:
        try:
            schema = load_schema(schema_path)
        except FileNotFoundError:
            errors.append(
                f"Arquivo de schema não encontrado: {schema_path or DEFAULT_SCHEMA_PATH}"
            )
            return errors, warnings
        except json.JSONDecodeError as e:
            errors.append(f"Erro ao decodificar o schema JSON: {e}")
            return errors, warnings

    # 1. Validação contra o schema
    schema_errors = validate_against_schema(scope_data, schema)
    errors.extend(schema_errors)

    # Se houver erros de schema, as validações semânticas podem falhar
    # Mas continuamos para fornecer feedback completo
    if schema_errors:
        warnings.append(
            "Erros de schema detectados. Validações semânticas podem ser imprecisas."
        )

    # 2. Validação de datas
    date_errors = validate_date_range(scope_data)
    errors.extend(date_errors)

    # 3. Validação de alvos
    target_errors = validate_targets(scope_data)
    errors.extend(target_errors)

    # 4. Validação de ações proibidas
    prohibited_errors = validate_prohibited_actions(scope_data)
    errors.extend(prohibited_errors)

    return errors, warnings


def print_validation_result(
    errors: List[str], warnings: List[str], scope_path: str
) -> None:
    """Imprime o resultado da validação de forma formatada.

    Args:
        errors: Lista de erros encontrados.
        warnings: Lista de avisos.
        scope_path: Caminho do arquivo de escopo validado.
    """
    separator = "=" * 60
    print(separator)
    print("  VALIDAÇÃO DE ESCOPO — AI Security Auditor")
    print(separator)
    print(f"  Arquivo: {scope_path}")
    print()

    if errors:
        print(f"[ERROS] ({len(errors)} encontrado(s))")
        for i, error in enumerate(errors, 1):
            print(f"  {i}. ❌ {error}")
        print()

    if warnings:
        print(f"[AVISOS] ({len(warnings)} encontrado(s))")
        for i, warning in enumerate(warnings, 1):
            print(f"  {i}. ⚠️  {warning}")
        print()

    print(separator)
    if errors:
        print(f"  RESULTADO: ❌ Escopo INVÁLIDO ({len(errors)} erro(s)).")
    else:
        status = "com avisos" if warnings else "sem problemas"
        print(f"  RESULTADO: ✅ Escopo VÁLIDO ({status}).")
    print(separator)


def main() -> int:
    """Ponto de entrada principal do script de validação de escopo.

    Analisa os argumentos, carrega e valida o escopo, exibindo
    o resultado formatado e retornando código de saída apropriado.

    Returns:
        0 se o escopo é válido, 1 se há erros.
    """
    parser = argparse.ArgumentParser(
        description="Validação de escopo de auditoria de segurança.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Exemplos de uso:\n"
            "  python validate_scope.py --scope-file escopo.json\n"
        ),
    )
    parser.add_argument(
        "--scope-file",
        type=str,
        required=True,
        help="Caminho para o arquivo JSON de escopo a ser validado.",
    )
    parser.add_argument(
        "--schema-file",
        type=str,
        default=None,
        help="Caminho para o arquivo JSON Schema (opcional).",
    )

    args = parser.parse_args()

    scope_path = Path(args.scope_file)
    schema_path = Path(args.schema_file) if args.schema_file else None

    # Carregar o escopo
    try:
        scope_data = load_scope(scope_path)
    except FileNotFoundError:
        print(f"ERRO: Arquivo de escopo não encontrado: {scope_path}", file=sys.stderr)
        return 1
    except json.JSONDecodeError as e:
        print(f"ERRO: JSON inválido no arquivo de escopo: {e}", file=sys.stderr)
        return 1

    # Validar
    errors, warnings = validate_scope(scope_data, schema_path=schema_path)

    # Exibir resultado
    print_validation_result(errors, warnings, str(scope_path))

    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
