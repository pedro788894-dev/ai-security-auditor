#!/usr/bin/env python3
"""
Auditor Estático de Executáveis e Binários — AI Security Auditor.

Realiza análise estática segura de arquivos executáveis (PE/Windows .exe, .dll,
scripts e binários) sem executar arquivos desconhecidos no sistema hospedeiro.

Inspeções realizadas:
1. Metadados e cabeçalhos binários (arquitetura, seções, timestamps).
2. Mitigações de segurança do compilador:
   - ASLR (Address Space Layout Randomization / Dynamic Base)
   - DEP / NX (Data Execution Prevention / No-Execute)
   - High Entropy VA (64-bit ASLR)
   - SafeSEH (Structured Exception Handling)
   - Control Flow Guard (CFG)
   - Assinatura digital (Authenticode)
3. Extração e análise estática de strings:
   - URLs, IPs, strings de conexão
   - Chaves de API, senhas e segredos embutidos
   - Comandos suspeitos (powershell, cmd, bash)
4. Detecção de APIs e bibliotecas importadas potencialmente perigosas:
   - Comunicação de rede
   - Injeção de processo e manipulação de memória
   - Keylogging e ganchos de sistema (hooks)
   - Acesso a credenciais e registro

SALVAGUARDA: O binário NUNCA é executado automaticamente.
"""

import hashlib
import os
import re
import struct
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
if sys.stderr and hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# Constantes PE (Portable Executable)
IMAGE_DOS_SIGNATURE = 0x5A4D  # "MZ"
IMAGE_NT_SIGNATURE = 0x00004550  # "PE\0\0"

# DllCharacteristics flags
IMAGE_DLLCHARACTERISTICS_HIGH_ENTROPY_VA = 0x0020
IMAGE_DLLCHARACTERISTICS_DYNAMIC_BASE = 0x0040  # ASLR
IMAGE_DLLCHARACTERISTICS_NX_COMPAT = 0x0100     # DEP / NX
IMAGE_DLLCHARACTERISTICS_NO_SEH = 0x0400        # Sem SEH (SafeSEH implícito)
IMAGE_DLLCHARACTERISTICS_GUARD_CF = 0x4000      # Control Flow Guard

# APIs e palavras-chave de risco
SUSPICIOUS_APIS: Dict[str, Tuple[str, str]] = {
    # Injeção e manipulação de memória
    "VirtualAllocEx": ("Injeção de Código / Memória", "high"),
    "WriteProcessMemory": ("Manipulação de Memória de Processo Remoto", "critical"),
    "CreateRemoteThread": ("Injeção de Thread em Outro Processo", "critical"),
    "QueueUserAPC": ("Técnica de Execução APC em Threads", "high"),
    "SetThreadContext": ("Manipulação de Contexto de Thread (Process Hollowing)", "critical"),
    "NtUnmapViewOfSection": ("Desmapeamento de Seção (Process Hollowing)", "critical"),
    # Spyware / Ganchos
    "SetWindowsHookExA": ("Instalação de Hook Global no Windows (Keylogger/Spyware)", "high"),
    "SetWindowsHookExW": ("Instalação de Hook Global no Windows (Keylogger/Spyware)", "high"),
    "GetAsyncKeyState": ("Captura de Teclas em Tempo Real (Keylogger)", "high"),
    "BitBlt": ("Captura de Tela (Screen Capture)", "medium"),
    # Rede
    "WSAStartup": ("Inicialização de Sockets de Rede (Winsock)", "low"),
    "InternetOpenA": ("Conexão HTTP/Internet (WinINet)", "medium"),
    "HttpSendRequestA": ("Envio de Requisição HTTP (WinINet)", "medium"),
    "URLDownloadToFileA": ("Download Direto de Arquivo da Web", "high"),
    # Credenciais
    "SamIConnect": ("Acesso à Base SAM de Contas e Senhas", "critical"),
    "CryptUnprotectData": ("Descriptografia de Dados Protegidos do Windows (DPAPI)", "high"),
    "LsaRetrievePrivateData": ("Leitura de Segredos LSA do Sistema", "critical"),
}


@dataclass
class PEMitigations:
    """Status de mitigações de segurança do binário PE."""
    has_aslr: bool = False
    has_dep: bool = False
    has_high_entropy_va: bool = False
    has_safe_seh: bool = False
    has_control_flow_guard: bool = False
    is_signed: bool = False
    machine_type: str = "Desconhecido"
    subsystem: str = "Desconhecido"


def extract_ascii_strings(data: bytes, min_len: int = 4) -> List[str]:
    """Extrai strings ASCII legíveis de dados binários."""
    pattern = re.compile(rb"[A-Za-z0-9/\-:._?&=#%@$!~*+ ]{" + str(min_len).encode() + rb",}")
    matches = pattern.findall(data)
    results = []
    for m in matches:
        try:
            s = m.decode("ascii").strip()
            if len(s) >= min_len:
                results.append(s)
        except UnicodeDecodeError:
            pass
    return results


def extract_unicode_strings(data: bytes, min_len: int = 4) -> List[str]:
    """Extrai strings UTF-16 LE comuns em binários Windows."""
    pattern = re.compile(rb"(?:[A-Za-z0-9/\-:._?&=#%@$!~*+ ]\x00){" + str(min_len).encode() + rb",}")
    matches = pattern.findall(data)
    results = []
    for m in matches:
        try:
            s = m.decode("utf-16le").strip()
            if len(s) >= min_len:
                results.append(s)
        except UnicodeDecodeError:
            pass
    return results


def parse_pe_headers(file_path: Path) -> Tuple[Optional[PEMitigations], List[str]]:
    """Analisa os cabeçalhos PE de um executável Windows sem executá-lo."""
    notes: List[str] = []
    try:
        with open(file_path, "rb") as f:
            data = f.read(4096)
    except Exception as e:
        return None, [f"Erro ao ler arquivo: {e}"]

    if len(data) < 64:
        return None, ["Arquivo muito pequeno para conter cabeçalho PE"]

    # Verificar cabeçalho DOS (MZ)
    dos_sig = struct.unpack_from("<H", data, 0)[0]
    if dos_sig != IMAGE_DOS_SIGNATURE:
        return None, ["Não é um executável com cabeçalho DOS (MZ)"]

    # Offset para o cabeçalho PE (e_lfanew em 0x3C)
    pe_offset = struct.unpack_from("<I", data, 0x3C)[0]
    if pe_offset + 24 > len(data):
        return None, ["Offset do cabeçalho PE fora do intervalo lido"]

    # Assinatura PE
    pe_sig = struct.unpack_from("<I", data, pe_offset)[0]
    if pe_sig != IMAGE_NT_SIGNATURE:
        return None, ["Assinatura PE inválida"]

    # Cabeçalho COFF (File Header)
    coff_offset = pe_offset + 4
    machine, num_sections, time_date_stamp, ptr_symbols, num_symbols, opt_header_size, characteristics = (
        struct.unpack_from("<HHIIIHH", data, coff_offset)
    )

    machine_names = {
        0x014C: "Intel 386 (x86 32-bit)",
        0x8664: "AMD64 (x64 64-bit)",
        0x01C0: "ARM Little-Endian",
        0xAA64: "ARM64 Little-Endian",
    }
    machine_type = machine_names.get(machine, f"Outro (0x{machine:04X})")

    # Optional Header
    opt_offset = coff_offset + 20
    if opt_header_size == 0 or opt_offset + opt_header_size > len(data):
        return PEMitigations(machine_type=machine_type), notes

    opt_magic = struct.unpack_from("<H", data, opt_offset)[0]
    is_64bit = opt_magic == 0x020B  # PE32+
    is_32bit = opt_magic == 0x010B  # PE32

    # Offset de DllCharacteristics
    # PE32: offset 70 dentro do Optional Header
    # PE32+: offset 70 dentro do Optional Header
    dll_char_offset = opt_offset + 70
    dll_characteristics = struct.unpack_from("<H", data, dll_char_offset)[0]

    # Subsystem (offset 68)
    subsystem_val = struct.unpack_from("<H", data, opt_offset + 68)[0]
    subsystems = {1: "Driver Nativo", 2: "Windows GUI", 3: "Windows CUI (Console)", 7: "POSIX CUI"}
    subsystem_str = subsystems.get(subsystem_val, f"Subsystem-{subsystem_val}")

    mitigations = PEMitigations(
        has_aslr=bool(dll_characteristics & IMAGE_DLLCHARACTERISTICS_DYNAMIC_BASE),
        has_dep=bool(dll_characteristics & IMAGE_DLLCHARACTERISTICS_NX_COMPAT),
        has_high_entropy_va=bool(dll_characteristics & IMAGE_DLLCHARACTERISTICS_HIGH_ENTROPY_VA),
        has_safe_seh=bool(dll_characteristics & IMAGE_DLLCHARACTERISTICS_NO_SEH),
        has_control_flow_guard=bool(dll_characteristics & IMAGE_DLLCHARACTERISTICS_GUARD_CF),
        machine_type=machine_type,
        subsystem=subsystem_str,
    )

    # Verificar diretório de segurança (Certificado / Authenticode)
    # RVA e tamanho do Security Directory:
    # PE32: Optional Header offset 128 (8 bytes)
    # PE32+: Optional Header offset 144 (8 bytes)
    cert_dir_offset = opt_offset + (144 if is_64bit else 128)
    if cert_dir_offset + 8 <= len(data):
        cert_rva, cert_size = struct.unpack_from("<II", data, cert_dir_offset)
        if cert_size > 0:
            mitigations.is_signed = True

    return mitigations, notes


def audit_executable(file_path_str: str) -> Dict[str, Any]:
    """Realiza a auditoria estática completa de um executável."""
    file_path = Path(file_path_str).resolve()
    if not file_path.exists() or not file_path.is_file():
        return {
            "status": "error",
            "error": f"Arquivo não encontrado ou inacessível: {file_path_str}",
            "findings": [],
        }

    file_size = file_path.stat().st_size
    file_name = file_path.name

    # Hashes criptográficos
    sha256 = hashlib.sha256()
    md5 = hashlib.md5()
    with open(file_path, "rb") as f:
        while chunk := f.read(65536):
            sha256.update(chunk)
            md5.update(chunk)

    file_sha256 = sha256.hexdigest()
    file_md5 = md5.hexdigest()

    findings: List[Dict[str, Any]] = []

    # 1. Análise de Cabeçalhos e Mitigações PE
    mitigations, pe_notes = parse_pe_headers(file_path)

    if mitigations:
        # Avaliar falhas de mitigação
        if not mitigations.has_aslr:
            findings.append({
                "id": "BIN-NO-ASLR-001",
                "title": "Executável compilado sem ASLR (Address Space Layout Randomization)",
                "severity": "medium",
                "file": file_name,
                "line": 0,
                "evidence": f"DllCharacteristics não possui flag IMAGE_DLLCHARACTERISTICS_DYNAMIC_BASE (0x0040)",
                "description": (
                    "O binário não foi compilado com suporte a ASLR. Seus módulos são carregados em endereços fixos, "
                    "facilitando ataques de corrupção de memória e exploração de buffer overflow (ROP/shellcode)."
                ),
                "recommendation": "Recompilar o executável com a flag de linker /DYNAMICBASE habilitada.",
                "cwe_id": "CWE-119",
            })

        if not mitigations.has_dep:
            findings.append({
                "id": "BIN-NO-DEP-002",
                "title": "Executável compilado sem proteção DEP / NX (Data Execution Prevention)",
                "severity": "high",
                "file": file_name,
                "line": 0,
                "evidence": f"DllCharacteristics não possui flag IMAGE_DLLCHARACTERISTICS_NX_COMPAT (0x0100)",
                "description": (
                    "O binário não possui compatibilidade com DEP/NX. Áreas de memória como pilha e heap "
                    "podem ser marcadas como executáveis, permitindo execução direta de payloads injetados."
                ),
                "recommendation": "Recompilar com a flag de linker /NXCOMPAT habilitada.",
                "cwe_id": "CWE-119",
            })

        if not mitigations.is_signed:
            findings.append({
                "id": "BIN-UNSIGNED-003",
                "title": "Executável sem assinatura digital (Authenticode)",
                "severity": "low",
                "file": file_name,
                "line": 0,
                "evidence": "Tabela de certificados de segurança (IMAGE_DIRECTORY_ENTRY_SECURITY) vazia ou ausente",
                "description": (
                    "O aplicativo não possui assinatura de código válida. Dificulta a validação de procedência "
                    "e integridade pelo sistema operacional e por defesas de endpoint."
                ),
                "recommendation": "Assinar o executável com certificado digital válido da organização via SignTool.",
                "cwe_id": "CWE-347",
            })

    # 2. Extração e Análise Estática de Strings
    with open(file_path, "rb") as f:
        # Ler até 10 MB para análise de strings para manter agilidade
        sample_bytes = f.read(10 * 1024 * 1024)

    ascii_strings = extract_ascii_strings(sample_bytes)
    unicode_strings = extract_unicode_strings(sample_bytes)
    all_strings = set(ascii_strings + unicode_strings)

    # Buscar URLs embutidas
    url_pattern = re.compile(r"https?://[a-zA-Z0-9_\-\.]+(?::\d+)?(?:/[^\s\"'<>{}|\\^`]+)?", re.IGNORECASE)
    discovered_urls: Set[str] = set()
    for s in all_strings:
        found = url_pattern.findall(s)
        for u in found:
            # Filtrar URLs de namespaces de schema XML padrão
            if not any(ign in u for ign in ["schemas.microsoft.com", "w3.org", "purl.org"]):
                discovered_urls.add(u)

    if discovered_urls:
        findings.append({
            "id": f"BIN-HARDCODED-URLS-{len(findings) + 1:03d}",
            "title": f"URLs e endpoints externos identificados no binário ({len(discovered_urls)} detectadas)",
            "severity": "informational",
            "file": file_name,
            "line": 0,
            "evidence": ", ".join(list(discovered_urls)[:5]) + ("..." if len(discovered_urls) > 5 else ""),
            "description": (
                "Foram encontradas URLs em texto plano no binário. Podem representar serviços de telemetria, "
                "APIs de backend ou canais de comunicação remota."
            ),
            "recommendation": "Verificar se todos os endpoints pertencem à infraestrutura autorizada da aplicação.",
            "cwe_id": "CWE-200",
        })

    # Buscar APIs suspeitas presentes nas strings/tabela de importação
    detected_suspicious_apis: Dict[str, Tuple[str, str]] = {}
    for s in all_strings:
        if s in SUSPICIOUS_APIS:
            detected_suspicious_apis[s] = SUSPICIOUS_APIS[s]

    if detected_suspicious_apis:
        for api_name, (desc, sev) in list(detected_suspicious_apis.items())[:5]:
            findings.append({
                "id": f"BIN-SUSPICIOUS-API-{len(findings) + 1:03d}",
                "title": f"Referência a API sensível no binário: {api_name}",
                "severity": sev,
                "file": file_name,
                "line": 0,
                "evidence": f"API detectada: {api_name} ({desc})",
                "description": (
                    f"O binário faz referência à API '{api_name}', associada a: {desc}. "
                    "Se o software não tiver propósito administrativo legítimo, esta API pode indicar "
                    "capacidades furtivas ou intrusivas."
                ),
                "recommendation": (
                    "Revisar a necessidade técnica desta chamada de sistema. Se a observação dinâmica "
                    "for necessária, executar exclusivamente em sandbox isolado com monitoramento de chamadas."
                ),
                "cwe_id": "CWE-250",
            })

    # Buscar comandos suspeitos embutidos (PowerShell / CMD)
    cmd_pattern = re.compile(r"(?:powershell(?:\.exe)?\s+-(?:enc|nop|w\s+hidden)|cmd(?:\.exe)?\s+/c)", re.IGNORECASE)
    for s in all_strings:
        if cmd_pattern.search(s):
            findings.append({
                "id": f"BIN-SHELL-EXEC-{len(findings) + 1:03d}",
                "title": "Linha de comando shell/PowerShell suspeita embutida no binário",
                "severity": "high",
                "file": file_name,
                "line": 0,
                "evidence": s[:120],
                "description": "O binário contém strings de invocação oculta de shell ou execução codificada.",
                "recommendation": "Evitar invocações diretas de shell de comando em binários; usar APIs nativas.",
                "cwe_id": "CWE-78",
            })
            break

    return {
        "status": "completed",
        "file_name": file_name,
        "file_size_bytes": file_size,
        "sha256": file_sha256,
        "md5": file_md5,
        "mitigations": asdict(mitigations) if mitigations else None,
        "findings_count": len(findings),
        "findings": findings,
        "static_only": True,
        "limitations": [
            "Análise estática estritamente segura sem execução de binários desconhecidos.",
            "Para observação dinâmica em tempo de execução, utilize um ambiente de sandbox isolado "
            "com consentimento explícito e sem acesso a credenciais ou redes corporativas.",
        ],
    }
