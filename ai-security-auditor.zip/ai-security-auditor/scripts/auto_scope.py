#!/usr/bin/env python3
"""
Geração e validação automática de escopo de auditoria.

Permite que agentes e usuários iniciem auditorias informando apenas uma URL,
caminho de executável ou diretório de código-fonte, sem a necessidade de criar
manualmente um arquivo JSON de escopo.

Garante os princípios fundamentais:
- Restrição estrita ao alvo especificado (sem ampliação para terceiros ou subdomínios não autorizados).
- Autorização explícita necessária para testes ativos; sem autorização, define modo passivo.
- Definição automática de limites operacionais conservadores.
"""

import argparse
import json
import os
import re
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
if sys.stderr and hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# Importar validador de escopo existente
try:
    from scripts.validate_scope import validate_scope
except ImportError:
    try:
        from validate_scope import validate_scope
    except ImportError:
        validate_scope = None


def sanitize_identifier(target: str) -> str:
    """Higieniza o identificador para uso em nomes de arquivo e IDs."""
    target = re.sub(r"^https?://", "", target.strip(), flags=re.IGNORECASE)
    sanitized = re.sub(r"[^a-zA-Z0-9_-]", "_", target)
    return re.sub(r"_+", "_", sanitized)[:32].strip("_")


def generate_scope_from_url(
    url: str,
    authorized: bool = False,
    authorized_by: str = "Solicitante da Auditoria",
    contact_email: str = "security@example.com",
    contact_name: str = "Responsável de Segurança",
    duration_hours: int = 4,
    notes: Optional[str] = None,
) -> Dict[str, Any]:
    """Gera um documento de escopo válido a partir de uma URL.

    Regra estrita: O escopo limita-se exclusivamente ao domínio/host fornecido.
    Não amplia para subdomínios, CDNs ou serviços terceiros.
    """
    url_clean = url.strip()
    if not re.match(r"^https?://", url_clean, re.IGNORECASE):
        url_clean = f"https://{url_clean}"

    parsed = urlparse(url_clean)
    hostname = parsed.hostname or ""
    if not hostname:
        raise ValueError(f"Não foi possível extrair um hostname válido da URL: {url}")

    port = parsed.port
    if not port:
        port = 443 if parsed.scheme == "https" else 80

    protocol = parsed.scheme.lower()
    now = datetime.now(timezone.utc)
    until = now + timedelta(hours=duration_hours)
    date_str = now.strftime("%Y-%m-%d")
    audit_id = f"AUD-{now.strftime('%Y%m%d')}-{sanitize_identifier(hostname)}"

    target_type = "saas" if any(k in hostname for k in ["app.", "saas", "cloud"]) else "domain"

    target_entry = {
        "type": target_type,
        "identifier": hostname,
        "description": f"Alvo URL: {url_clean} (estritamente restrito a este host)",
        "includes_subdomains": False,
        "protocols": [protocol],
        "ports": [port],
        "environment": "production",
    }

    testing_mode = "passive_and_active" if authorized else "passive_only"

    prohibited_actions = [
        "Negação de serviço (DoS/DDoS) e testes de estresse de infraestrutura",
        "Modificação, exclusão ou corrupção de dados e configurações no sistema",
        "Força bruta irrestrita de senhas e ataques com wordlists massivas em contas reais",
        "Rotação de proxies ou técnicas de evasão de defesas e bloqueios",
        "Testes em domínios ou serviços de terceiros, gateways de pagamento e provedores de autenticação externa",
        "Acesso ou exfiltração de dados pessoais (PII) ou credenciais de usuários reais",
    ]

    scope_data = {
        "audit_id": audit_id,
        "audit_name": f"Auditoria de Segurança — {hostname}",
        "authorized_by": authorized_by if authorized else "Pendente de Autorização (Modo Passivo)",
        "authorization_date": date_str,
        "valid_from": now.isoformat(),
        "valid_until": until.isoformat(),
        "contact": {
            "name": contact_name,
            "email": contact_email,
            "role": "Responsável pela Auditoria",
        },
        "targets": [target_entry],
        "constraints": {
            "max_requests_per_second": 5 if authorized else 2,
            "max_duration_minutes": duration_hours * 60,
            "allowed_hours": "00:00-23:59",
            "concurrent_connections": 2,
        },
        "prohibited_actions": prohibited_actions,
        "testing_mode": testing_mode,
        "notes": notes
        or (
            f"Escopo gerado automaticamente para o alvo {hostname}. "
            f"Autorização ativa: {'SIM' if authorized else 'NÃO (restringido a modo passivo)'}."
        ),
    }

    return scope_data


def generate_scope_from_file(
    file_path: str,
    file_type: str = "application",
    authorized: bool = True,
    authorized_by: str = "Auditor Local",
    contact_email: str = "security-audit@local.internal",
    contact_name: str = "Auditor de Código",
    notes: Optional[str] = None,
) -> Dict[str, Any]:
    """Gera um documento de escopo válido a partir de um executável ou diretório de código.

    Para executáveis e arquivos locais, a auditoria é prioritariamente estática
    sem executar binários desconhecidos no sistema hospedeiro.
    """
    path_obj = Path(file_path).resolve()
    target_name = path_obj.name
    now = datetime.now(timezone.utc)
    until = now + timedelta(days=1)
    date_str = now.strftime("%Y-%m-%d")
    audit_id = f"AUD-{now.strftime('%Y%m%d')}-{sanitize_identifier(target_name)}"

    actual_target_type = "repository" if path_obj.is_dir() else "application"

    target_entry = {
        "type": actual_target_type,
        "identifier": str(path_obj),
        "description": f"Arquivo/Diretório local: {target_name} (análise estática e segura)",
        "includes_subdomains": False,
        "environment": "laboratory",
    }

    testing_mode = "passive_only" if not authorized else "active_authorized"

    prohibited_actions = [
        "Execução direta e não isolada de binários desconhecidos no sistema operacional hospedeiro",
        "Modificação ou sobreposição de arquivos de código ou binários originais",
        "Envio de telemetria ou dados confidenciais para servidores externos não autorizados",
        "Exfiltração de chaves criptográficas, credenciais ou dados pessoais encontrados",
    ]

    scope_data = {
        "audit_id": audit_id,
        "audit_name": f"Auditoria de Segurança — {target_name}",
        "authorized_by": authorized_by,
        "authorization_date": date_str,
        "valid_from": now.isoformat(),
        "valid_until": until.isoformat(),
        "contact": {
            "name": contact_name,
            "email": contact_email,
            "role": "Auditor Local de Segurança",
        },
        "targets": [target_entry],
        "constraints": {
            "max_requests_per_second": 10,
            "max_duration_minutes": 120,
            "allowed_hours": "00:00-23:59",
            "concurrent_connections": 1,
        },
        "prohibited_actions": prohibited_actions,
        "testing_mode": testing_mode,
        "notes": notes
        or (
            f"Escopo local gerado para {target_name}. "
            "Análise estática de segurança e permissões de dados."
        ),
    }

    return scope_data


def save_scope(scope_data: Dict[str, Any], output_path: Optional[Path] = None) -> Path:
    """Salva os dados de escopo em arquivo JSON temporário ou especificado."""
    if output_path is None:
        audit_id = scope_data.get("audit_id", "audit")
        output_path = Path.cwd() / f".scope_{audit_id}.json"

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(scope_data, f, indent=2, ensure_ascii=False)

    return output_path


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Geração automática de configuração de escopo para auditoria.",
    )
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--url", type=str, help="URL do site ou SaaS alvo (ex: https://meu-saas.example)")
    group.add_argument("--file", type=str, help="Caminho do executável ou arquivo binário local")
    group.add_argument("--code", type=str, help="Caminho do diretório de código-fonte")

    parser.add_argument("--authorized", action="store_true", help="Confirmação explícita de autorização para testes ativos")
    parser.add_argument("--authorized-by", type=str, default="Solicitante da Auditoria", help="Nome do responsável pela autorização")
    parser.add_argument("--contact-email", type=str, default="security@example.com", help="Email do contato")
    parser.add_argument("--output", type=str, default=None, help="Caminho do arquivo JSON de saída")
    parser.add_argument("--validate", action="store_true", help="Valida o escopo gerado com o validador oficial")

    args = parser.parse_args()

    if args.url:
        scope = generate_scope_from_url(
            url=args.url,
            authorized=args.authorized,
            authorized_by=args.authorized_by,
            contact_email=args.contact_email,
        )
    elif args.file:
        scope = generate_scope_from_file(
            file_path=args.file,
            file_type="application",
            authorized=args.authorized,
            authorized_by=args.authorized_by,
            contact_email=args.contact_email,
        )
    elif args.code:
        scope = generate_scope_from_file(
            file_path=args.code,
            file_type="repository",
            authorized=args.authorized,
            authorized_by=args.authorized_by,
            contact_email=args.contact_email,
        )

    out_path = Path(args.output) if args.output else None
    saved_path = save_scope(scope, out_path)
    print(f"[+] Escopo gerado com sucesso: {saved_path}")
    print(f"[*] Modo de teste: {scope['testing_mode']}")
    print(f"[*] Alvo: {scope['targets'][0]['identifier']} ({scope['targets'][0]['type']})")

    if args.validate and validate_scope:
        errors, warnings = validate_scope(scope)
        if errors:
            print(f"[-] Erros de validação de escopo: {errors}", file=sys.stderr)
            return 1
        print("[+] Validação de escopo aprovada com sucesso.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
