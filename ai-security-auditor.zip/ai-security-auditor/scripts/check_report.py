#!/usr/bin/env python3
"""
Validação de relatórios de auditoria de segurança.

Este script carrega e valida documentos de relatório de auditoria contra o
JSON Schema definido, verifica unicidade de IDs de achados, detecta
potenciais segredos não sanitizados em evidências/descrições, e valida
coerência entre pontuações CVSS e níveis de severidade.

NÃO realiza atividade de rede.
"""

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
if sys.stderr and hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

try:
    import jsonschema
    from jsonschema import Draft7Validator
except ImportError:
    print(
        "ERRO: Biblioteca 'jsonschema' não encontrada. "
        "Instale com: pip install jsonschema>=4.0.0",
        file=sys.stderr,
    )
    sys.exit(1)


# Caminho padrão do schema de relatório
DEFAULT_SCHEMA_PATH = (
    Path(__file__).resolve().parent.parent / "schemas" / "report.schema.json"
)

# Padrão de ID de achado
FINDING_ID_PATTERN = re.compile(r"^FIND-\d{4}$")

# ============================================================
# Padrões de regex para detecção de segredos / dados sensíveis
# ============================================================

SECRET_PATTERNS: Dict[str, re.Pattern] = {
    "Chave AWS Access Key": re.compile(r"AKIA[0-9A-Z]{16}"),
    "Chave de API genérica (hex longo)": re.compile(
        r"(?:api[_-]?key|apikey|api[_-]?secret)\s*[:=]\s*['\"]?[A-Za-z0-9]{20,}['\"]?",
        re.IGNORECASE,
    ),
    "Senha em padrão comum": re.compile(
        r"(?:password|passwd|pwd|senha)\s*[:=]\s*['\"]?[^\s'\"]{4,}['\"]?",
        re.IGNORECASE,
    ),
    "Token JWT": re.compile(
        r"eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}"
    ),
    "Chave privada (PEM)": re.compile(
        r"-----BEGIN\s+(?:RSA\s+|EC\s+|DSA\s+|OPENSSH\s+)?PRIVATE\s+KEY-----"
    ),
    "String de conexão com credenciais": re.compile(
        r"(?:mongodb|mysql|postgresql|postgres|sqlserver|mssql|redis)"
        r"://[^:]+:[^@]+@[^\s]+",
        re.IGNORECASE,
    ),
}

# Mapeamento de severidade para faixas de CVSS esperadas
SEVERITY_CVSS_RANGES: Dict[str, Tuple[float, float]] = {
    "critical": (9.0, 10.0),
    "high": (7.0, 8.9),
    "medium": (4.0, 6.9),
    "low": (0.1, 3.9),
    "informational": (0.0, 0.0),
}


def load_schema(schema_path: Optional[Path] = None) -> Dict[str, Any]:
    """Carrega o JSON Schema do relatório a partir do arquivo.

    Args:
        schema_path: Caminho para o arquivo de schema. Se None, usa o padrão.

    Returns:
        Dicionário com o schema carregado.

    Raises:
        FileNotFoundError: Se o arquivo de schema não for encontrado.
        json.JSONDecodeError: Se o arquivo não for um JSON válido.
    """
    path = schema_path or DEFAULT_SCHEMA_PATH
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_report(report_path: Path) -> Dict[str, Any]:
    """Carrega o documento de relatório a partir do arquivo JSON.

    Args:
        report_path: Caminho para o arquivo de relatório.

    Returns:
        Dicionário com o relatório carregado.

    Raises:
        FileNotFoundError: Se o arquivo não for encontrado.
        json.JSONDecodeError: Se o arquivo não for um JSON válido.
    """
    with open(report_path, "r", encoding="utf-8") as f:
        return json.load(f)


def validate_against_schema(
    report_data: Dict[str, Any], schema: Dict[str, Any]
) -> List[str]:
    """Valida o documento de relatório contra o JSON Schema.

    Args:
        report_data: Dados do relatório a serem validados.
        schema: JSON Schema para validação.

    Returns:
        Lista de erros de validação encontrados.
    """
    errors: List[str] = []
    validator = Draft7Validator(schema)

    for error in sorted(validator.iter_errors(report_data), key=lambda e: list(e.path)):
        path = ".".join(str(p) for p in error.absolute_path) or "(raiz)"
        errors.append(f"Erro de schema em '{path}': {error.message}")

    return errors


def validate_finding_ids(findings: List[Dict[str, Any]]) -> List[str]:
    """Valida que os IDs de achados são únicos e seguem o padrão FIND-XXXX.

    Args:
        findings: Lista de achados do relatório.

    Returns:
        Lista de erros encontrados.
    """
    errors: List[str] = []
    seen_ids: Dict[str, int] = {}

    for i, finding in enumerate(findings):
        finding_id = finding.get("finding_id", "")
        prefix = f"Achado #{i + 1}"

        # Verificar padrão do ID
        if finding_id and not FINDING_ID_PATTERN.match(finding_id):
            errors.append(
                f"{prefix}: ID '{finding_id}' não segue o padrão esperado "
                f"'FIND-XXXX' (4 dígitos numéricos)."
            )

        # Verificar duplicidade
        if finding_id in seen_ids:
            errors.append(
                f"{prefix}: ID '{finding_id}' duplicado "
                f"(já usado no achado #{seen_ids[finding_id]})."
            )
        else:
            seen_ids[finding_id] = i + 1

    return errors


def detect_secrets_in_text(text: str) -> List[str]:
    """Detecta potenciais segredos ou dados sensíveis em texto.

    Utiliza padrões de regex para identificar credenciais, tokens,
    chaves e strings de conexão que podem não ter sido sanitizados.

    Args:
        text: Texto a ser analisado.

    Returns:
        Lista de avisos sobre segredos potencialmente encontrados.
    """
    warnings: List[str] = []

    for secret_name, pattern in SECRET_PATTERNS.items():
        matches = pattern.findall(text)
        if matches:
            # Truncar match para não expor o segredo completo no aviso
            sample = matches[0]
            if len(sample) > 20:
                sample = sample[:20] + "..."
            warnings.append(
                f"Possível {secret_name} detectado: '{sample}'. "
                f"Verifique se os dados foram adequadamente sanitizados."
            )

    return warnings


def check_findings_for_secrets(findings: List[Dict[str, Any]]) -> List[str]:
    """Verifica evidências e descrições de achados em busca de segredos.

    Args:
        findings: Lista de achados do relatório.

    Returns:
        Lista de avisos sobre dados potencialmente sensíveis.
    """
    warnings: List[str] = []

    for i, finding in enumerate(findings):
        finding_id = finding.get("finding_id", f"#{i + 1}")

        # Verificar evidência
        evidence = finding.get("evidence", "")
        if evidence:
            secret_warnings = detect_secrets_in_text(evidence)
            for w in secret_warnings:
                warnings.append(f"Achado {finding_id} (evidência): {w}")

        # Verificar descrição
        description = finding.get("description", "")
        if description:
            secret_warnings = detect_secrets_in_text(description)
            for w in secret_warnings:
                warnings.append(f"Achado {finding_id} (descrição): {w}")

    return warnings


def validate_cvss_severity_consistency(findings: List[Dict[str, Any]]) -> List[str]:
    """Valida a coerência entre pontuação CVSS e nível de severidade.

    Verifica se a pontuação CVSS informada está dentro da faixa
    esperada para o nível de severidade declarado.

    Args:
        findings: Lista de achados do relatório.

    Returns:
        Lista de avisos sobre inconsistências.
    """
    warnings: List[str] = []

    for i, finding in enumerate(findings):
        finding_id = finding.get("finding_id", f"#{i + 1}")
        severity = finding.get("severity", "")
        cvss_score = finding.get("cvss_score")

        if cvss_score is None or severity not in SEVERITY_CVSS_RANGES:
            continue

        expected_min, expected_max = SEVERITY_CVSS_RANGES[severity]

        # Caso especial: informational com score 0.0 é ok
        if severity == "informational" and cvss_score == 0.0:
            continue

        if not (expected_min <= cvss_score <= expected_max):
            warnings.append(
                f"Achado {finding_id}: Pontuação CVSS {cvss_score} é "
                f"inconsistente com severidade '{severity}' "
                f"(faixa esperada: {expected_min}-{expected_max})."
            )

    return warnings


def validate_report(
    report_data: Dict[str, Any],
    schema: Optional[Dict[str, Any]] = None,
    schema_path: Optional[Path] = None,
) -> Tuple[List[str], List[str]]:
    """Executa a validação completa do relatório.

    Realiza validação contra o schema JSON, verificação de IDs,
    detecção de segredos e validação de coerência CVSS.

    Args:
        report_data: Dados do relatório a serem validados.
        schema: Schema JSON carregado. Se None, será carregado do arquivo.
        schema_path: Caminho para o arquivo de schema (usado se schema é None).

    Returns:
        Tupla com (lista_de_erros, lista_de_avisos).
    """
    errors: List[str] = []
    warnings: List[str] = []

    # Carregar schema se necessário
    if schema is None:
        try:
            schema = load_schema(schema_path)
        except FileNotFoundError:
            errors.append(
                f"Arquivo de schema não encontrado: "
                f"{schema_path or DEFAULT_SCHEMA_PATH}"
            )
            return errors, warnings
        except json.JSONDecodeError as e:
            errors.append(f"Erro ao decodificar o schema JSON: {e}")
            return errors, warnings

    # 1. Validação contra o schema
    schema_errors = validate_against_schema(report_data, schema)
    errors.extend(schema_errors)

    # 2. Validação de IDs de achados
    findings = report_data.get("findings", [])
    id_errors = validate_finding_ids(findings)
    errors.extend(id_errors)

    # 3. Detecção de segredos em evidências/descrições
    secret_warnings = check_findings_for_secrets(findings)
    warnings.extend(secret_warnings)

    # 4. Validação de coerência CVSS/severidade
    cvss_warnings = validate_cvss_severity_consistency(findings)
    warnings.extend(cvss_warnings)

    return errors, warnings


def print_validation_result(
    errors: List[str], warnings: List[str], report_path: str
) -> None:
    """Imprime o resultado da validação de forma formatada.

    Args:
        errors: Lista de erros encontrados.
        warnings: Lista de avisos.
        report_path: Caminho do arquivo de relatório validado.
    """
    separator = "=" * 60
    print(separator)
    print("  VALIDAÇÃO DE RELATÓRIO — AI Security Auditor")
    print(separator)
    print(f"  Arquivo: {report_path}")
    print()

    if errors:
        print(f"[ERROS] ({len(errors)} encontrado(s))")
        for i, error in enumerate(errors, 1):
            print(f"  {i}. ❌ {error}")
        print()

    if warnings:
        print(f"[AVISOS] ({len(warnings)} encontrado(s))")
        for i, warning in enumerate(warnings, 1):
            print(f"  {i}. ⚠️  {warning}")
        print()

    print(separator)
    if errors:
        print(f"  RESULTADO: ❌ Relatório INVÁLIDO ({len(errors)} erro(s)).")
    else:
        status = "com avisos" if warnings else "sem problemas"
        print(f"  RESULTADO: ✅ Relatório VÁLIDO ({status}).")
    print(separator)


def main() -> int:
    """Ponto de entrada principal do script de validação de relatório.

    Analisa os argumentos, carrega e valida o relatório, exibindo
    o resultado formatado e retornando código de saída apropriado.

    Returns:
        0 se o relatório é válido, 1 se há erros.
    """
    parser = argparse.ArgumentParser(
        description="Validação de relatórios de auditoria de segurança.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Exemplos de uso:\n"
            "  python check_report.py --report-file relatorio.json\n"
        ),
    )
    parser.add_argument(
        "--report-file",
        type=str,
        required=True,
        help="Caminho para o arquivo JSON de relatório a ser validado.",
    )
    parser.add_argument(
        "--schema-file",
        type=str,
        default=None,
        help="Caminho para o arquivo JSON Schema (opcional).",
    )

    args = parser.parse_args()

    report_path = Path(args.report_file)
    schema_path = Path(args.schema_file) if args.schema_file else None

    # Carregar o relatório
    try:
        report_data = load_report(report_path)
    except FileNotFoundError:
        print(
            f"ERRO: Arquivo de relatório não encontrado: {report_path}",
            file=sys.stderr,
        )
        return 1
    except json.JSONDecodeError as e:
        print(
            f"ERRO: JSON inválido no arquivo de relatório: {e}",
            file=sys.stderr,
        )
        return 1

    # Validar
    errors, warnings = validate_report(report_data, schema_path=schema_path)

    # Exibir resultado
    print_validation_result(errors, warnings, str(report_path))

    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
