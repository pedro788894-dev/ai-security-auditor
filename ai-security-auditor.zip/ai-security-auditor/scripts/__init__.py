# Pacote de scripts do AI Security Auditor
