#!/usr/bin/env python3
"""
Auditor de Segurança de Banco de Dados — AI Security Auditor.

Especializado em:
1. Análise estática de vulnerabilidades de Injeção SQL e NoSQL no código.
2. Verificação de portas e exposição de rede de serviços de banco de dados.
3. Identificação de credenciais padrão, superusuários e dados sensíveis desprotegidos.
4. Detecção de backups e dumps expostos (.sql, .dump, .bak).
5. Auditoria de controle de privilégios (Least Privilege).

POLÍTICA ESTRITA: Operação estritamente SOMENTE LEITURA.
Nenhum comando INSERT, UPDATE, DELETE, DROP ou modificação de dados é realizado.
"""

import json
import os
import re
import socket
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
if sys.stderr and hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# Portas padrão de bancos de dados
STANDARD_DB_PORTS: Dict[int, str] = {
    5432: "PostgreSQL",
    3306: "MySQL / MariaDB",
    27017: "MongoDB",
    6379: "Redis",
    1433: "Microsoft SQL Server",
    9200: "Elasticsearch HTTP",
    9300: "Elasticsearch Transport",
    1521: "Oracle DB",
    5984: "CouchDB",
    8529: "ArangoDB",
    28015: "RethinkDB",
    7000: "Cassandra Inter-node",
    9042: "Cassandra CQL",
}

# Painéis administrativos web conhecidos
ADMIN_PANEL_PATHS = [
    "/phpmyadmin",
    "/pma",
    "/adminer",
    "/adminer.php",
    "/mongo-express",
    "/redis-commander",
    "/pgadmin",
]

# Extensões e padrões de dumps de banco de dados
DUMP_PATTERNS = [
    r".*\.sql(?:\.(?:gz|bz2|zip|tar))?$",
    r".*\.dump$",
    r".*\.bak$",
    r".*\.rdb$",
    r"backup_.*\.tar$",
    r"db_backup_.*",
]


def check_port_exposure_readonly(
    host: str,
    ports: Optional[List[int]] = None,
    timeout_sec: float = 1.0,
) -> List[Dict[str, Any]]:
    """Verifica de forma estritamente somente leitura se portas de banco de dados estão abertas na rede.

    Apenas testa conexão TCP SYN/ACK (socket.connect_ex) sem enviar comandos destrutivos.
    """
    results: List[Dict[str, Any]] = []
    target_ports = ports or list(STANDARD_DB_PORTS.keys())

    for port in target_ports:
        service_name = STANDARD_DB_PORTS.get(port, "Desconhecido")
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout_sec)
        try:
            res = sock.connect_ex((host, port))
            if res == 0:
                results.append({
                    "port": port,
                    "service": service_name,
                    "state": "open",
                    "severity": "critical" if port in [6379, 27017, 9200] else "high",
                    "description": (
                        f"Porta de serviço de banco de dados {port} ({service_name}) exposta "
                        f"diretamente na interface de rede {host}."
                    ),
                    "recommendation": (
                        "Restringir o acesso a esta porta via firewall/security groups, "
                        "vincular o serviço a 'localhost' ou sub-rede privada, e habilitar TLS/autenticação."
                    ),
                })
        except Exception as e:
            # Erro de rede ou DNS ignorado de forma segura
            pass
        finally:
            try:
                sock.close()
            except Exception:
                pass

    return results


def analyze_sql_injection_patterns(code_dir: str) -> List[Dict[str, Any]]:
    """Analisa arquivos de código-fonte em busca de padrões de injeção de SQL.

    Detecta:
    - Concatenação direta de strings em comandos SQL ('SELECT ... ' + var)
    - Interpolação com f-strings ou .format() em queries Python
    - Parâmetros ORDER BY e LIKE construídos dinamicamente sem whitelist
    - Uso incorreto de raw queries em ORMs (Sequelize, TypeORM, Django, SQLAlchemy)
    """
    findings: List[Dict[str, Any]] = []
    base_path = Path(code_dir).resolve()
    if not base_path.exists():
        return findings

    code_extensions = {".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".php", ".go", ".cs", ".rb"}

    # Padrões de concatenação de SQL (ordenados do mais específico para o geral)
    concat_sql_patterns = [
        (
            re.compile(r"""\bORDER\s+BY\b\s+['"]\s*\+\s*[a-zA-Z0-9_]+|\bORDER\s+BY\b\s+\$\{""", re.IGNORECASE),
            "Cláusula ORDER BY construída dinamicamente sem whitelist",
            "high",
        ),
        (
            re.compile(r"""\bLIKE\b\s+['"]%\s*['"]\s*\+\s*[a-zA-Z0-9_]+|\bLIKE\b\s+`%?\$\{""", re.IGNORECASE),
            "Cláusula LIKE montada por concatenação de texto não parametrizado",
            "medium",
        ),
        (
            re.compile(r"""(?:execute|raw|query)\s*\(\s*f['"].*\b(?:SELECT|INSERT|UPDATE|DELETE|WHERE)\b""", re.IGNORECASE),
            "Interpolação de f-string em query SQL do cursor/ORM",
            "critical",
        ),
        (
            re.compile(r"""(?:execute|raw|query)\s*\(\s*['"].*\b(?:SELECT|INSERT|UPDATE|DELETE|WHERE)\b.*\.format\s*\(""", re.IGNORECASE),
            "Formatação com .format() em query SQL",
            "high",
        ),
        (
            re.compile(r"""(?:sequelize|knex|prisma|typeorm|db)\.\$?(?:query|raw)\s*\(\s*`[^`]*\$\{""", re.IGNORECASE),
            "Raw query de ORM utilizando interpolação de template string (ES6)",
            "critical",
        ),
        (
            re.compile(r"""\b(?:SELECT|INSERT|UPDATE|DELETE|FROM|WHERE)\b\s+.*['"]\s*\+\s*[a-zA-Z0-9_]+""", re.IGNORECASE),
            "Concatenação de string em query SQL (+)",
            "high",
        ),
    ]

    for root, _, files in os.walk(base_path):
        if any(ignored in root for ignored in ["node_modules", ".git", "venv", "__pycache__", "dist", "build"]):
            continue

        for file in files:
            file_path = Path(root) / file
            if file_path.suffix.lower() not in code_extensions:
                continue

            try:
                content = file_path.read_text(encoding="utf-8", errors="replace")
                lines = content.splitlines()
            except Exception:
                continue

            rel_file = str(file_path.relative_to(base_path)).replace("\\", "/")

            for idx, line in enumerate(lines, 1):
                clean_line = line.strip()
                # Ignorar comentários comuns
                if clean_line.startswith(("//", "#", "/*", "*")):
                    continue

                for pat, desc, severity in concat_sql_patterns:
                    if pat.search(line):
                        findings.append({
                            "id": f"DB-SQLI-{len(findings) + 1:03d}",
                            "type": "sql_injection",
                            "title": desc,
                            "severity": severity,
                            "file": rel_file,
                            "line": idx,
                            "evidence": f"{rel_file}:{idx}: {clean_line[:120]}",
                            "description": (
                                f"Detectado padrão no arquivo {rel_file}:{idx} onde queries SQL "
                                f"são montadas dinamicamente via concatenação ou interpolação não parametrizada."
                            ),
                            "recommendation": (
                                "Substituir concatenações manuais por prepared statements ou parâmetros nativos "
                                "do driver/ORM (ex.: cursor.execute('SELECT * FROM t WHERE id = %s', (id,)))."
                            ),
                            "cwe_id": "CWE-89",
                        })
                        break

    return findings


def analyze_nosql_injection_patterns(code_dir: str) -> List[Dict[str, Any]]:
    """Analisa arquivos de código-fonte em busca de injeção NoSQL (ex: MongoDB, Mongoose).

    Detecta:
    - Passagem direta de req.body ou req.query para métodos find/findOne/update
    - Manipulação de operadores ($gt, $ne, $where) não sanitizados
    """
    findings: List[Dict[str, Any]] = []
    base_path = Path(code_dir).resolve()
    if not base_path.exists():
        return findings

    code_extensions = {".js", ".ts", ".jsx", ".tsx", ".py"}

    nosql_patterns = [
        (
            re.compile(r"""\.(?:find|findOne|update|deleteOne)\s*\(\s*(?:req\.body|req\.query|req\.params)\s*\)""", re.IGNORECASE),
            "Objeto de requisição não sanitizado passado diretamente a query NoSQL",
            "high",
        ),
        (
            re.compile(r"""\.(?:find|findOne)\s*\(\s*\{[^\}]*(?:username|password|email|user)\s*:\s*(?:req\.body\.\w+|req\.query\.\w+)""", re.IGNORECASE),
            "Propriedade de autenticação sem validação de tipo de objeto (risco de operador $gt/$ne)",
            "high",
        ),
        (
            re.compile(r"""\$where\s*:\s*(?:req\.|function|\+)""", re.IGNORECASE),
            "Uso perigoso do operador $where no MongoDB com código dinâmico",
            "critical",
        ),
    ]

    for root, _, files in os.walk(base_path):
        if any(ignored in root for ignored in ["node_modules", ".git", "venv", "__pycache__", "dist"]):
            continue

        for file in files:
            file_path = Path(root) / file
            if file_path.suffix.lower() not in code_extensions:
                continue

            try:
                content = file_path.read_text(encoding="utf-8", errors="replace")
                lines = content.splitlines()
            except Exception:
                continue

            rel_file = str(file_path.relative_to(base_path)).replace("\\", "/")

            for idx, line in enumerate(lines, 1):
                clean_line = line.strip()
                if clean_line.startswith(("//", "#", "/*")):
                    continue

                for pat, desc, severity in nosql_patterns:
                    if pat.search(line):
                        findings.append({
                            "id": f"DB-NOSQLI-{len(findings) + 1:03d}",
                            "type": "nosql_injection",
                            "title": desc,
                            "severity": severity,
                            "file": rel_file,
                            "line": idx,
                            "evidence": f"{rel_file}:{idx}: {clean_line[:120]}",
                            "description": (
                                f"Padrão suspeito de injeção NoSQL no arquivo {rel_file}:{idx}. "
                                "Atacantes podem enviar payloads JSON com operadores como { $ne: null } para contornar verificações."
                            ),
                            "recommendation": (
                                "Sanitizar e converter explicitamente tipos (ex.: String(req.body.username)) "
                                "ou utilizar bibliotecas como express-mongo-sanitize para remover chaves que iniciem com '$'."
                            ),
                            "cwe_id": "CWE-943",
                        })
                        break

    return findings


def check_db_configuration_and_secrets(code_dir: str) -> List[Dict[str, Any]]:
    """Inspeciona configurações de banco de dados, privilégios de conexão e exposição de backups."""
    findings: List[Dict[str, Any]] = []
    base_path = Path(code_dir).resolve()
    if not base_path.exists():
        return findings

    # 1. Procurar arquivos de dump e backup desprotegidos no repositório/diretório
    for root, _, files in os.walk(base_path):
        if any(ignored in root for ignored in [".git", "node_modules", "venv"]):
            continue

        for file in files:
            for pattern in DUMP_PATTERNS:
                if re.match(pattern, file, re.IGNORECASE):
                    file_path = Path(root) / file
                    rel_file = str(file_path.relative_to(base_path)).replace("\\", "/")
                    size_mb = file_path.stat().st_size / (1024 * 1024)
                    findings.append({
                        "id": f"DB-BACKUP-EXPOSED-{len(findings) + 1:03d}",
                        "title": f"Arquivo de dump ou backup de banco de dados exposto no repositório: {file}",
                        "severity": "critical" if size_mb > 0.1 else "high",
                        "file": rel_file,
                        "line": 1,
                        "evidence": f"Arquivo: {rel_file} ({size_mb:.2f} MB)",
                        "description": (
                            f"O arquivo {rel_file} aparenta ser um dump ou backup de banco de dados. "
                            "Se exposto em repositórios ou diretórios web, pode vazar a estrutura e dados sensíveis."
                        ),
                        "recommendation": (
                            "Remover imediatamente o dump do repositório/diretório web e armazenar backups "
                            "em buckets com criptografia e controle de acesso estrito."
                        ),
                        "cwe_id": "CWE-200",
                    })
                    break

    # 2. Procurar conexão com usuário superadministrador (root, sa, postgres) e credenciais fracas
    superuser_regex = re.compile(
        r"""(?:postgres|postgresql|mysql|mssql)://(?:root|sa|postgres|admin):([^@\s'"]*)@""",
        re.IGNORECASE,
    )

    weak_hash_regex = re.compile(
        r"""(?:hashlib\.md5|hashlib\.sha1|crypto\.createHash\(['"](?:md5|sha1)['"]\))""",
        re.IGNORECASE,
    )

    for root, _, files in os.walk(base_path):
        if any(ignored in root for ignored in [".git", "node_modules", "venv"]):
            continue

        for file in files:
            file_path = Path(root) / file
            if file_path.suffix.lower() not in {".env", ".json", ".yaml", ".yml", ".py", ".js", ".ts", ".conf"}:
                continue

            try:
                content = file_path.read_text(encoding="utf-8", errors="replace")
                lines = content.splitlines()
            except Exception:
                continue

            rel_file = str(file_path.relative_to(base_path)).replace("\\", "/")

            for idx, line in enumerate(lines, 1):
                # Verificar usuário superadministrador
                match = superuser_regex.search(line)
                if match:
                    findings.append({
                        "id": f"DB-SUPERUSER-CONN-{len(findings) + 1:03d}",
                        "title": "Conexão de banco de dados configurada com usuário superadministrador",
                        "severity": "high",
                        "file": rel_file,
                        "line": idx,
                        "evidence": f"{rel_file}:{idx}: {re.sub(r':[^@]+@', ':***@', line.strip())[:100]}",
                        "description": (
                            f"A aplicação está configurada para conectar ao banco usando credenciais de superusuário "
                            f"(root/sa/postgres), violando o princípio do menor privilégio (PoLP)."
                        ),
                        "recommendation": (
                            "Criar um usuário específico para a aplicação com permissões restritas apenas às tabelas "
                            "necessárias (DML: SELECT, INSERT, UPDATE, DELETE), sem privilégios de DDL ou superadmin."
                        ),
                        "cwe_id": "CWE-250",
                    })

                # Verificar hashing fraco para dados sensíveis
                if weak_hash_regex.search(line) and any(k in line.lower() for k in ["pass", "pwd", "token", "auth", "secret"]):
                    findings.append({
                        "id": f"DB-WEAK-HASH-{len(findings) + 1:03d}",
                        "title": "Uso de algoritmo de hashing fraco (MD5 / SHA-1) para dados sensíveis",
                        "severity": "high",
                        "file": rel_file,
                        "line": idx,
                        "evidence": f"{rel_file}:{idx}: {line.strip()[:100]}",
                        "description": (
                            "MD5 e SHA-1 são vulneráveis a colisões e ataques de dicionário acelerados por GPU. "
                            "Não são adequados para senhas ou credenciais."
                        ),
                        "recommendation": "Migrar para algoritmos modernos de hashing como Argon2id, bcrypt ou scrypt.",
                        "cwe_id": "CWE-328",
                    })

    return findings


def run_database_security_audit(
    code_dir: Optional[str] = None,
    network_host: Optional[str] = None,
) -> Dict[str, Any]:
    """Executa a auditoria completa de segurança de banco de dados em modo estritamente somente leitura."""
    all_findings: List[Dict[str, Any]] = []
    ports_detected: List[Dict[str, Any]] = []

    if network_host:
        ports_detected = check_port_exposure_readonly(network_host)
        all_findings.extend(ports_detected)

    if code_dir and Path(code_dir).exists():
        sqli_findings = analyze_sql_injection_patterns(code_dir)
        nosqli_findings = analyze_nosql_injection_patterns(code_dir)
        config_findings = check_db_configuration_and_secrets(code_dir)

        all_findings.extend(sqli_findings)
        all_findings.extend(nosqli_findings)
        all_findings.extend(config_findings)

    return {
        "status": "completed",
        "findings_count": len(all_findings),
        "findings": all_findings,
        "read_only_verified": True,
        "limitations": [
            "Auditoria estritamente somente leitura. Nenhuma alteração em tabelas ou registros foi realizada.",
            "Testes dinâmicos de exploração de SQLi em banco em produção são proibidos.",
        ],
    }
