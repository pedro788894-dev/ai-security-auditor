#!/usr/bin/env python3
"""
Auditor especializado em resistência a Brute Force, Credential Stuffing e Autenticação.

Este módulo implementa:
1. Classificação de defesas em 4 estados:
   - Hard lockout
   - Soft IP throttle
   - CAPTCHA injection
   - Silent shadow-throttle
2. Teste de semente de shadow-throttle (Shadow-Throttle Seed Test) para login e OTP/2FA.
3. Detecção de enumeração de usuários (diferenças de resposta e timing side-channels
   com mediana de pelo menos 30 amostras).
4. Avaliação de proteção baseada em IP vs baseada em conta (Account-based).
5. Análise estática de código-fonte para falhas de autenticação e brute force.
6. Limites conservadores e salvaguardas éticas estritas.
"""

import json
import os
import re
import statistics
import sys
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlparse
from urllib.request import Request, urlopen

if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
if sys.stderr and hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


@dataclass
class ResponseSample:
    """Amostra de resposta HTTP para análise de defesa e timing."""
    index: int
    status_code: int
    latency_ms: float
    body_length: int
    body_snippet: str = ""
    headers: Dict[str, str] = field(default_factory=dict)
    is_seed: bool = False
    is_success: bool = False


@dataclass
class DefenseClassification:
    """Resultado da classificação de estado da defesa contra brute force."""
    state: str  # 'Hard lockout', 'Soft IP throttle', 'CAPTCHA injection', 'Silent shadow-throttle', 'No rate limiting', 'Inconclusive'
    signals: List[str]
    confidence: str  # 'high', 'medium', 'low'
    details: str
    samples_count: int
    seed_tested: bool = False
    seed_succeeded: Optional[bool] = None


@dataclass
class TimingAnalysisResult:
    """Resultado da análise estatística de timing side-channel."""
    user_a: str
    user_b: str
    samples_a_count: int
    samples_b_count: int
    median_a_ms: float
    median_b_ms: float
    delta_ms: float
    difference_detected: bool
    potential_enumeration: bool
    details: str


# Padrões comuns de CAPTCHA
CAPTCHA_PATTERNS = [
    r"recaptcha",
    r"hcaptcha",
    r"cf-turnstile",
    r"challenge-form",
    r"g-recaptcha",
    r"captcha[-_]?token",
    r"geetest",
    r"arkoselabs",
    r"security-check",
    r"human-verification",
]

# Mensagens típicas de bloqueio explícito (Hard lockout)
LOCKOUT_MESSAGES = [
    r"account\s+(?:is\s+)?(?:temporarily\s+)?locked",
    r"conta\s+(?:foi\s+)?bloqueada",
    r"too\s+many\s+(?:failed\s+)?login\s+attempts",
    r"muitas\s+tentativas\s+(?:falhas\s+)?de\s+login",
    r"temporarily\s+disabled",
    r"temporariamente\s+desativad[oa]",
    r"try\s+again\s+in\s+\d+\s+(?:minutes?|seconds?|hours?)",
    r"tente\s+novamente\s+em\s+\d+\s+(?:minutos?|segundos?|horas?)",
    r"blocked\s+due\s+to\s+suspicious\s+activity",
]


def classify_defense_state(
    samples: List[ResponseSample],
    seed_sample: Optional[ResponseSample] = None,
) -> DefenseClassification:
    """Classifica o estado da defesa contra força bruta com base nos sinais observáveis.

    Estados:
    1. Hard lockout: Conta desabilitada temporariamente; status 403 ou mensagem explícita de bloqueio.
    2. Soft IP throttle: Status 429 ou latência progressivamente crescente.
    3. CAPTCHA injection: O corpo da resposta muda para um desafio de verificação humana.
    4. Silent shadow-throttle: Respostas permanecem 200/401, mas requisições deixam de ser processadas
       (confirmado quando uma credencial válida no teste de semente deixa de autenticar).
    """
    if not samples:
        return DefenseClassification(
            state="Inconclusive",
            signals=["Nenhuma amostra fornecida"],
            confidence="low",
            details="Não há dados suficientes para determinar a defesa.",
            samples_count=0,
        )

    signals: List[str] = []
    total = len(samples)

    # 1. Verificar CAPTCHA injection
    # Se o corpo da resposta passou a conter marcadores de CAPTCHA que não estavam presentes inicialmente
    initial_has_captcha = any(
        any(re.search(pat, s.body_snippet, re.IGNORECASE) for pat in CAPTCHA_PATTERNS)
        for s in samples[:2]
    )
    later_has_captcha = any(
        any(re.search(pat, s.body_snippet, re.IGNORECASE) for pat in CAPTCHA_PATTERNS)
        for s in samples[2:]
    )

    if later_has_captcha and not initial_has_captcha:
        signals.append("Desafio CAPTCHA (reCAPTCHA/hCaptcha/Turnstile) injetado após sequência de requisições")
        return DefenseClassification(
            state="CAPTCHA injection",
            signals=signals,
            confidence="high",
            details="O sistema injetou dinamicamente um desafio CAPTCHA para bloquear automação.",
            samples_count=total,
        )

    # 2. Verificar Soft IP throttle
    # Status 429 Too Many Requests ou latência progressivamente crescente
    has_429 = any(s.status_code == 429 for s in samples)
    has_retry_after = any("retry-after" in {k.lower(): v for k, v in s.headers.items()} for s in samples)

    latencies = [s.latency_ms for s in samples]
    latency_escalation = False
    if len(latencies) >= 6:
        first_quarter = statistics.median(latencies[: len(latencies) // 3])
        last_quarter = statistics.median(latencies[-len(latencies) // 3 :])
        # Latência aumentou significativamente (> 3x e > 500ms de acréscimo)
        if last_quarter > first_quarter * 3 and (last_quarter - first_quarter) > 500:
            latency_escalation = True

    if has_429 or (has_retry_after and latency_escalation):
        if has_429:
            signals.append("Recebido código de status HTTP 429 (Too Many Requests)")
        if has_retry_after:
            signals.append("Presença de cabeçalho 'Retry-After'")
        if latency_escalation:
            signals.append(f"Atraso progressivo observado (latência subiu de ~{first_quarter:.0f}ms para ~{last_quarter:.0f}ms)")
        return DefenseClassification(
            state="Soft IP throttle",
            signals=signals,
            confidence="high",
            details="O sistema aplicou limitação de taxa (throttling) com HTTP 429 ou atraso progressivo.",
            samples_count=total,
        )

    # 3. Verificar Hard lockout
    # Status 403 Forbidden ou mensagens textuais explícitas de bloqueio de conta
    has_403 = any(s.status_code == 403 for s in samples[1:])
    lockout_msg_detected = False
    matched_lockout_text = ""

    for s in samples:
        for pat in LOCKOUT_MESSAGES:
            match = re.search(pat, s.body_snippet, re.IGNORECASE)
            if match:
                lockout_msg_detected = True
                matched_lockout_text = match.group(0)
                break
        if lockout_msg_detected:
            break

    if has_403 or lockout_msg_detected:
        if has_403:
            signals.append("Código de status HTTP 403 (Forbidden) recebido após tentativas repetidas")
        if lockout_msg_detected:
            signals.append(f"Mensagem explícita de bloqueio de conta detectada: '{matched_lockout_text}'")
        return DefenseClassification(
            state="Hard lockout",
            signals=signals,
            confidence="high",
            details="A conta ou sessão foi explicitamente desabilitada temporariamente.",
            samples_count=total,
        )

    # 4. Avaliar Silent shadow-throttle vs Ausência de Rate Limiting
    # Se todas as respostas permaneceram 200 ou 401 com comportamento constante
    if seed_sample is not None:
        if not seed_sample.is_success:
            # A credencial sabidamente válida FALHOU ao autenticar sob carga
            signals.append(
                f"Teste de semente (Seed Test): credencial válida injetada sob carga foi rejeitada "
                f"(status={seed_sample.status_code}, latência={seed_sample.latency_ms:.0f}ms), "
                f"embora a resposta geral permaneça simulando processamento normal."
            )
            return DefenseClassification(
                state="Silent shadow-throttle",
                signals=signals,
                confidence="high",
                details="O sistema implementa estrangulamento silencioso (shadow-throttling); "
                "requisições parecem ser processadas normalmente mas são ignoradas nos bastidores.",
                samples_count=total,
                seed_tested=True,
                seed_succeeded=False,
            )
        else:
            # A credencial válida teve êxito mesmo sob carga contínua
            signals.append(
                f"Teste de semente (Seed Test): credencial válida autenticou com sucesso (status={seed_sample.status_code}) "
                f"mesmo após {total} tentativas consecutivas sem bloqueio ou atraso."
            )
            return DefenseClassification(
                state="No rate limiting",
                signals=signals,
                confidence="high",
                details="O endpoint não aplicou nenhuma limitação observável nem estrangulamento silencioso. "
                "Vulnerável a força bruta e credential stuffing.",
                samples_count=total,
                seed_tested=True,
                seed_succeeded=True,
            )

    # Sem seed test para confirmar
    signals.append(f"Todas as {total} requisições retornaram código constante sem bloqueio observável")
    signals.append("Teste de semente (seed test) não foi executado para desempate definitivo")
    return DefenseClassification(
        state="No rate limiting",
        signals=signals,
        confidence="medium",
        details="Candidato a ausência de rate limiting. Recomenda-se executar o shadow-throttle seed test com conta de teste.",
        samples_count=total,
        seed_tested=False,
    )


def execute_controlled_burst_test(
    request_sender: Callable[[int, bool], ResponseSample],
    max_attempts: int = 30,
    seed_position: Optional[int] = None,
    latency_abort_ms: float = 3000.0,
) -> Tuple[DefenseClassification, List[ResponseSample], bool]:
    """Executa sequência controlada de testes de autenticação/OTP com salvaguardas éticas.

    Salvaguardas operacionais:
    - Limite conservador (máximo de 50 tentativas por janela de teste).
    - Interrupção imediata ao primeiro sinal de bloqueio (403, 429, CAPTCHA).
    - Interrupção imediata diante de sinais de sobrecarga (erros 5xx ou latência > threshold).
    - Execução do Shadow-Throttle Seed Test na posição especificada.

    Returns:
        Tupla com (Classificacao, AmostrasColetadas, AbortadoPorSeguranca).
    """
    safe_max = min(max(max_attempts, 1), 50)
    samples: List[ResponseSample] = []
    seed_sample: Optional[ResponseSample] = None
    aborted_due_to_safety = False

    for i in range(1, safe_max + 1):
        is_seed_turn = (seed_position is not None and i == seed_position)
        sample = request_sender(i, is_seed_turn)

        if is_seed_turn:
            seed_sample = sample
        else:
            samples.append(sample)

        # 1. Interrupção por erro 5xx (sobrecarga de servidor)
        if sample.status_code >= 500:
            aborted_due_to_safety = True
            break

        # 2. Interrupção por latência excessiva
        if sample.latency_ms > latency_abort_ms:
            aborted_due_to_safety = True
            break

        # 3. Interrupção se bloqueio (403 ou 429) ou CAPTCHA já foi atingido
        if sample.status_code in [403, 429]:
            break

        if any(re.search(p, sample.body_snippet, re.IGNORECASE) for p in CAPTCHA_PATTERNS):
            break

    classification = classify_defense_state(samples, seed_sample=seed_sample)
    if aborted_due_to_safety:
        classification.signals.append("Sequência de teste interrompida antecipadamente por salvaguarda de estabilidade do alvo.")

    return classification, samples, aborted_due_to_safety


def analyze_timing_side_channel(
    samples_user_a: List[float],
    samples_user_b: List[float],
    user_a_label: str = "Usuário Existente",
    user_b_label: str = "Usuário Inexistente",
    significance_threshold_ms: float = 35.0,
    min_samples: int = 30,
) -> TimingAnalysisResult:
    """Calcula se há timing side-channel indicando enumeração de usuários.

    Regra rigorosa: Exige medianas de pelo menos 30 amostras por usuário para
    conclusões confiáveis, eliminando variações transitórias de rede.
    """
    len_a = len(samples_user_a)
    len_b = len(samples_user_b)

    if len_a < min_samples or len_b < min_samples:
        return TimingAnalysisResult(
            user_a=user_a_label,
            user_b=user_b_label,
            samples_a_count=len_a,
            samples_b_count=len_b,
            median_a_ms=statistics.median(samples_user_a) if samples_user_a else 0.0,
            median_b_ms=statistics.median(samples_user_b) if samples_user_b else 0.0,
            delta_ms=0.0,
            difference_detected=False,
            potential_enumeration=False,
            details=f"Amostras insuficientes ({len_a}/{min_samples} e {len_b}/{min_samples}). "
            f"São necessárias pelo menos {min_samples} amostras por grupo para conclusões estatísticas.",
        )

    median_a = statistics.median(samples_user_a)
    median_b = statistics.median(samples_user_b)
    delta = abs(median_a - median_b)

    # IQR ou desvio padrão para avaliar estabilidade
    diff_detected = delta >= significance_threshold_ms

    details = (
        f"Mediana [{user_a_label}]: {median_a:.1f}ms (n={len_a}). "
        f"Mediana [{user_b_label}]: {median_b:.1f}ms (n={len_b}). "
        f"Diferença (delta): {delta:.1f}ms. "
    )
    if diff_detected:
        details += (
            f"Variação estatística significativa (>= {significance_threshold_ms}ms) "
            "indica timing side-channel que permite enumerar se um usuário/email existe no sistema."
        )
    else:
        details += "Diferença estatisticamente desprezível entre as respostas. Sem canal lateral de timing observável."

    return TimingAnalysisResult(
        user_a=user_a_label,
        user_b=user_b_label,
        samples_a_count=len_a,
        samples_b_count=len_b,
        median_a_ms=median_a,
        median_b_ms=median_b,
        delta_ms=delta,
        difference_detected=diff_detected,
        potential_enumeration=diff_detected,
        details=details,
    )


def audit_code_for_brute_force_flaws(code_dir: str) -> List[Dict[str, Any]]:
    """Analisa estaticamente arquivos de código-fonte em busca de falhas de brute force e autenticação.

    Inspeciona:
    - Ausência de middleware de rate limiting em rotas de auth
    - Lógica de bloqueio baseada apenas em IP (ip-only), permitindo password spraying e credential stuffing
    - Tokens de reset ou magic links com entropia insuficiente ou sem invalidação de uso único
    - Bypass de MFA (ex: via parâmetros como remember_device ou flags opcionais)
    """
    findings: List[Dict[str, Any]] = []
    base_path = Path(code_dir).resolve()
    if not base_path.exists():
        return findings

    code_extensions = {".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".go", ".php", ".rb", ".cs"}

    # Padrões para rotas de autenticação
    auth_route_patterns = [
        re.compile(r"['\"]/(?:api/)?(?:v\d+/)?(?:auth|login|signin|reset-password|forgot-password|verify-otp|refresh)['\"]", re.IGNORECASE),
        re.compile(r"@(?:app|router)\.(?:post|get)\s*\(\s*['\"]/(?:login|authenticate|token|otp)['\"]", re.IGNORECASE),
    ]

    # Padrões de middleware de rate limit
    rate_limit_patterns = [
        re.compile(r"rate_?limit", re.IGNORECASE),
        re.compile(r"limiter\.(?:limit|check)", re.IGNORECASE),
        re.compile(r"throttle", re.IGNORECASE),
        re.compile(r"express-rate-limit", re.IGNORECASE),
        re.compile(r"slowdown", re.IGNORECASE),
        re.compile(r"django_ratelimit", re.IGNORECASE),
    ]

    # Padrão de chave de bloqueio por IP apenas
    ip_only_lockout = re.compile(
        r"(?:lockout|failed_attempts|attempts_by_ip|ratelimit)\s*\[\s*(?:req\.ip|request\.META\['REMOTE_ADDR'\]|req\.connection\.remoteAddress|client_ip)\s*\]",
        re.IGNORECASE,
    )

    # Tokens fracos em reset de senha / links mágicos
    weak_token_patterns = [
        re.compile(r"Math\.random\s*\(\s*\)", re.IGNORECASE),
        re.compile(r"random\.randint\s*\(", re.IGNORECASE),
        re.compile(r"random\.random\s*\(", re.IGNORECASE),
        re.compile(r"rand\s*\(\s*\d+\s*,\s*\d+\s*\)", re.IGNORECASE),
    ]

    # MFA bypass flags
    mfa_bypass_patterns = [
        re.compile(r"if\s*\(\s*!?(?:req\.body|req\.query|params)\.remember_device", re.IGNORECASE),
        re.compile(r"skip_mfa|bypass_2fa|remember_me\s*==\s*true", re.IGNORECASE),
    ]

    for root, _, files in os.walk(base_path):
        # Ignorar diretórios comuns de dependências e testes
        if any(ignored in root for ignored in ["node_modules", ".git", "venv", "__pycache__", "dist", "build"]):
            continue

        for file in files:
            file_path = Path(root) / file
            if file_path.suffix.lower() not in code_extensions:
                continue

            try:
                content = file_path.read_text(encoding="utf-8", errors="replace")
                lines = content.splitlines()
            except Exception:
                continue

            rel_file = str(file_path.relative_to(base_path)).replace("\\", "/")

            # 1. Rota de autenticação sem rate limiting evidente
            has_auth_route = False
            auth_route_line = 0
            for idx, line in enumerate(lines, 1):
                if any(p.search(line) for p in auth_route_patterns):
                    has_auth_route = True
                    auth_route_line = idx
                    break

            if has_auth_route:
                has_rate_limit = any(any(p.search(l) for p in rate_limit_patterns) for l in lines)
                if not has_rate_limit:
                    findings.append({
                        "id": f"AUTH-NO-RATELIMIT-{len(findings) + 1:03d}",
                        "title": "Rota de autenticação sem middleware de Rate Limiting visível",
                        "severity": "high",
                        "file": rel_file,
                        "line": auth_route_line,
                        "evidence": f"{rel_file}:{auth_route_line}: {lines[auth_route_line - 1].strip()[:100]}",
                        "description": (
                            f"O arquivo {rel_file} define rotas críticas de autenticação, mas não inclui "
                            "referências a middlewares conhecidos de rate limiting ou throttling."
                        ),
                        "recommendation": (
                            "Implementar rate limiting rígido (ex.: express-rate-limit, slowapi, redis-limiter) "
                            "tanto por endereço IP quanto por conta de usuário."
                        ),
                    })

            # 2. Bloqueio baseado apenas em IP
            for idx, line in enumerate(lines, 1):
                if ip_only_lockout.search(line):
                    findings.append({
                        "id": f"AUTH-IP-ONLY-LOCKOUT-{len(findings) + 1:03d}",
                        "title": "Controle de bloqueio de tentativas baseado exclusivamente em IP",
                        "severity": "medium",
                        "file": rel_file,
                        "line": idx,
                        "evidence": f"{rel_file}:{idx}: {line.strip()[:100]}",
                        "description": (
                            "A contagem de tentativas falhas ou bloqueio está indexada apenas ao endereço IP do cliente. "
                            "Atacantes podem contornar essa proteção distribuindo ataques de credential stuffing e "
                            "password spraying por múltiplos IPs e proxies."
                        ),
                        "recommendation": (
                            "Vincular o contador de bloqueio à identidade da conta/email (account-based lockout) "
                            "além da chave de IP, com atrasos progressivos."
                        ),
                    })
                    break

            # 3. Geração de tokens de reset com entropia fraca
            for idx, line in enumerate(lines, 1):
                if any(w.search(line) for w in weak_token_patterns) and any(
                    k in line.lower() for k in ["token", "reset", "otp", "code", "secret", "magic"]
                ):
                    findings.append({
                        "id": f"AUTH-WEAK-TOKEN-ENTROPY-{len(findings) + 1:03d}",
                        "title": "Geração de token de segurança com gerador pseudo-aleatório previsível",
                        "severity": "high",
                        "file": rel_file,
                        "line": idx,
                        "evidence": f"{rel_file}:{idx}: {line.strip()[:100]}",
                        "description": (
                            "Tokens de recuperação de senha ou códigos OTP estão sendo gerados com geradores "
                            "pseudo-aleatórios não criptográficos (ex.: Math.random ou random.randint), "
                            "permitindo predição de tokens."
                        ),
                        "recommendation": (
                            "Utilizar geradores criptograficamente seguros (crypto.randomBytes em Node.js, "
                            "secrets.token_urlsafe em Python, SecureRandom em Java)."
                        ),
                    })
                    break

            # 4. Potencial bypass de MFA via parâmetros secundários
            for idx, line in enumerate(lines, 1):
                if any(p.search(line) for p in mfa_bypass_patterns):
                    findings.append({
                        "id": f"AUTH-MFA-BYPASS-{len(findings) + 1:03d}",
                        "title": "Verificação de MFA suscetível a bypass por parâmetro secundário",
                        "severity": "critical",
                        "file": rel_file,
                        "line": idx,
                        "evidence": f"{rel_file}:{idx}: {line.strip()[:100]}",
                        "description": (
                            "Detectada lógica condicional que pode permitir ignorar a etapa de MFA quando parâmetros "
                            "como 'remember_device' estão presentes na requisição sem validação de sessão criptográfica."
                        ),
                        "recommendation": (
                            "Nunca permitir que o cliente decida o bypass de 2FA via parâmetro de requisição; "
                            "validar o dispositivo exclusivamente através de token de sessão assinado e armazenado no backend."
                        ),
                    })
                    break

    return findings
