# Relatório de Auditoria de Segurança — TechLab Solutions

---

## Metadados da Auditoria

| Campo | Valor |
| :--- | :--- |
| **Identificador do Relatório** | `REP-20261020-001` |
| **Identificador do Escopo** | `AUD-20261020-LAB` |
| **Data e Hora de Emissão** | 2026-10-20T18:30:00Z |
| **Auditor Responsável** | AI Security Auditor (Engenharia Defensiva) |
| **Ambiente Avaliado** | Laboratório / Homologação Sintética |
| **Modo de Auditoria** | Passivo e Ativo Autorizado |

---

## 1. Resumo Executivo

Auditoria de segurança defensiva realizada no ambiente de homologação da **TechLab Solutions**. Foram avaliados a aplicação web, a API REST, o repositório central e as configurações do banco de dados PostgreSQL/Supabase.

Foram identificados **4 achados de segurança relevantes**:
- **1 de Severidade Alta**: Broken Object Level Authorization (BOLA/IDOR) na API de faturas.
- **2 de Severidade Média**: Ausência de rate limiting na recuperação de senhas e política RLS permissiva na tabela de perfis de usuário.
- **1 de Severidade Baixa**: Ausência de cabeçalhos de segurança HTTP de endurecimento.

Não foram detectados segredos expostos no histórico de commits e nenhuma dependência com vulnerabilidades críticas conhecidas foi identificada.

### Matriz Consolidada de Riscos e Descobertas

| Severidade | Quantidade | Status Típico |
| :--- | :---: | :--- |
| 🔴 **Crítica (Critical)** | 0 | Nenhuma identificada |
| 🟠 **Alta (High)** | 1 | Ação no curto prazo |
| 🟡 **Média (Medium)** | 2 | Correção no ciclo de sprint |
| 🟢 **Baixa (Low)** | 1 | Endurecimento de configuração |
| 🔵 **Informativa (Info)** | 0 | Boas práticas gerais atendidas |
| **Total de Achados** | **4** | |

---

## 2. Escopo Autorizado

A auditoria foi restrita estritamente aos ativos autorizados conforme documentado no arquivo de escopo `AUD-20261020-LAB`:

- **Alvos Analisados**:
  - `portal-homolog.techlab-ficticio.local` (Ambiente: Laboratory)
  - `https://api-homolog.techlab-ficticio.local/v1` (Ambiente: Laboratory)
  - `github.com/techlab-ficticio/platform-backend` (Repositório)
  - `db-homolog.techlab-ficticio.local:5432` (PostgreSQL)
- **Ações Proibidas Respeitadas**:
  - Sem ataques volumétricos de negação de serviço (DoS/DDoS)
  - Sem tentativas de força bruta massiva contra contas reais
  - Sem alteração ou exfiltração de dados
  - Sem execução de comandos arbitrários ou instalação de persistência
- **Contatos Técnicos**:
  - Responsável: Mariana Souza (`mariana.souza@techlab-ficticio.local`)

---

## 3. Metodologia Aplicada

A auditoria seguiu o padrão do **AI Security Auditor**, integrando as melhores práticas dos frameworks:
- **OWASP Top 10 Web Application Security Risks (2021)**
- **OWASP API Security Top 10 (2023)**
- **PTES (Penetration Testing Execution Standard)**
- **CVSS v3.1** para mensuração de severidade e risco

---

## 4. Ferramentas Utilizadas

| Ferramenta | Versão | Finalidade Específica |
| :--- | :--- | :--- |
| `Semgrep` | 1.78.0 | Análise estática de código-fonte (SAST) e detecção de padrões inseguros |
| `Gitleaks` | 8.18.2 | Detecção de credenciais e segredos no histórico do Git |
| `Trivy` | 0.50.1 | Verificação de CVEs conhecidas em bibliotecas e dependências (SCA) |
| `Scripts de Validação` | 1.0.0 | Validação de escopo e higienização automática de relatórios |

---

## 5. Limitações Metodológicas

1. **Restrições Volumétricas**: Testes de estresse de carga e concorrência massiva não foram realizados para manter a estabilidade do laboratório.
2. **Ambiente Sintético**: Os testes foram executados com credenciais e bases de teste sintéticas fornecidas previamente pela equipe de engenharia.
3. **Isolamento de Terceiros**: Gateways externos de pagamento e serviços de entrega de terceiros foram excluídos das análises.

---

## 6. Descobertas e Vulnerabilidades Detalhadas

### FIND-0001: Broken Object Level Authorization (BOLA/IDOR) no Endpoint de Faturas

* **Status**: `confirmed`
* **Severidade**: `high`
* **Pontuação CVSS v3.1**: `7.5` (`CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N`)
* **Classificação CWE**: `CWE-639: Authorization Bypass Through User-Controlled Key`
* **Probabilidade de Exploração**: `high`

#### Descrição Técnica
O endpoint `GET /api/v1/invoices/{invoice_id}` não valida se a fatura solicitada pertence à organização do usuário autenticado. Foi verificado que um usuário autenticado sintético (`user_a`) conseguiu visualizar faturas pertencentes ao `user_b` apenas alterando o parâmetro numérico no caminho da requisição.

#### Evidência Sanitizada
```http
GET /api/v1/invoices/9842 HTTP/1.1
Host: api-homolog.techlab-ficticio.local
Authorization: Bearer eyJhbGciOi...[TOKEN REDACTED]...
Accept: application/json

HTTP/1.1 200 OK
Content-Type: application/json

{
  "invoice_id": 9842,
  "organization_id": "org_beta_corp",
  "amount_cents": 145000,
  "status": "paid"
}
```

#### Impacto
Exposição indevida de dados financeiros, volumes de faturamento e dados comerciais de outras organizações para qualquer usuário autenticado.

#### Recomendações de Correção
1. **Curto Prazo**: Validar na camada de serviço se `invoice.organization_id == current_user.organization_id`. Se divergente, retornar `HTTP 404 Not Found` ou `HTTP 403 Forbidden`.
2. **Longo Prazo**: Utilizar identificadores não previsíveis (UUID v4) e implementar filtros de autorização em nível de repositório de dados.

---

### FIND-0002: Ausência de Rate Limiting no Endpoint de Recuperação de Senha

* **Status**: `confirmed`
* **Severidade**: `medium`
* **Pontuação CVSS v3.1**: `5.3` (`CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:L/A:N`)
* **Classificação CWE**: `CWE-307: Improper Restriction of Excessive Authentication Attempts`
* **Probabilidade de Exploração**: `medium`

#### Descrição Técnica
O endpoint `POST /api/v1/auth/forgot-password` permite o envio repetido de solicitações de recuperação de senha sem limites por endereço IP ou por conta alvo em uma mesma janela temporal.

#### Evidência Sanitizada
Envio controlado de 15 solicitações consecutivas a partir da mesma origem em intervalo de 10 segundos para uma conta sintética de teste resultou em 15 respostas `HTTP 200 OK` com disparo simultâneo de e-mails de redefinição.

#### Impacto
Risco de exaustão de cota do provedor de envio transacional de e-mails (abuso de recursos) e potencial incômodo para usuários cadastrados através de envio massivo de notificações.

#### Recomendações de Correção
Configurar limitador de taxa (ex: máximo de 3 requisições a cada 15 minutos por conta e por IP) com armazenamento em cache distribuído (Redis).

---

### FIND-0003: Política de Row Level Security (RLS) Permissiva na Tabela de Perfis

* **Status**: `insecure_configuration`
* **Severidade**: `medium`
* **Pontuação CVSS v3.1**: `6.5` (`CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N`)
* **Classificação CWE**: `CWE-284: Improper Access Control`
* **Probabilidade de Exploração**: `high`

#### Descrição Técnica
Na configuração do PostgreSQL/Supabase, a tabela `user_profiles` possui política de leitura (SELECT) configurada com `USING (true);`, permitindo que qualquer cliente conectado com a chave anônima pública (`anon_key`) consulte telefones e endereços de todos os usuários cadastrados.

#### Evidência Sanitizada
```sql
-- Arquivo: migrations/20260901_profiles.sql
CREATE POLICY profiles_read_all ON public.user_profiles
FOR SELECT USING (true);
```

#### Impacto
Exposição pública de dados de contato e perfil de todos os usuários da aplicação sem necessidade de credencial administrativa.

#### Recomendações de Correção
Restringir a cláusula `USING` para permitir leitura pública apenas de campos especificamente públicos ou restringir a consulta para `auth.uid() = user_id`.

---

### FIND-0004: Ausência de Cabeçalhos de Segurança HTTP de Endurecimento

* **Status**: `insecure_configuration`
* **Severidade**: `low`
* **Pontuação CVSS v3.1**: `3.1` (`CVSS:3.1/AV:N/AC:H/PR:N/UI:R/S:U/C:L/I:N/A:N`)
* **Classificação CWE**: `CWE-16: Configuration`
* **Probabilidade de Exploração**: `low`

#### Descrição Técnica
As respostas da aplicação web não incluem os cabeçalhos `Strict-Transport-Security` (HSTS) e `X-Content-Type-Options: nosniff`.

#### Evidência Sanitizada
Inspeção passiva de cabeçalhos HTTP nas respostas do endpoint `portal-homolog.techlab-ficticio.local` confirmou a ausência dos parâmetros recomendados.

#### Impacto
Redução das defesas em profundidade contra ataques de rebaixamento de conexão (SSL stripping) e interpretação incorreta de tipos MIME em navegadores legados.

#### Recomendações de Correção
Configurar o proxy reverso / gateway (Nginx/Cloudflare) para injetar:
`Strict-Transport-Security: max-age=31536000; includeSubDomains` e `X-Content-Type-Options: nosniff`.

---

## 7. Conclusão e Próximos Passos

A auditoria identificou vulnerabilidades que demandam atenção prioritária, em especial a falha de controle de acesso por objeto (BOLA) na API de faturas e a política excessivamente permissiva de RLS. As demais correções envolvem ajustes de taxa e endurecimento de cabeçalhos. O sistema apresenta boa base estrutural e não foram detectados segredos expostos no repositório avaliado.
