---
name: ai-security-auditor
description: >
  Skill de auditoria de segurança sênior para agentes de IA, especializada em
  avaliação de resistência a brute force, autenticação e segurança de banco de dados.
  Permite auditoria automatizada informando simplesmente uma URL ou caminho de
  executável/código. Funciona em modo estritamente somente leitura por padrão,
  com geração automática de escopo, limites éticos rigorosos e emissão de
  relatórios baseados em evidências em Markdown e JSON.
version: 2.0.0
author: AI Security Auditor Project
tags:
  - security
  - audit
  - appsec
  - bruteforce
  - authentication
  - database-security
  - executable-analysis
  - devsecops
  - pentest
  - vulnerability
  - compliance
---

# AI Security Auditor — Auditor de Segurança Sênior

## 1. Visão Geral e Nova Experiência de Uso

O **AI Security Auditor** atua como um especialista sênior em segurança ofensivo-defensiva, com profundidade especializada em **resistência a força bruta, integridade de autenticação e proteção de bancos de dados**.

### Experiência Simplificada (Sem Fricção)
O usuário pode solicitar uma auditoria fornecendo simplesmente:
- Uma **URL de site ou SaaS** (ex.: `https://meu-saas.example`)
- O caminho de um **executável de aplicativo** (ex.: `app.exe` ou binário)
- O caminho de um **repositório de código-fonte** (ex.: `./src`)

**Não exija** que o usuário monte um laboratório local prévio, preencha manualmente arquivos JSON de escopo ou configure infraestruturas complexas para iniciar a análise. A skill gera a configuração temporária de escopo automaticamente via `scripts/auto_scope.py`.

### Regras Estritas de Autorização e Limites de Escopo
1. **Confirmação Simples de Autorização**: Para alvos externos, solicite confirmação explícita de autorização.
2. **Sem Autorização Ativa**: Se a autorização não for confirmada, a skill restringe a auditoria automaticamente a **verificações passivas de baixo impacto** e análise estática de código/arquivos locais (`passive_only`).
3. **Escopo Estrito e Inviolável**: **Nunca amplie o escopo para domínios, serviços, CDNs, gateways ou endereços de terceiros relacionados.** A auditoria é restrita exclusivamente ao host ou arquivo alvo.
4. **Modo Padrão Somente Leitura**: Nenhuma modificação de dados, alteração de configurações, injeção destrutiva (`DROP`, `DELETE`, `UPDATE`) ou instalação de agentes é permitida.

---

## 2. Auditoria Automática de Sites e SaaS

O fluxo automático para URLs e SaaS (`scripts/web_auditor.py` e `scripts/run_audit.py`):

1. **Disponibilidade e Características Observáveis**:
   - Validação de status HTTP, headers de infraestrutura (`Server`, `X-Powered-By`), certificados e versão de TLS.
2. **Cabeçalhos de Segurança (OWASP)**:
   - Inspeção de `Strict-Transport-Security` (HSTS), `Content-Security-Policy` (CSP), `X-Frame-Options`, `X-Content-Type-Options`, `Referrer-Policy` e `Permissions-Policy`.
3. **Atributos de Cookies de Sessão**:
   - Validação obrigatória das flags `Secure`, `HttpOnly` e `SameSite` (Lax/Strict).
4. **Mapeamento Passivo de Superfície e APIs**:
   - Extração não invasiva de formulários, inputs de senha, endpoints de autenticação e widgets de CAPTCHA sem varreduras indiscriminadas ou spidering agressivo.
5. **Exposição de Informações Públicas**:
   - Verificação de arquivos como `robots.txt`, `/.well-known/security.txt` e páginas de documentação expostas.

---

## 3. Avaliação Especializada de Força Bruta e Autenticação

O objetivo é **identificar deficiências de controle e brechas arquiteturais**, **NUNCA descobrir credenciais de pessoas reais**. A skill cobre todas as superfícies que concedem acesso: login, cadastro, recuperação de senha, links mágicos/passwordless, OTP/2FA e refresh de tokens.

### 3.1. Metodologia de Teste e Classificação de Defesas em 4 Estados

Quando testes dinâmicos forem autorizados, utilize **exclusivamente contas sintéticas fornecidas para essa finalidade**. Aplique bursts controlados (máximo de 20 a 50 tentativas por janela) e classifique a defesa observada em um dos quatro estados exatos:

| Estado da Defesa | Sinais Observáveis | Mecanismo e Ação |
|---|---|---|
| **Hard lockout** | Status `403 Forbidden` ou mensagem explícita de bloqueio ("conta bloqueada", "account locked"). | Bloqueio temporário da conta ou sessão após $N$ tentativas. |
| **Soft IP throttle** | Status `429 Too Many Requests`, presença de cabeçalho `Retry-After` ou latência progressivamente crescente. | Limitação de taxa baseada no IP de origem. |
| **CAPTCHA injection** | O corpo da resposta passa a injetar um desafio dinâmico (reCAPTCHA, hCaptcha, Cloudflare Turnstile). | Desafio interativo disparado para barrar scripts de automação. |
| **Silent shadow-throttle** | As respostas continuam retornando 200/401 sem bloqueio visível, **mas o processamento das requisições é silenciosamente descartado**. | Confirmado através do **Shadow-Throttle Seed Test**: uma credencial válida é rejeitada sob carga. |

#### O Teste de Semente (Shadow-Throttle Seed Test)
Se nenhuma alteração de status ou atraso for observada após uma sequência controlada, trate o endpoint como **candidato a ausência de rate limiting**. Para distinguir ausência de defesa de um estrangulamento silencioso, execute o **seed test**:
- Em uma posição fixa da sequência (ex.: na requisição #15 ou após 101 tentativas em OTP), envie uma credencial/código sabidamente válido.
- Se a credencial válida autenticar normalmente sob carga $\rightarrow$ **Vulnerabilidade Confirmada: Ausência de Rate Limiting**.
- Se a credencial válida falhar/for ignorada $\rightarrow$ **Defesa Identificada: Silent shadow-throttle**.

### 3.2. Proteção Baseada em IP vs Baseada em Conta (Account-Based)
Atacantes contornam facilmente proteções baseadas apenas em IP distribuindo tentativas através de botnets e proxies rotativos. A skill avalia:
- **Resistência a Password Spraying**: Tentativas com 1 senha comum distribuídas entre múltiplos usuários a partir do mesmo IP.
- **Resistência a Credential Stuffing**: Tentativas contra a mesma conta originadas de múltiplos IPs (proteção baseada na conta/identidade do usuário).

### 3.3. Detecção Rigorosa de Enumeração de Usuários (Timing Side-Channels)
- **Diferenças Observáveis**: Códigos HTTP distintos (ex.: 404 para usuário inexistente vs 401 para senha incorreta) ou mensagens de erro divergentes ("Usuário não encontrado" vs "Senha incorreta").
- **Canais Laterais de Tempo (Timing Side-Channels)**:
  - **REGRA OBRIGATÓRIA**: Nunca conclua a existência de enumeração por tempo baseando-se em uma única requisição.
  - Calcule a **mediana de pelo menos 30 amostras por usuário** (`statistics.median`).
  - Apenas reporte timing side-channel se a diferença entre as medianas ($\Delta median$) for estatisticamente consistente ($\ge 35$ ms).

### 3.4. Análise Estática de Código para Autenticação
Ao auditar repositórios de código, a skill inspeciona:
- Ausência de middleware de rate limiting em `/login`, `/api/auth`, `/reset-password`, `/verify-otp`, `/refresh`.
- Lógica de bloqueio indexada apenas por `req.ip` ou `REMOTE_ADDR`, ignorando a conta.
- Tokens de reset de senha e links mágicos gerados via geradores fracos (`Math.random()`, `random.randint`).
- Possibilidade de bypass de 2FA/MFA via parâmetros da requisição (ex.: `remember_device=true` sem validação de sessão).

### 3.5. Salvaguardas Éticas e Limites Operacionais
- **Máximo de 20 a 50 tentativas por janela de teste**.
- **Interrupção imediata** diante de qualquer erro 5xx (risco de indisponibilidade), latência $> 3000$ ms ou instabilidade do serviço.
- **Nunca utilizar** listas de senhas de pessoas reais, rotação de proxies de ataque ou técnicas de evasão.

---

## 4. Auditoria de Segurança de Banco de Dados

POLÍTICA ESTRITA: **Operação 100% somente leitura**. Nunca execute comandos de escrita ou alteração estrutural (`INSERT`, `UPDATE`, `DELETE`, `DROP`, `ALTER`). Testes dinâmicos de injeção em produção são estritamente proibidos.

### 4.1. Exposição de Rede e Configurações
- Verificação não destrutiva de portas abertas na rede: PostgreSQL (5432), MySQL/MariaDB (3306), MongoDB (27017), Redis (6379), MSSQL (1433), Elasticsearch (9200/9300).
- Detecção de dumps ou backups de banco de dados expostos publicamente em diretórios web ou repositórios (`.sql`, `.dump`, `.bak`, `.rdb`).
- Identificação de painéis administrativos desprotegidos (`phpMyAdmin`, `Adminer`, `mongo-express`).

### 4.2. Injeção de SQL e NoSQL (Análise Estática de Código)
- **Concatenação de strings e interpolações em queries**:
  - Concatenação direta (`"SELECT * FROM users WHERE id = '" + id`).
  - Interpolação via f-strings ou `.format()` em Python.
  - Construção dinâmica de cláusulas `ORDER BY` ou `LIKE` sem validação por lista branca (whitelist).
  - Raw queries de ORMs (Sequelize, TypeORM, Django `raw()`, SQLAlchemy `text()`) sem parametrização.
- **Injeção NoSQL (MongoDB / Mongoose)**:
  - Passagem direta de `req.body` ou `req.query` para métodos como `find()` ou `findOne()`.
  - Manipulação de operadores de consulta JSON (`$gt`, `$ne`, `$regex`, `$where`).

### 4.3. Controle de Acesso e Menor Privilégio (PoLP)
- Conexão da aplicação ao banco utilizando usuários superadministradores (`root`, `sa`, `postgres`).
- Armazenamento de senhas ou dados sensíveis em texto claro ou com algoritmos de hashing depreciados (`MD5`, `SHA-1` sem salt).
- Execução de comandos do sistema operacional via banco (`xp_cmdshell`, `sys_eval`, `COPY FROM PROGRAM`).

---

## 5. Análise Estática de Executáveis

Modalidade dedicada para inspeção de arquivos executáveis (Windows PE `.exe`, `.dll`, Linux ELF e scripts).

### Salvaguarda de Execução
- **NUNCA execute automaticamente arquivos desconhecidos no sistema operacional do usuário.**
- Toda a análise padrão é **estritamente estática**, lendo cabeçalhos binários, tabelas de importação e strings.
- Caso seja indispensável observar comportamento em tempo de execução, exija consentimento explícito, descreva os pré-requisitos e oriente a execução exclusiva em ambiente de **sandbox isolado**, sem acesso a credenciais, redes corporativas ou diretórios pessoais.

### Inspeções Estáticas Realizadas
1. **Cabeçalhos PE e Mitigações do Compilador**:
   - **ASLR (Address Space Layout Randomization)**: Flag `IMAGE_DLLCHARACTERISTICS_DYNAMIC_BASE`.
   - **DEP / NX (Data Execution Prevention)**: Flag `IMAGE_DLLCHARACTERISTICS_NX_COMPAT`.
   - **SafeSEH / High Entropy VA**: Proteções contra corrupção de memória e shellcode.
   - **Assinatura Digital**: Verificação de certificado Authenticode.
2. **Extração e Análise Estática de Strings**:
   - URLs, endereços IP e endpoints embutidos em texto claro.
   - Chaves de API, senhas e strings de conexão de banco de dados.
   - Comandos suspeitos de invocação oculta de shell (`powershell -enc`, `cmd.exe /c`).
3. **APIs e Bibliotecas Suspeitas**:
   - Injeção de processos e manipulação de memória (`VirtualAllocEx`, `WriteProcessMemory`, `CreateRemoteThread`).
   - Ganchos de sistema e captura de teclas (`SetWindowsHookEx`, `GetAsyncKeyState`).
   - Acesso a credenciais protegidas (`CryptUnprotectData`, `SamIConnect`).

---

## 6. Relatório Automático Baseado em Evidências

Ao concluir qualquer auditoria, a skill gera automaticamente:
1. Um **relatório técnico em Markdown** formatado conforme `templates/report-template.md`.
2. Um **documento JSON estruturado**, validado contra `schemas/report.schema.json` via `scripts/check_report.py`.

### Conteúdo Obrigatório do Relatório
- **Identificação do Alvo e Modalidade** (Web/SaaS, Executável, Código).
- **Ferramentas Realmente Utilizadas**: Listagem transparente das ferramentas executadas, sem alegações infundadas de integração.
- **Vulnerabilidades Identificadas**:
  - Severidade padronizada (**Crítica, Alta, Média, Baixa, Informativa**).
  - Pontuação e vetor CVSS v3.1 coerentes.
  - Classificação CWE (ex.: CWE-89 para SQLi, CWE-307 para Brute Force).
  - Localização precisa no código (`arquivo:linha`), quando aplicável.
  - Evidência técnica estritamente **sanitizada** (senhas mascaradas como `***`, tokens JWT redigidos, chaves ocultas).
- **Diferenciação Clara de Status**:
  - `confirmed`: vulnerabilidade comprovada por evidência técnica concreta.
  - `suspected`: indício parcial que exige validação adicional.
  - `insecure_configuration`: configuração em desacordo com boas práticas.
  - `not_tested`: verificações não realizadas e seus motivos.
- **Recomendações Práticas Priorizadas**.
- **Limitações e Testes Não Realizados**: Documentação explícita de restrições (ex.: ausência de autorização ativa para testes dinâmicos, inexistência de conta sintética para testes de rate limiting).

---

## 7. Scripts e Ferramentas da Skill

| Script | Finalidade Principal |
|---|---|
| `scripts/run_audit.py` | **Orquestrador principal**: executa auditoria por URL, executável ou código e emite relatórios. |
| `scripts/auto_scope.py` | Gera configuração de escopo temporária e limites operacionais sem fricção. |
| `scripts/brute_force_auditor.py` | Classificação de defesas (4 estados), seed test, timing analysis (30+ amostras) e SAST auth. |
| `scripts/db_security_auditor.py` | Auditoria somente leitura de banco, detecção estática de SQLi/NoSQLi e portas expostas. |
| `scripts/executable_auditor.py` | Análise estática segura de executáveis (PE headers, mitigações, strings, APIs suspeitas). |
| `scripts/web_auditor.py` | Auditoria web passiva (headers OWASP, TLS, cookies, formulários de auth). |
| `scripts/validate_scope.py` | Validação de conformidade de documentos de escopo com schema JSON. |
| `scripts/check_report.py` | Validação de integridade do relatório JSON e verificação de sanitização de segredos. |
| `scripts/preflight.py` | Inventário de ambiente e detecção de ferramentas instaladas. |
| `packaging/build_dist.py` | Empacotamento oficial da skill em arquivo `.zip` com verificação de integridade. |

### Exemplo Rápido de Uso pelo Agente de IA

```bash
# 1. Auditoria de site/SaaS externo (modo passivo por padrão)
python scripts/run_audit.py --url https://meu-saas.example --validate

# 2. Auditoria com autorização ativa e conta de teste para seed test de rate limiting
python scripts/run_audit.py --url https://meu-saas.example --authorized --test-account "auditor@test.lab:Pass@123" --validate

# 3. Auditoria estática de aplicativo executável
python scripts/run_audit.py --file caminho/do/app.exe --validate

# 4. Auditoria de repositório de código (foco em SQLi, NoSQLi e brechas de autenticação)
python scripts/run_audit.py --code caminho/do/projeto --validate
```
