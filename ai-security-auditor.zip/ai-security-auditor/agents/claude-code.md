# Adaptador para Claude Code

## Visão Geral

Este documento descreve como instalar, configurar e utilizar a skill **AI Security Auditor** no Claude Code. O Claude Code é um agente de codificação que opera diretamente no terminal, com acesso ao sistema de arquivos, execução de comandos e integração com ferramentas de desenvolvimento.

---

## Instalação da Skill

### 1. Estrutura de diretórios

A skill deve ser instalada no diretório de skills do Claude Code, dentro do projeto:

```
.claude/
└── skills/
    └── ai-security-auditor/
        ├── skill.md              # Arquivo principal da skill
        ├── integrations/
        │   ├── semgrep.md
        │   ├── zap.md
        │   ├── trivy.md
        │   ├── gitleaks.md
        │   └── nmap.md
        ├── agents/
        │   └── claude-code.md
        ├── templates/
        │   ├── scope-template.json
        │   ├── audit-checklist.md
        │   └── report-template.md
        └── examples/
            ├── sample-scope.json
            └── sample-report.md
```

### 2. Copiar arquivos

**Bash (Linux/macOS):**
```bash
# Criar diretório de destino
mkdir -p .claude/skills/ai-security-auditor

# Copiar todos os arquivos da skill
cp -r caminho/para/ai-security-auditor/* .claude/skills/ai-security-auditor/
```

**PowerShell (Windows):**
```powershell
# Criar diretório de destino
New-Item -ItemType Directory -Path ".claude/skills/ai-security-auditor" -Force

# Copiar todos os arquivos da skill
Copy-Item -Path "caminho/para/ai-security-auditor/*" -Destination ".claude/skills/ai-security-auditor/" -Recurse
```

### 3. Verificar instalação

```bash
# Verificar estrutura
find .claude/skills/ai-security-auditor -type f | head -20
```

---

## Configuração Específica do Claude Code

### Integração com CLAUDE.md

O `CLAUDE.md` é o arquivo de configuração principal do Claude Code para um projeto. Adicione instruções sobre a skill de auditoria de segurança:

```markdown
# CLAUDE.md

## Skills Disponíveis

### AI Security Auditor
- **Localização**: `.claude/skills/ai-security-auditor/`
- **Descrição**: Skill para auditoria de segurança de aplicações
- **Ativação**: Consulte `.claude/skills/ai-security-auditor/skill.md` quando solicitado a realizar auditoria de segurança

### Instruções para auditoria de segurança:
1. Sempre consulte `.claude/skills/ai-security-auditor/skill.md` antes de iniciar
2. Verifique ferramentas disponíveis (semgrep, trivy, gitleaks, nmap, zap)
3. Utilize os templates em `.claude/skills/ai-security-auditor/templates/`
4. Siga os guias de integração em `.claude/skills/ai-security-auditor/integrations/`
5. NUNCA execute auto-fix sem aprovação explícita
6. NUNCA escaneie fora do escopo autorizado
7. Sempre redatar segredos encontrados antes de exibir

### Ferramentas de segurança:
- `semgrep` — Análise estática de código (SAST)
- `trivy` — Análise de dependências e contêineres
- `gitleaks` — Detecção de segredos em repositórios Git
- `nmap` — Varredura de rede (requer autorização explícita)
- `zap` — Varredura de aplicações web (requer autorização explícita)
```

### Configuração de permissões

O Claude Code solicita confirmação antes de executar comandos potencialmente destrutivos. Para ferramentas de segurança, as seguintes configurações são recomendadas:

**Comandos que o Claude Code pode executar diretamente (leitura):**
- `semgrep --version`
- `trivy --version`
- `gitleaks version`
- `nmap --version`
- `semgrep scan --config=auto --json ...`
- `trivy fs --format json ...`
- `gitleaks detect --report-format json ...`

**Comandos que devem sempre solicitar confirmação:**
- `nmap` (qualquer varredura de rede)
- `zap.sh` / `zap.exe` (qualquer operação do ZAP)
- Qualquer comando com `--autofix` ou `--fix`

### Arquivo `.claude/settings.json` (exemplo)

```json
{
  "permissions": {
    "allow": [
      "semgrep scan *",
      "trivy fs *",
      "trivy image *",
      "trivy config *",
      "gitleaks detect *",
      "gitleaks protect *"
    ],
    "deny": [
      "semgrep scan --autofix *",
      "rm -rf *",
      "nmap * -T5 *",
      "nmap * --script=exploit *"
    ]
  }
}
```

---

## Referenciando a Skill

### Como ativar a skill no Claude Code

No Claude Code, você pode referenciar arquivos e diretórios para que o agente os leia e siga as instruções:

```
Por favor, leia o arquivo .claude/skills/ai-security-auditor/skill.md
e execute uma auditoria de segurança neste projeto.
```

### Referenciando guias de integração

```
Leia o guia em .claude/skills/ai-security-auditor/integrations/semgrep.md
e execute uma varredura de segurança no código-fonte com Semgrep.
```

### Referenciando templates

```
Use o template em .claude/skills/ai-security-auditor/templates/report-template.md
para gerar o relatório de auditoria com os resultados já coletados.
```

### Referenciando exemplos

```
Consulte o exemplo em .claude/skills/ai-security-auditor/examples/sample-scope.json
e crie um documento de escopo para a auditoria deste projeto.
```

---

## Usando as Ferramentas do Claude Code com a Skill

### Execução de comandos

O Claude Code executa comandos diretamente no terminal, o que permite:

```bash
# O Claude Code executará estes comandos quando solicitado

# Verificar ferramentas
semgrep --version
trivy --version
gitleaks version

# Executar varreduras
semgrep scan --config=p/security-audit --json --output=audit-results/semgrep.json ./src/
trivy fs --severity HIGH,CRITICAL --format json --output audit-results/trivy.json .
gitleaks detect --source . --report-format json --report-path audit-results/gitleaks.json
```

### Leitura e análise de arquivos

O Claude Code pode ler e analisar os resultados das varreduras:

```
Leia os resultados em audit-results/semgrep.json e audit-results/trivy.json.
Consolide as vulnerabilidades encontradas e classifique por severidade.
```

### Criação de arquivos

O Claude Code pode criar relatórios e documentos:

```
Crie o relatório de auditoria em audit-reports/relatorio.md
usando o template em .claude/skills/ai-security-auditor/templates/report-template.md
e os resultados em audit-results/.
```

---

## Dicas de Integração com CLAUDE.md

### Seção de contexto do projeto

Adicione ao `CLAUDE.md` informações sobre o projeto que ajudam na auditoria:

```markdown
## Contexto do Projeto

### Stack tecnológica:
- Backend: Python 3.11 + FastAPI
- Frontend: React 18 + TypeScript
- Banco de dados: PostgreSQL 15
- Cache: Redis 7
- Infraestrutura: AWS (ECS, RDS, ElastiCache)
- CI/CD: GitHub Actions

### Estrutura do código:
- `src/api/` — Endpoints da API
- `src/core/` — Lógica de negócio
- `src/models/` — Modelos de dados
- `src/services/` — Serviços externos
- `tests/` — Testes automatizados
- `infrastructure/` — IaC (Terraform)
- `docker/` — Dockerfiles

### Arquivos sensíveis:
- `.env` — Variáveis de ambiente (não commitado)
- `infrastructure/secrets/` — Segredos de infraestrutura
- `src/core/auth/` — Lógica de autenticação
```

### Seção de regras de segurança

```markdown
## Regras de Segurança

### NUNCA:
- Executar `--autofix` do Semgrep sem revisão manual
- Exibir segredos encontrados pelo Gitleaks sem redatar
- Executar varreduras Nmap sem verificar autorização
- Executar varredura ativa do ZAP sem aprovação explícita
- Escanear diretórios ou hosts fora do escopo definido

### SEMPRE:
- Verificar escopo antes de qualquer varredura
- Documentar cada varredura executada
- Classificar vulnerabilidades por severidade
- Fornecer recomendações de correção
- Redatar informações sensíveis em relatórios
```

---

## Exemplo de Fluxo de Trabalho no Claude Code

### Sessão 1: Preparação

```
Vou iniciar uma auditoria de segurança neste projeto.

1. Leia .claude/skills/ai-security-auditor/skill.md para entender o processo
2. Verifique quais ferramentas de segurança estão instaladas
3. Crie os diretórios: audit-results/, audit-reports/, audit-scope/
4. Gere um documento de escopo baseado no template
   (.claude/skills/ai-security-auditor/templates/scope-template.json)
```

### Sessão 2: Varreduras

```
Execute as seguintes varreduras de segurança:

1. Semgrep: varredura com p/security-audit e p/owasp-top-ten no diretório src/
2. Trivy: análise de dependências com severidade HIGH e CRITICAL
3. Gitleaks: detecção de segredos no repositório completo

Salve todos os resultados em audit-results/ em formato JSON.
Siga os guias em .claude/skills/ai-security-auditor/integrations/
```

### Sessão 3: Análise e Relatório

```
Analise os resultados em audit-results/ e gere o relatório final.

1. Leia todos os arquivos de resultado
2. Consolide vulnerabilidades por severidade
3. Identifique os achados mais críticos
4. Use o template de relatório em
   .claude/skills/ai-security-auditor/templates/report-template.md
5. Gere o relatório em audit-reports/relatorio-auditoria.md
6. Preencha a checklist em
   .claude/skills/ai-security-auditor/templates/audit-checklist.md
```

---

## Solução de Problemas

### Ferramentas não encontradas

Se o Claude Code não encontrar uma ferramenta:

1. Verifique se está instalada: `which semgrep` ou `Get-Command semgrep`
2. Verifique o PATH do sistema
3. Tente instalar via gerenciador de pacotes:
   ```bash
   pip install semgrep
   brew install trivy gitleaks nmap
   ```

### Permissões negadas

Se o Claude Code recusar executar um comando:

1. Verifique as configurações de permissão em `.claude/settings.json`
2. Confirme manualmente quando solicitado pelo Claude Code
3. Ajuste as permissões se necessário (mas nunca para comandos destrutivos)

### Resultados muito grandes

Para projetos grandes com muitos achados:

1. Filtre por severidade: `--severity HIGH,CRITICAL`
2. Limite o escopo: use `--include` e `--exclude`
3. Peça ao Claude Code para processar os resultados em partes
4. Foque primeiro nas vulnerabilidades críticas

### CLAUDE.md não sendo lido

Se o Claude Code não parecer seguir as instruções do CLAUDE.md:

1. Verifique se o arquivo está no diretório raiz do projeto
2. Verifique se o conteúdo está formatado corretamente em Markdown
3. Referencie explicitamente: "Leia o CLAUDE.md e siga as instruções de auditoria"
