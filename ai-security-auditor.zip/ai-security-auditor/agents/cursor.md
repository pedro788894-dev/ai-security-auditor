# Adaptador para Cursor

## Visão Geral

Este documento descreve como instalar, configurar e utilizar a skill **AI Security Auditor** no editor Cursor. O Cursor é um editor de código com IA integrada que permite executar tarefas complexas de desenvolvimento e análise diretamente no ambiente de edição.

---

## Instalação da Skill

### 1. Estrutura de diretórios

A skill deve ser instalada no diretório de skills do Cursor, dentro do projeto:

```
.cursor/
└── skills/
    └── ai-security-auditor/
        ├── skill.md              # Arquivo principal da skill
        ├── integrations/
        │   ├── semgrep.md
        │   ├── zap.md
        │   ├── trivy.md
        │   ├── gitleaks.md
        │   └── nmap.md
        ├── agents/
        │   └── cursor.md
        ├── templates/
        │   ├── scope-template.json
        │   ├── audit-checklist.md
        │   └── report-template.md
        └── examples/
            ├── sample-scope.json
            └── sample-report.md
```

### 2. Copiar arquivos

**PowerShell (Windows):**
```powershell
# Criar diretório de destino
New-Item -ItemType Directory -Path ".cursor/skills/ai-security-auditor" -Force

# Copiar todos os arquivos da skill
Copy-Item -Path "caminho/para/ai-security-auditor/*" -Destination ".cursor/skills/ai-security-auditor/" -Recurse
```

**Bash (Linux/macOS):**
```bash
# Criar diretório e copiar
mkdir -p .cursor/skills/ai-security-auditor
cp -r caminho/para/ai-security-auditor/* .cursor/skills/ai-security-auditor/
```

### 3. Verificar instalação

```powershell
# Windows
Get-ChildItem -Path ".cursor/skills/ai-security-auditor" -Recurse | Select-Object FullName

# Linux/macOS
find .cursor/skills/ai-security-auditor -type f
```

---

## Configuração Específica do Cursor

### Arquivo de regras do projeto (`.cursor/rules`)

Para que o Cursor reconheça e utilize a skill automaticamente, adicione as seguintes regras ao arquivo de configuração do projeto:

```markdown
# .cursor/rules

## Skill: AI Security Auditor

Quando solicitado a realizar auditoria de segurança, consulte a skill em
`.cursor/skills/ai-security-auditor/skill.md` para instruções completas.

### Ferramentas de segurança disponíveis:
- Semgrep (análise estática de código)
- Trivy (análise de dependências e contêineres)
- Gitleaks (detecção de segredos)
- OWASP ZAP (varredura de aplicações web)
- Nmap (varredura de rede)

### Documentação de integrações:
- `.cursor/skills/ai-security-auditor/integrations/` contém guias para cada ferramenta
- `.cursor/skills/ai-security-auditor/templates/` contém templates de escopo, checklist e relatório
- `.cursor/skills/ai-security-auditor/examples/` contém exemplos de escopo e relatório

### Regras de segurança:
- Nunca execute auto-fix sem aprovação explícita
- Sempre verifique o escopo antes de executar varreduras
- Redatar segredos encontrados antes de exibir
- Documentar todas as varreduras executadas
```

### Configuração do `.cursorignore`

Adicione os diretórios de resultados de auditoria ao `.cursorignore` para evitar indexação desnecessária:

```text
# .cursorignore
audit-results/
*.sarif
gitleaks-results.json
nmap-results.xml
```

---

## Referenciando a Skill em Prompts

### Como referenciar a skill no chat do Cursor

No Cursor, você pode referenciar arquivos diretamente no chat usando `@`. Para utilizar a skill:

```
@.cursor/skills/ai-security-auditor/skill.md

Preciso realizar uma auditoria de segurança no código deste projeto.
Por favor, siga as instruções da skill referenciada.
```

### Referenciando documentação específica

```
@.cursor/skills/ai-security-auditor/integrations/semgrep.md

Execute uma varredura Semgrep no projeto seguindo as instruções deste guia.
Use os conjuntos de regras p/security-audit e p/owasp-top-ten.
```

### Referenciando templates

```
@.cursor/skills/ai-security-auditor/templates/report-template.md

Gere um relatório de auditoria usando este template.
Preencha com os resultados das varreduras já executadas.
```

### Referenciando exemplos

```
@.cursor/skills/ai-security-auditor/examples/sample-scope.json

Crie um documento de escopo para minha auditoria seguindo este exemplo.
O projeto é uma API REST em Node.js hospedada em AWS.
```

---

## Configuração do Workspace

### Pré-requisitos

Antes de utilizar a skill, verifique se as ferramentas necessárias estão acessíveis via terminal do Cursor:

1. Abra o terminal integrado do Cursor (`Ctrl+`` ` ou `Cmd+`` `)
2. Verifique cada ferramenta:

```bash
# Verificar ferramentas instaladas
semgrep --version
trivy --version
gitleaks version
nmap --version
```

### Estrutura recomendada do workspace

```
projeto/
├── .cursor/
│   ├── rules                      # Regras do Cursor
│   └── skills/
│       └── ai-security-auditor/   # Skill instalada
├── audit-results/                 # Resultados das varreduras
├── audit-reports/                 # Relatórios gerados
├── audit-scope/                   # Documentação de escopo
│   └── scope.json
└── src/                           # Código-fonte
```

### Configuração do `.gitignore`

Adicione ao `.gitignore` do projeto:

```gitignore
# Resultados de auditoria de segurança (contêm dados sensíveis)
audit-results/
audit-reports/
*.sarif
gitleaks-results.json
nmap-results.xml
trivy-results.json
semgrep-results.json
```

---

## Usando o Terminal do Cursor

O terminal integrado do Cursor é essencial para executar as ferramentas de segurança. Exemplos de uso:

### Varredura com Semgrep

```bash
# No terminal do Cursor
semgrep scan --config=p/security-audit --config=p/owasp-top-ten --json --output=audit-results/semgrep-results.json ./src/
```

### Varredura com Trivy

```bash
trivy fs --severity HIGH,CRITICAL --format json --output audit-results/trivy-results.json .
```

### Varredura com Gitleaks

```bash
gitleaks detect --source . --report-format json --report-path audit-results/gitleaks-results.json
```

### Dica: Composer Mode

No Cursor, utilize o **Composer Mode** (`Ctrl+I` ou `Cmd+I`) para tarefas mais complexas que envolvem múltiplos arquivos:

```
Execute uma auditoria de segurança completa:
1. Rode Semgrep com p/security-audit no diretório src/
2. Rode Trivy para verificar dependências
3. Rode Gitleaks para detectar segredos
4. Consolide os resultados e gere um relatório

Siga as instruções em @.cursor/skills/ai-security-auditor/skill.md
```

---

## Exemplo de Fluxo de Trabalho no Cursor

### Passo 1: Preparação

No chat do Cursor:
```
@.cursor/skills/ai-security-auditor/skill.md

Vou iniciar uma auditoria de segurança neste projeto.
Por favor:
1. Verifique quais ferramentas de segurança estão disponíveis no terminal
2. Crie a estrutura de diretórios para auditoria (audit-results/, audit-reports/, audit-scope/)
3. Gere um documento de escopo inicial baseado no template
```

### Passo 2: Varreduras

No Composer:
```
@.cursor/skills/ai-security-auditor/integrations/semgrep.md
@.cursor/skills/ai-security-auditor/integrations/trivy.md
@.cursor/skills/ai-security-auditor/integrations/gitleaks.md

Execute as varreduras de segurança seguindo os guias de integração referenciados.
Salve todos os resultados em audit-results/ em formato JSON.
```

### Passo 3: Análise

```
Analise os resultados em audit-results/ e crie um resumo:
- Quantas vulnerabilidades por severidade
- Quais são as mais críticas
- Quais segredos foram encontrados (redatados)
- Dependências com CVEs conhecidas
```

### Passo 4: Relatório

```
@.cursor/skills/ai-security-auditor/templates/report-template.md

Gere o relatório final de auditoria usando este template.
Preencha todas as seções com os dados reais da auditoria.
Salve em audit-reports/relatorio-auditoria.md
```

---

## Dicas e Solução de Problemas

### Ferramentas não encontradas no terminal

Se uma ferramenta não for encontrada no terminal do Cursor:

1. Verifique se está instalada globalmente no sistema.
2. Verifique se o PATH do sistema inclui o diretório da ferramenta.
3. Reinicie o Cursor após instalar novas ferramentas.
4. No Windows, use o terminal PowerShell no Cursor.

### Skill não reconhecida

Se o Cursor não reconhecer a skill:

1. Verifique se o arquivo `skill.md` existe em `.cursor/skills/ai-security-auditor/`.
2. Referencie o arquivo diretamente com `@` no chat.
3. Verifique se o arquivo `.cursor/rules` contém as regras da skill.

### Performance em projetos grandes

Para projetos grandes, otimize as varreduras:

1. Use `--include` e `--exclude` para limitar o escopo das ferramentas.
2. Execute uma ferramenta por vez para evitar consumo excessivo de recursos.
3. Foque inicialmente em severidades HIGH e CRITICAL.
