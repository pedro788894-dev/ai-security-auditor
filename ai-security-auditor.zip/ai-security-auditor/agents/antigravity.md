# Adaptador para Google Antigravity

## Visão Geral

Este documento descreve como instalar, configurar e utilizar a skill **AI Security Auditor** no ambiente Google Antigravity. O Antigravity é um agente de IA que executa tarefas complexas diretamente no seu ambiente de desenvolvimento, com acesso a terminal, sistema de arquivos e ferramentas de desenvolvimento.

---

## Instalação da Skill

### 1. Estrutura de diretórios

A skill deve ser instalada no diretório de skills do Antigravity:

```
.agents/
└── skills/
    └── ai-security-auditor/
        ├── skill.md              # Arquivo principal da skill
        ├── integrations/
        │   ├── semgrep.md
        │   ├── zap.md
        │   ├── trivy.md
        │   ├── gitleaks.md
        │   └── nmap.md
        ├── agents/
        │   └── antigravity.md
        ├── templates/
        │   ├── scope-template.json
        │   ├── audit-checklist.md
        │   └── report-template.md
        └── examples/
            ├── sample-scope.json
            └── sample-report.md
```

### 2. Copiar arquivos

```powershell
# Criar diretório de destino
New-Item -ItemType Directory -Path ".agents/skills/ai-security-auditor" -Force

# Copiar todos os arquivos da skill
Copy-Item -Path "caminho/para/ai-security-auditor/*" -Destination ".agents/skills/ai-security-auditor/" -Recurse
```

### 3. Verificar instalação

Após copiar os arquivos, verifique que a estrutura está correta:

```powershell
Get-ChildItem -Path ".agents/skills/ai-security-auditor" -Recurse | Select-Object FullName
```

---

## Configuração Específica do Antigravity

### Ativação da Skill

No Antigravity, as skills são ativadas automaticamente quando presentes no diretório `.agents/skills/`. Para garantir que a skill está ativa:

1. Verifique se o diretório `.agents/skills/ai-security-auditor/` contém o arquivo `skill.md`.
2. O Antigravity carregará a skill automaticamente na próxima interação.

### Configuração do Workspace

Para melhor experiência com a skill de auditoria de segurança, configure o workspace:

1. **Defina o diretório do projeto como workspace ativo** no Antigravity.
2. Certifique-se de que as ferramentas externas necessárias estão instaladas e acessíveis via terminal:
   - Semgrep
   - Trivy
   - Gitleaks
   - Nmap (se aplicável)
   - OWASP ZAP (se aplicável)

### Verificar ferramentas disponíveis

Peça ao Antigravity para verificar as ferramentas instaladas:

```
Verifique quais ferramentas de segurança estão instaladas no sistema:
semgrep, trivy, gitleaks, nmap e OWASP ZAP.
```

---

## Usando as Ferramentas do Antigravity com a Skill

### Terminal

O Antigravity pode executar comandos diretamente no terminal, o que é essencial para:

- Executar varreduras com Semgrep, Trivy, Gitleaks e Nmap
- Iniciar o OWASP ZAP em modo daemon
- Processar resultados de varreduras

### Sistema de Arquivos

O Antigravity pode ler e criar arquivos, útil para:

- Ler o documento de escopo da auditoria
- Analisar resultados de varreduras (JSON, XML, SARIF)
- Gerar o relatório de auditoria
- Criar checklists preenchidas

### Pesquisa Web

O Antigravity pode pesquisar informações online para:

- Consultar detalhes de CVEs encontradas
- Verificar recomendações de correção
- Consultar documentação de ferramentas

---

## Comandos Recomendados

### Iniciar uma auditoria

```
Inicie uma auditoria de segurança no projeto atual.
Use o template de escopo em .agents/skills/ai-security-auditor/templates/scope-template.json
como referência para definir o escopo.
```

### Executar varredura de código

```
Execute uma varredura de segurança no código-fonte usando Semgrep e Gitleaks.
Foque em vulnerabilidades de severidade alta e crítica.
Salve os resultados em ./audit-results/.
```

### Verificar dependências

```
Verifique vulnerabilidades nas dependências do projeto usando Trivy.
Liste todas as CVEs com severidade HIGH e CRITICAL e suas correções disponíveis.
```

### Verificar segredos

```
Execute o Gitleaks para verificar se há segredos expostos no repositório.
Inclua o histórico completo de commits na análise.
Redatar qualquer segredo encontrado antes de exibir.
```

### Gerar relatório

```
Gere um relatório de auditoria de segurança completo baseado nos resultados coletados.
Use o template em .agents/skills/ai-security-auditor/templates/report-template.md.
Inclua todas as vulnerabilidades encontradas, classificadas por severidade.
```

### Revisar checklist

```
Revise a checklist de auditoria em .agents/skills/ai-security-auditor/templates/audit-checklist.md
e marque os itens que já foram verificados nesta auditoria.
Identifique os itens pendentes que ainda precisam de atenção.
```

---

## Exemplo de Fluxo de Trabalho Completo

### Passo 1: Preparação

```
Preciso realizar uma auditoria de segurança no projeto atual.
Por favor:
1. Verifique quais ferramentas de segurança estão instaladas
2. Crie um documento de escopo baseado no template
3. Me apresente a checklist de auditoria
```

### Passo 2: Varreduras automatizadas

```
Execute as seguintes varreduras de segurança no projeto:
1. Semgrep com regras p/security-audit e p/owasp-top-ten
2. Trivy para análise de dependências
3. Gitleaks para detecção de segredos

Salve todos os resultados em ./audit-results/ em formato JSON.
```

### Passo 3: Análise dos resultados

```
Analise os resultados das varreduras em ./audit-results/ e:
1. Consolide todas as vulnerabilidades encontradas
2. Classifique por severidade (crítica, alta, média, baixa)
3. Identifique falsos positivos óbvios
4. Sugira correções para as vulnerabilidades confirmadas
```

### Passo 4: Geração do relatório

```
Gere o relatório final de auditoria usando o template oficial.
Inclua:
- Resumo executivo
- Todas as vulnerabilidades encontradas
- Evidências (redatadas quando necessário)
- Recomendações de correção
- Matriz de risco
```

---

## Recomendações de Configuração do Workspace

### Estrutura recomendada do projeto durante auditoria

```
projeto/
├── .agents/
│   └── skills/
│       └── ai-security-auditor/    # Skill instalada
├── audit-results/                  # Resultados das varreduras
│   ├── semgrep-results.json
│   ├── trivy-results.json
│   ├── gitleaks-results.json
│   └── nmap-results.xml
├── audit-reports/                  # Relatórios gerados
│   ├── relatorio-auditoria.md
│   └── checklist-preenchida.md
├── audit-scope/                    # Documentação de escopo
│   └── scope.json
└── src/                            # Código-fonte do projeto
    └── ...
```

### Boas práticas

1. **Defina o workspace** como o diretório raiz do projeto que será auditado.
2. **Crie diretórios separados** para resultados, relatórios e documentação de escopo.
3. **Não commite resultados brutos** no repositório — eles podem conter informações sensíveis.
4. **Adicione ao .gitignore**:
   ```gitignore
   audit-results/
   audit-reports/
   *.sarif
   gitleaks-results.json
   ```
