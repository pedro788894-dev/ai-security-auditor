# Segurança de Executáveis e Binários — Guia de Auditoria

> Documento de referência para auditoria estática defensiva de arquivos executáveis e binários.
> Padrão: **Análise estática estritamente segura sem execução de binários desconhecidos no sistema hospedeiro.**

---

## 1. Visão Geral

A auditoria de segurança em aplicativos compilados (como binários Windows `.exe`/`.dll`, executáveis Linux ELF e instaladores) visa identificar deficiências de mitigação de compilador, segredos e endpoints expostos em texto claro, e a presença de APIs com potencial invasivo ou malicioso.

> 🔴 **REGRA ABSOLUTA DE SEGURANÇA**: NUNCA execute arquivos binários de origem desconhecida ou não confiável diretamente no sistema operacional do usuário. Toda análise inicial deve ser **100% estática**. Se a observação dinâmica de comportamento em tempo de execução for necessária, exija consentimento explícito e utilize exclusivamente um **ambiente de sandbox isolado**, sem acesso a credenciais, dados pessoais ou redes internas.

---

## 2. Mitigações de Segurança do Compilador (PE Header)

Ao analisar executáveis Windows (Portable Executable), inspecione os bits do campo `DllCharacteristics` no cabeçalho opcional (*Optional Header*):

| Mitigação | Flag / Bit | Impacto de Segurança | Recomendação |
|---|---|---|---|
| **ASLR (Address Space Layout Randomization)** | `IMAGE_DLLCHARACTERISTICS_DYNAMIC_BASE` (`0x0040`) | Carrega o executável em endereços de memória aleatórios a cada execução, dificultando ataques de ROP (*Return-Oriented Programming*) e buffer overflow. | Habilitar `/DYNAMICBASE` no linker. |
| **DEP / NX (Data Execution Prevention)** | `IMAGE_DLLCHARACTERISTICS_NX_COMPAT` (`0x0100`) | Impede que a CPU execute código armazenado em regiões marcadas apenas para dados (pilha e heap), bloqueando shellcodes injetados. | Habilitar `/NXCOMPAT` no linker. |
| **High Entropy VA** | `IMAGE_DLLCHARACTERISTICS_HIGH_ENTROPY_VA` (`0x0020`) | Permite a utilização de espaço de endereçamento de 64 bits completo para aleatorização ASLR. | Habilitar `/HIGHENTROPYVA` em binários de 64 bits. |
| **SafeSEH** | `IMAGE_DLLCHARACTERISTICS_NO_SEH` (`0x0400`) ou tabela de SEH protegida | Impede que atacantes sobrescrevam ponteiros de Structured Exception Handling para redirecionar o fluxo de execução (x86). | Habilitar `/SAFESEH`. |
| **Control Flow Guard (CFG)** | `IMAGE_DLLCHARACTERISTICS_GUARD_CF` (`0x4000`) | Valida a integridade de chamadas indiretas de funções antes de executá-las, mitigando corrupção de fluxo de controle. | Habilitar `/guard:cf`. |
| **Assinatura Digital (Authenticode)** | Tabela de certificados de segurança (`IMAGE_DIRECTORY_ENTRY_SECURITY`) | Garante a autenticidade da autoria e a integridade do código contra adulteração pós-compilação. | Assinar com certificado corporativo via `signtool.exe`. |

---

## 3. Extração e Análise Estática de Strings

Executáveis frequentemente contêm strings ASCII e UTF-16 LE legíveis recuperáveis a partir dos dados brutos:

### 3.1. Indicadores a Inspecionar
- **Endpoints de Rede e URLs**: Detecção de URLs em texto plano (`https://api.exemplo.com`), serviços de comando e controle (C2) ou telemetria invasiva.
- **Strings de Conexão com Banco de Dados**: Conexões diretas a PostgreSQL, MySQL, SQL Server ou MongoDB embutidas no binário.
- **Credenciais Hardcoded**: Senhas de serviço, tokens JWT, chaves de API (`AKIA...`, `api_key=...`) e certificados PEM.
- **Invocação de Shell e Comandos Ocultos**: Strings contendo `powershell.exe -enc`, `cmd.exe /c`, `wscript.exe` ou `curl/wget` silenciosos.

---

## 4. Tabela de Importações e APIs Sensíveis

A tabela de importações (*Import Address Table - IAT*) revela as chamadas de sistema que o binário é capaz de realizar:

### 4.1. Injeção de Código e Manipulação de Memória
- `VirtualAllocEx` / `WriteProcessMemory`: Alocação e escrita em espaço de memória de processo remoto.
- `CreateRemoteThread` / `NtCreateThreadEx`: Criação de thread de execução em processo de terceiros.
- `QueueUserAPC` / `SetThreadContext`: Desvio de fluxo de execução em threads existentes (*Thread Hijacking*).

### 4.2. Spyware e Captura de Dados
- `SetWindowsHookExA` / `SetWindowsHookExW`: Instalação de ganchos globais de teclado ou mouse (*Keylogging*).
- `GetAsyncKeyState` / `GetKeyState`: Monitoramento de pressionamento de teclas em tempo real.
- `BitBlt` / `GetDC`: Captura de tela e espionagem de janelas.

### 4.3. Acesso a Credenciais
- `CryptUnprotectData`: Acesso a segredos protegidos pelo DPAPI do Windows (senhas salvas no Chrome, Edge, etc.).
- `SamIConnect` / `LsaRetrievePrivateData`: Extração de segredos e credenciais locais do sistema.

---

## 5. Pré-requisitos para Observação em Tempo de Execução (Sandbox)

Quando a análise estática for inconclusiva e houver necessidade documentada de observar o comportamento dinâmico do executável:

1. **Consentimento Explícito do Usuário**: Nunca execute o binário sem autorização documentada.
2. **Isolamento Completo (Sandbox)**:
   - Utilizar uma Máquina Virtual descartável ou container dedicado (ex.: Windows Sandbox, VM sem conectividade de rede à LAN interna).
   - Sem acesso a pastas compartilhadas do host, credenciais locais ou diretórios de perfil de usuário.
3. **Monitoramento Instrumentado**:
   - Registrar criação de processos (Sysmon Event ID 1).
   - Monitorar conexões de rede (Sysmon Event ID 3).
   - Monitorar alterações de chaves de registro de persistência (`Run`, `RunOnce`).
