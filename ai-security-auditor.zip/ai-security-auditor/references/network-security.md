# Segurança de Rede — Guia de Auditoria

> Documento de referência para auditoria de segurança de rede em ativos **explicitamente autorizados**.
> Toda varredura e teste de rede deve ser realizada apenas dentro do escopo autorizado.

---

## 1. Visão Geral

A auditoria de segurança de rede avalia a exposição e configuração de serviços de rede, identificando vulnerabilidades na camada de transporte, protocolos criptográficos e segmentação. Este guia define a metodologia para avaliação segura de infraestrutura de rede.

> 🔴 **REGRA ABSOLUTA**: NUNCA realizar varreduras em alvos não autorizados. Cada IP, domínio ou faixa de rede deve estar explicitamente listado no escopo da auditoria. Varreduras não autorizadas podem constituir crime cibernético.

---

## 2. Metodologia de Varredura de Portas

### 2.1. Pré-Requisitos

Antes de iniciar qualquer varredura:

- [ ] Autorização escrita e documentada para os alvos específicos
- [ ] Lista de IPs/domínios/faixas autorizadas confirmada
- [ ] Janela de tempo para varredura acordada
- [ ] Contato de emergência do cliente disponível
- [ ] Verificar se IPs do auditor estão na allowlist (se necessário)
- [ ] Rate limiting definido para não impactar serviços

### 2.2. Abordagem Gradual

A varredura deve seguir uma abordagem **gradual**, do menos intrusivo para o mais intrusivo:

```
Nível 1: Varredura TCP SYN (mais comum, menos intrusivo)
         ↓
Nível 2: Varredura de versão de serviços
         ↓
Nível 3: Varredura UDP (mais lento, gera mais tráfego)
         ↓
Nível 4: Scripts NSE para verificações específicas
```

### 2.3. Comandos Nmap Recomendados

> ⚠️ **IMPORTANTE**: Todos os comandos abaixo devem ser executados **apenas contra alvos autorizados**.

#### Nível 1 — Descoberta e Portas TCP Comuns

```bash
# Varredura SYN das 1000 portas mais comuns
# -sS: SYN scan (half-open, menos intrusivo)
# -T3: Timing template moderado (não agressivo)
# --max-rate 500: Limitar taxa de pacotes
# -oA: Salvar resultados em todos os formatos
nmap -sS -T3 --max-rate 500 -oA scan_tcp_common <ALVO_AUTORIZADO>
```

#### Nível 2 — Detecção de Versão

```bash
# Varredura de versão apenas nas portas abertas encontradas
# -sV: Detecção de versão
# -p <portas>: Apenas portas identificadas na varredura anterior
nmap -sV -T3 --max-rate 300 -p <PORTAS_ABERTAS> -oA scan_versions <ALVO_AUTORIZADO>
```

#### Nível 3 — Portas UDP Comuns

```bash
# Varredura UDP das portas mais relevantes
# -sU: UDP scan
# --top-ports 50: Apenas as 50 portas UDP mais comuns
nmap -sU --top-ports 50 -T3 --max-rate 200 -oA scan_udp <ALVO_AUTORIZADO>
```

#### Nível 4 — Scripts de Verificação Seguros

```bash
# Scripts NSE seguros (não exploram vulnerabilidades)
# --script=safe: Apenas scripts classificados como seguros
nmap --script=safe -p <PORTAS_ABERTAS> -T3 --max-rate 200 -oA scan_scripts <ALVO_AUTORIZADO>

# Verificação específica de TLS/SSL
nmap --script=ssl-enum-ciphers -p 443 -oA scan_tls <ALVO_AUTORIZADO>
```

### 2.4. Controles de Intensidade e Rate Limiting

| Template (-T) | Nome | Pacotes/segundo | Uso |
|---|---|---|---|
| T0 | Paranoid | ~1/5min | IDS evasion (raro em auditorias) |
| T1 | Sneaky | ~1/15s | IDS evasion (raro em auditorias) |
| T2 | Polite | ~1/0.4s | Redes sensíveis |
| **T3** | **Normal** | Adaptativo | **Padrão recomendado** |
| T4 | Aggressive | Rápido | Redes resilientes (com autorização) |
| T5 | Insane | Máximo | ❌ Evitar — pode causar DoS |

**Parâmetros de controle adicionais:**

```bash
--max-rate <pacotes/s>    # Limite máximo de pacotes por segundo
--max-retries <n>         # Limite de retransmissões
--host-timeout <tempo>    # Timeout por host
--scan-delay <ms>         # Delay mínimo entre probes
```

### 2.5. Scripts Nmap Proibidos

**NUNCA utilizar scripts que exploram vulnerabilidades ou causam danos:**
- Scripts da categoria `exploit`
- Scripts da categoria `dos`
- Scripts da categoria `brute` (sem autorização específica)
- Scripts que modificam dados no alvo
- Scripts `vuln` devem ser usados com cautela (apenas verificação, sem exploração)

---

## 3. Identificação de Serviços e Versões

### 3.1. Serviços Comuns e Riscos

| Porta | Serviço | Risco se Exposto | Verificação |
|---|---|---|---|
| 21 | FTP | Login anônimo, texto plano | Verificar auth anônima, FTPS |
| 22 | SSH | Acesso remoto | Versão, autenticação por chave, algoritmos |
| 23 | Telnet | ❌ Texto plano, sem criptografia | Deve ser desabilitado |
| 25 | SMTP | Relay aberto, spoofing | SPF, DKIM, DMARC |
| 53 | DNS | Transferência de zona, amplificação | Zone transfer, recursão |
| 80 | HTTP | Dados em texto plano | Redirecionamento para HTTPS |
| 110 | POP3 | Texto plano | Deve usar POP3S (995) |
| 143 | IMAP | Texto plano | Deve usar IMAPS (993) |
| 443 | HTTPS | Configuração TLS | Verificar protocolos e cifras |
| 445 | SMB | Compartilhamento de arquivos | Autenticação, versão, signing |
| 1433 | MSSQL | Banco de dados | Não expor publicamente |
| 3306 | MySQL | Banco de dados | Não expor publicamente |
| 3389 | RDP | Acesso remoto Windows | NLA, criptografia, exposição |
| 5432 | PostgreSQL | Banco de dados | Não expor publicamente |
| 5900 | VNC | Acesso remoto | Criptografia, autenticação |
| 6379 | Redis | Cache/banco de dados | ❌ Frequentemente sem autenticação |
| 8080/8443 | HTTP alternativo | Aplicações web | Mesmas verificações de HTTP/HTTPS |
| 27017 | MongoDB | Banco de dados | ❌ Frequentemente sem autenticação |

### 3.2. Checklist de Verificação por Serviço

Para cada serviço identificado, documentar:

```markdown
## Serviço: [nome]
- **Porta**: [número]
- **Versão detectada**: [versão]
- **CVEs conhecidas para esta versão**: [lista]
- **Exposição**: Público / Interno
- **Necessidade de exposição**: Justificada / Não justificada
- **Configuração**: Adequada / Inadequada
- **Recomendações**: [ações]
```

---

## 4. Avaliação de TLS/SSL

### 4.1. Protocolos

| Protocolo | Status | Ação |
|---|---|---|
| SSL 2.0 | ❌ Inseguro | Deve estar desabilitado |
| SSL 3.0 | ❌ Inseguro (POODLE) | Deve estar desabilitado |
| TLS 1.0 | ❌ Depreciado | Deve estar desabilitado |
| TLS 1.1 | ❌ Depreciado | Deve estar desabilitado |
| **TLS 1.2** | ✅ Aceitável | Com cipher suites seguras |
| **TLS 1.3** | ✅ Recomendado | Melhor segurança e performance |

### 4.2. Cipher Suites

**Recomendadas (TLS 1.3):**
```
TLS_AES_256_GCM_SHA384
TLS_CHACHA20_POLY1305_SHA256
TLS_AES_128_GCM_SHA256
```

**Recomendadas (TLS 1.2):**
```
ECDHE-ECDSA-AES256-GCM-SHA384
ECDHE-RSA-AES256-GCM-SHA384
ECDHE-ECDSA-CHACHA20-POLY1305
ECDHE-RSA-CHACHA20-POLY1305
ECDHE-ECDSA-AES128-GCM-SHA256
ECDHE-RSA-AES128-GCM-SHA256
```

**Inseguras (devem ser desabilitadas):**
- Cipher suites com `RC4` — vulnerável a ataques
- Cipher suites com `DES` ou `3DES` — tamanho de bloco pequeno
- Cipher suites com `MD5` — hash comprometido
- Cipher suites sem `ECDHE` ou `DHE` — sem forward secrecy
- Cipher suites com `NULL` — sem criptografia
- Cipher suites com `EXPORT` — chaves fracas

### 4.3. Ferramentas de Verificação

```bash
# Usando nmap
nmap --script ssl-enum-ciphers -p 443 <ALVO_AUTORIZADO>

# Usando openssl (verificação manual)
openssl s_client -connect <ALVO_AUTORIZADO>:443 -tls1_2
openssl s_client -connect <ALVO_AUTORIZADO>:443 -tls1_3

# Verificar suporte a protocolo inseguro
openssl s_client -connect <ALVO_AUTORIZADO>:443 -tls1  # Não deve conectar
openssl s_client -connect <ALVO_AUTORIZADO>:443 -ssl3  # Não deve conectar
```

### 4.4. Vulnerabilidades TLS Conhecidas

| Vulnerabilidade | Descrição | Como Verificar |
|---|---|---|
| POODLE | SSL 3.0 / CBC padding oracle | Verificar se SSL 3.0 está habilitado |
| BEAST | TLS 1.0 CBC | Verificar se TLS 1.0 está habilitado |
| CRIME | Compressão TLS | Verificar se compressão está habilitada |
| BREACH | Compressão HTTP | Verificar compressão HTTP com dados sensíveis |
| Heartbleed | OpenSSL bug (CVE-2014-0160) | Verificar versão do OpenSSL |
| FREAK | Export cipher suites | Verificar cipher suites EXPORT |
| Logjam | DH fraco (< 2048 bits) | Verificar parâmetros DH |
| ROBOT | RSA padding oracle | Verificar cipher suites RSA estáticas |
| DROWN | SSLv2 cross-protocol | Verificar se SSLv2 está habilitado |

---

## 5. Validação de Certificados

### 5.1. Checklist de Certificado

- [ ] Certificado emitido por CA confiável?
- [ ] Certificado não expirado?
- [ ] Certificado cobre o domínio correto (CN ou SAN)?
- [ ] Cadeia de certificados completa?
- [ ] Certificado não é auto-assinado (em produção)?
- [ ] Tamanho da chave adequado (RSA ≥ 2048 bits, ECDSA ≥ 256 bits)?
- [ ] Algoritmo de assinatura seguro (SHA-256 ou superior)?
- [ ] Certificate Transparency (CT) logs publicados?
- [ ] OCSP Stapling configurado?
- [ ] CAA records configurados no DNS?
- [ ] HSTS configurado (ver seção de headers HTTP)?
- [ ] Wildcard não é usado desnecessariamente?

### 5.2. Verificação de Certificado

```bash
# Verificar certificado
openssl s_client -connect <ALVO>:443 -servername <DOMINIO> </dev/null 2>/dev/null | \
  openssl x509 -noout -text

# Verificar expiração
openssl s_client -connect <ALVO>:443 -servername <DOMINIO> </dev/null 2>/dev/null | \
  openssl x509 -noout -dates

# Verificar cadeia completa
openssl s_client -connect <ALVO>:443 -servername <DOMINIO> -showcerts
```

---

## 6. Segurança de DNS

### 6.1. Verificações

- [ ] Zone transfer (AXFR) está restrito?
- [ ] DNSSEC está implementado?
- [ ] Registros SPF, DKIM e DMARC configurados (para domínios de email)?
- [ ] Registros CAA configurados?
- [ ] Recursão DNS está desabilitada em servidores autoritativos?
- [ ] Existem registros DNS que expõem infraestrutura interna?

### 6.2. Comandos de Verificação

```bash
# Verificar transferência de zona (deve falhar)
dig @<DNS_SERVER> <DOMINIO> AXFR

# Verificar DNSSEC
dig <DOMINIO> DNSKEY +dnssec
dig <DOMINIO> DS

# Verificar registros de email
dig <DOMINIO> TXT  # SPF
dig _dmarc.<DOMINIO> TXT  # DMARC
dig <seletor>._domainkey.<DOMINIO> TXT  # DKIM

# Verificar CAA
dig <DOMINIO> CAA

# Enumerar subdomínios (somente com autorização)
dig <DOMINIO> ANY
```

---

## 7. Análise de Regras de Firewall

### 7.1. Verificações

Se o acesso às regras de firewall for fornecido como parte do escopo:

- [ ] Regra padrão é DENY ALL (bloquear tudo por padrão)?
- [ ] Regras são específicas (não usam `any` desnecessariamente)?
- [ ] Não existem regras que permitem tráfego de `0.0.0.0/0` para portas sensíveis?
- [ ] Regras não utilizadas foram removidas?
- [ ] Existe segmentação entre ambientes (dev, staging, produção)?
- [ ] Tráfego de saída (egress) é filtrado?
- [ ] Logs de firewall estão habilitados?
- [ ] Existe revisão periódica de regras?

### 7.2. Regras Comumente Problemáticas

```
# ❌ INSEGURO - permite SSH de qualquer lugar
ALLOW TCP 0.0.0.0/0 -> <servidor>:22

# ✅ SEGURO - SSH apenas de IPs específicos
ALLOW TCP 203.0.113.10/32 -> <servidor>:22

# ❌ INSEGURO - permite todo tráfego
ALLOW ALL 0.0.0.0/0 -> <servidor>:*

# ❌ INSEGURO - banco de dados exposto publicamente
ALLOW TCP 0.0.0.0/0 -> <servidor>:5432

# ✅ SEGURO - banco de dados acessível apenas pela aplicação
ALLOW TCP 10.0.1.0/24 -> <servidor>:5432
```

---

## 8. Verificação de Segmentação de Rede

### 8.1. Princípios de Segmentação

- [ ] Ambientes estão separados (desenvolvimento, staging, produção)?
- [ ] Bancos de dados não são acessíveis diretamente da internet?
- [ ] Serviços internos não são expostos publicamente?
- [ ] Existe DMZ para serviços expostos à internet?
- [ ] A comunicação entre segmentos é controlada e monitorada?
- [ ] Microsegmentação está implementada para cargas de trabalho críticas?

### 8.2. Diagrama de Verificação de Segmentação

```
Internet → [Firewall/WAF] → DMZ (Web servers, APIs)
                              ↓ (regras específicas)
                         Rede Aplicação (App servers)
                              ↓ (regras específicas)
                         Rede Dados (Databases, caches)
                              ↓ (isolado)
                         Rede Gestão (Bastion, monitoring)
```

Verificar se cada camada tem controles de acesso adequados entre elas.

---

## 9. Documentação de Testes de Rede

### 9.1. Requisitos de Documentação

Para cada varredura ou teste de rede, registrar:

```markdown
## Varredura: [ID]

- **Data/Hora**: [timestamp UTC]
- **Alvo**: [IP/domínio — VERIFICADO NO ESCOPO]
- **Tipo**: [SYN scan / Version scan / UDP scan / Script scan]
- **Ferramenta**: [nmap versão X.XX]
- **Comando**: [comando completo utilizado]
- **Rate limiting**: [parâmetros de controle]
- **Duração**: [tempo total]
- **Resultados**: [resumo]
- **Arquivos de saída**: [caminhos dos arquivos .nmap, .xml, .gnmap]
- **Incidentes**: [qualquer problema observado durante a varredura]
```

### 9.2. Armazenamento de Resultados

- Salvar resultados em formato estruturado (XML do nmap para parsing)
- Sanitizar resultados antes de incluir em relatórios
- Não incluir informações de serviços/versões de ativos fora do escopo
- Manter registro de todas as atividades com timestamp

---

## 10. Serviços Comumente Expostos e Riscos

### 10.1. Redis (porta 6379)

```bash
# Verificar se aceita conexão sem autenticação
redis-cli -h <ALVO_AUTORIZADO> ping
# Se retornar "PONG", está sem autenticação — CRÍTICO
```

- Risco: Acesso total aos dados em cache, possível RCE
- Recomendação: Nunca expor publicamente, sempre exigir autenticação

### 10.2. MongoDB (porta 27017)

- Risco: Acesso sem autenticação, exfiltração de dados
- Verificação: Tentativa de conexão sem credenciais
- Recomendação: Habilitar autenticação, restringir bind address

### 10.3. Elasticsearch (portas 9200/9300)

- Risco: Acesso sem autenticação, exposição de dados indexados
- Verificação: `GET /` e `GET /_cat/indices`
- Recomendação: Habilitar X-Pack Security, restringir acesso

### 10.4. Memcached (porta 11211)

- Risco: Amplificação DDoS, acesso a dados em cache
- Verificação: Tentativa de conexão TCP/UDP
- Recomendação: Não expor publicamente, desabilitar UDP

---

## 11. Referências

- NIST SP 800-115 — Technical Guide to Information Security Testing and Assessment
- OWASP Testing Guide v4.2 — Network Testing
- CIS Benchmarks para configuração de serviços de rede
- Nmap Reference Guide: https://nmap.org/book/man.html
- Mozilla SSL Configuration Generator: https://ssl-config.mozilla.org/
- Qualys SSL Labs: https://www.ssllabs.com/ssltest/

---

*Última atualização: Outubro 2026*
*Referências cruzadas: [audit-methodology.md](./audit-methodology.md) | [safe-testing-policy.md](./safe-testing-policy.md) | [cloud-and-saas-security.md](./cloud-and-saas-security.md)*
