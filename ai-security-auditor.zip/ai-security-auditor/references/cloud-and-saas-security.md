# Segurança de Cloud e SaaS — Guia de Auditoria

> Documento de referência para auditoria de segurança de ambientes cloud e integrações SaaS.
> Cobre AWS, GCP, Azure, CI/CD, containers e conformidade.

---

## 1. Visão Geral

A migração para a nuvem trouxe novos vetores de ataque e modelos de responsabilidade compartilhada. Este guia cobre a auditoria de segurança de ambientes cloud, incluindo configurações de IAM, armazenamento, serverless, containers, pipelines CI/CD e integrações SaaS.

---

## 2. Modelo de Responsabilidade Compartilhada

| Camada | IaaS (EC2, Compute) | PaaS (Lambda, App Engine) | SaaS (Supabase, Auth0) |
|---|---|---|---|
| **Dados** | Cliente | Cliente | Cliente |
| **Aplicação** | Cliente | Cliente | Provedor |
| **Runtime** | Cliente | Provedor | Provedor |
| **SO** | Cliente | Provedor | Provedor |
| **Virtualização** | Provedor | Provedor | Provedor |
| **Rede** | Provedor | Provedor | Provedor |
| **Infraestrutura Física** | Provedor | Provedor | Provedor |

> **Princípio**: O provedor é responsável pela segurança **da** nuvem. O cliente é responsável pela segurança **na** nuvem.

---

## 3. Baselines de Segurança por Provedor Cloud

### 3.1. AWS (Amazon Web Services)

#### 3.1.1. Checklist de Segurança AWS

**Conta e Acesso:**
- [ ] MFA habilitado na conta root?
- [ ] Conta root não é usada para operações diárias?
- [ ] AWS Organizations configurado com SCPs (Service Control Policies)?
- [ ] CloudTrail habilitado em todas as regiões?
- [ ] GuardDuty habilitado?
- [ ] AWS Config habilitado para monitorar mudanças?

**Rede:**
- [ ] VPCs configuradas com subnets públicas e privadas?
- [ ] Security Groups seguem princípio de menor privilégio?
- [ ] NACLs configuradas como camada adicional?
- [ ] VPC Flow Logs habilitados?
- [ ] Endpoints VPC usados para serviços AWS (evitar tráfego público)?

**Armazenamento:**
- [ ] S3 buckets com Block Public Access habilitado por padrão?
- [ ] S3 buckets com criptografia em repouso (SSE-S3 ou SSE-KMS)?
- [ ] S3 bucket policies restritivas?
- [ ] Versionamento habilitado em buckets críticos?
- [ ] EBS volumes criptografados?
- [ ] RDS instances com criptografia habilitada?

**Logging e Monitoramento:**
- [ ] CloudWatch Logs configurado?
- [ ] Alertas configurados para atividades suspeitas?
- [ ] AWS Config rules para compliance?
- [ ] Access Analyzer habilitado para IAM?

### 3.2. GCP (Google Cloud Platform)

#### 3.2.1. Checklist de Segurança GCP

**Conta e Acesso:**
- [ ] Organização configurada com políticas organizacionais?
- [ ] MFA habilitado para todos os usuários?
- [ ] Contas de serviço com escopo mínimo?
- [ ] Audit Logs habilitados?
- [ ] Security Command Center habilitado?

**Rede:**
- [ ] VPC com firewall rules restritivas?
- [ ] Private Google Access habilitado?
- [ ] VPC Service Controls configurados para dados sensíveis?
- [ ] Cloud NAT usado para acesso de saída controlado?

**Armazenamento:**
- [ ] Cloud Storage buckets com acesso uniforme (Uniform Bucket-Level Access)?
- [ ] Criptografia gerenciada pelo cliente (CMEK) quando necessário?
- [ ] BigQuery com controle de acesso por dataset/tabela?

### 3.3. Azure

#### 3.3.1. Checklist de Segurança Azure

**Conta e Acesso:**
- [ ] Azure AD com MFA obrigatório?
- [ ] Conditional Access Policies configuradas?
- [ ] Privileged Identity Management (PIM) habilitado?
- [ ] Activity Logs encaminhados para SIEM?
- [ ] Azure Defender habilitado?

**Rede:**
- [ ] NSGs (Network Security Groups) configurados?
- [ ] Azure Firewall ou WAF implementado?
- [ ] Private Endpoints usados para serviços PaaS?
- [ ] Just-in-Time VM Access configurado?

**Armazenamento:**
- [ ] Storage Accounts com criptografia em repouso?
- [ ] Acesso público a blobs desabilitado por padrão?
- [ ] Shared Access Signatures (SAS) com expiração e escopo limitado?
- [ ] Key Vault usado para segredos?

---

## 4. IAM — Revisão de Políticas

### 4.1. Princípios de IAM

1. **Menor Privilégio**: Cada identidade deve ter apenas as permissões necessárias.
2. **Separação de Deveres**: Operações críticas requerem múltiplas identidades.
3. **Revisão Periódica**: Permissões devem ser revisadas regularmente.
4. **Credenciais Temporárias**: Preferir credenciais temporárias (assume role, federation) a chaves de acesso permanentes.

### 4.2. Verificações de IAM (AWS como exemplo)

```json
// ❌ INSEGURO - permissão total
{
  "Effect": "Allow",
  "Action": "*",
  "Resource": "*"
}

// ❌ INSEGURO - wildcard em ações
{
  "Effect": "Allow",
  "Action": "s3:*",
  "Resource": "arn:aws:s3:::*"
}

// ✅ SEGURO - permissões específicas
{
  "Effect": "Allow",
  "Action": [
    "s3:GetObject",
    "s3:PutObject"
  ],
  "Resource": "arn:aws:s3:::my-app-bucket/*"
}
```

**Checklist de IAM:**
- [ ] Nenhuma política com `Action: *` e `Resource: *`?
- [ ] Políticas inline minimizadas (preferir managed policies)?
- [ ] Chaves de acesso rotacionadas regularmente?
- [ ] Chaves de acesso não utilizadas removidas?
- [ ] Políticas de senha adequadas para usuários IAM?
- [ ] Service accounts/roles usados em vez de chaves de acesso?
- [ ] Cross-account access configurado com external IDs?
- [ ] Condições (conditions) usadas para restringir acesso?

---

## 5. Segurança de Storage (Buckets/Blobs)

### 5.1. Verificações Comuns

- [ ] Nenhum bucket/blob está publicamente acessível sem justificativa?
- [ ] ACLs não concedem acesso a `AllUsers` ou `AllAuthenticatedUsers`?
- [ ] Criptografia em repouso está habilitada?
- [ ] Criptografia em trânsito (HTTPS) é exigida?
- [ ] Versionamento está habilitado para dados críticos?
- [ ] Lifecycle policies estão configuradas para dados temporários?
- [ ] Logging de acesso está habilitado?
- [ ] CORS está configurado adequadamente (se aplicável)?

### 5.2. Detecção de Buckets Públicos

```bash
# AWS - Verificar se S3 bucket é público
aws s3api get-bucket-acl --bucket <BUCKET_NAME>
aws s3api get-bucket-policy --bucket <BUCKET_NAME>
aws s3api get-public-access-block --bucket <BUCKET_NAME>

# GCP - Verificar permissões do bucket
gsutil iam get gs://<BUCKET_NAME>
```

---

## 6. Segurança de Funções Serverless

### 6.1. Verificações

- [ ] Funções têm permissões IAM mínimas necessárias?
- [ ] Variáveis de ambiente não contêm segredos em texto plano?
- [ ] Segredos são obtidos de um secrets manager em runtime?
- [ ] Timeout adequado configurado (evitar runaway functions)?
- [ ] Limite de execuções concorrentes definido?
- [ ] Logging habilitado para debugging e auditoria?
- [ ] VPC configurada quando a função acessa recursos internos?
- [ ] Dependências são verificadas quanto a vulnerabilidades?
- [ ] Tamanho do payload de entrada é limitado?
- [ ] Tratamento de erros não expõe informações internas?

### 6.2. Riscos Específicos

| Risco | Descrição | Mitigação |
|---|---|---|
| **Injeção de evento** | Input malicioso via eventos (S3, API Gateway) | Validar e sanitizar inputs |
| **Permissões excessivas** | Role com acesso desnecessário | Princípio do menor privilégio |
| **Segredos expostos** | Variáveis de ambiente com chaves | Usar secrets manager |
| **Cold start timing** | Informações vazadas via timing | Não expor métricas de startup |
| **Dependências vulneráveis** | Libs com CVEs conhecidas | Scan de dependências |

---

## 7. Segurança de Containers

### 7.1. Checklist de Segurança de Containers

**Imagem:**
- [ ] Imagem base é oficial e verificada?
- [ ] Imagem base é atualizada regularmente?
- [ ] Vulnerabilidades na imagem foram escaneadas (Trivy, Snyk)?
- [ ] Imagem não roda como root?
- [ ] Imagem é minimal (distroless, Alpine)?
- [ ] Secrets não estão incluídos na imagem?
- [ ] `.dockerignore` exclui arquivos sensíveis?

**Runtime:**
- [ ] Container não roda com `--privileged`?
- [ ] Capabilities são dropadas (`--cap-drop ALL`)?
- [ ] Filesystem é read-only quando possível (`--read-only`)?
- [ ] Limites de recursos (CPU, memória) estão definidos?
- [ ] Health checks estão configurados?
- [ ] Network policies restringem tráfego entre containers?

**Dockerfile — Boas Práticas:**

```dockerfile
# ✅ SEGURO - multi-stage build, user não-root
FROM node:20-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

FROM node:20-alpine
RUN addgroup -S appgroup && adduser -S appuser -G appgroup
WORKDIR /app
COPY --from=builder /app/node_modules ./node_modules
COPY . .
USER appuser
EXPOSE 3000
CMD ["node", "server.js"]

# ❌ INSEGURO - roda como root, copia tudo
FROM node:20
COPY . /app
WORKDIR /app
RUN npm install
CMD ["node", "server.js"]
```

### 7.2. Kubernetes (se aplicável)

- [ ] RBAC configurado com princípio de menor privilégio?
- [ ] Pod Security Standards (Restricted) aplicadas?
- [ ] Network Policies implementadas?
- [ ] Secrets gerenciados via external secret manager?
- [ ] Service accounts com permissões mínimas?
- [ ] Ingress controllers com TLS configurado?
- [ ] Image pull policy é `Always` (não usar `latest` em produção)?

---

## 8. Segurança de Pipelines CI/CD

### 8.1. Verificações de Pipeline

- [ ] Secrets não estão hardcoded no pipeline (YAML, Jenkinsfile)?
- [ ] Secrets são injetados via mecanismo seguro do CI/CD?
- [ ] Pipeline não expõe secrets em logs?
- [ ] Artefatos de build não contêm secrets?
- [ ] SAST (Static Analysis) integrado no pipeline?
- [ ] SCA (Software Composition Analysis) integrado no pipeline?
- [ ] Container image scanning integrado?
- [ ] Branch protection rules configuradas?
- [ ] Code review obrigatório antes de merge?
- [ ] Deploy para produção requer aprovação?

### 8.2. Riscos de Pipeline

| Risco | Descrição | Mitigação |
|---|---|---|
| **Envenenamento de pipeline** | PR malicioso que modifica o pipeline | Branch protection, code review |
| **Dependency confusion** | Pacote malicioso com mesmo nome interno | Registry interno, namespace scoping |
| **Secrets em logs** | Secrets impressos em output do build | Masking de secrets, `--quiet` flags |
| **Supply chain attack** | Ação/plugin de CI comprometido | Fixar versões, verificar integridade |
| **Self-hosted runner comprometido** | Runner executando código malicioso | Runners efêmeros, isolamento |

### 8.3. GitHub Actions — Verificações Específicas

```yaml
# ❌ INSEGURO - usa ação sem fixar versão
- uses: actions/checkout@main

# ✅ SEGURO - fixa hash do commit
- uses: actions/checkout@b4ffde65f46336ab88eb53be808477a3936bae11 # v4.1.1

# ❌ INSEGURO - secret pode vazar
- run: echo ${{ secrets.API_KEY }}

# ✅ SEGURO - usa máscara
- run: echo "::add-mask::${{ secrets.API_KEY }}"
```

- [ ] Ações de terceiros fixadas por hash (não tag)?
- [ ] `GITHUB_TOKEN` tem permissões mínimas?
- [ ] Workflows não aceitam `pull_request_target` sem validação?
- [ ] Environments com proteção para deploy em produção?

---

## 9. Revisão de Integrações SaaS

### 9.1. Checklist de Integração

Para cada serviço SaaS integrado:

- [ ] Quais dados são compartilhados com o serviço?
- [ ] O serviço tem certificações de segurança (SOC 2, ISO 27001)?
- [ ] As permissões concedidas são mínimas necessárias (OAuth scopes)?
- [ ] Existe mecanismo de revogação de acesso?
- [ ] Dados são criptografados em trânsito e repouso?
- [ ] O serviço tem política de privacidade compatível com LGPD/GDPR?
- [ ] Existe plano de contingência se o serviço ficar indisponível?
- [ ] Webhooks são verificados (assinatura, HTTPS)?

### 9.2. Avaliação de Risco de Terceiros

| Fator | Baixo Risco | Médio Risco | Alto Risco |
|---|---|---|---|
| **Dados compartilhados** | Nenhum dado sensível | Dados operacionais | PII, financeiros |
| **Acesso ao sistema** | Somente leitura | Leitura e escrita limitada | Acesso administrativo |
| **Certificações** | SOC 2, ISO 27001 | Apenas políticas documentadas | Nenhuma |
| **Dependência** | Substituível facilmente | Algumas dependências | Crítico para operação |

---

## 10. Avaliação de Risco de Dependências

### 10.1. Verificações

- [ ] Dependências são escaneadas regularmente (Dependabot, Snyk, Trivy)?
- [ ] Dependências com CVEs conhecidas são atualizadas prontamente?
- [ ] Lock files (`package-lock.json`, `poetry.lock`) estão commitados?
- [ ] Registros de pacotes privados são autenticados?
- [ ] Integridade de pacotes é verificada (checksums)?
- [ ] Número de dependências transitivas é monitorado?
- [ ] Dependências abandonadas são identificadas e substituídas?

---

## 11. Infrastructure as Code (IaC) — Revisão de Segurança

### 11.1. Verificações de IaC

- [ ] Secrets não estão hardcoded em arquivos Terraform/CloudFormation/Pulumi?
- [ ] Security groups/firewall rules não permitem `0.0.0.0/0` desnecessariamente?
- [ ] Criptografia está habilitada para recursos de armazenamento e banco de dados?
- [ ] Logging está habilitado para todos os recursos críticos?
- [ ] Estado do Terraform (`.tfstate`) está armazenado de forma segura e criptografada?
- [ ] IaC é escaneado por ferramentas de segurança (Checkov, tfsec, Terrascan)?

### 11.2. Exemplo de Verificação Terraform

```hcl
# ❌ INSEGURO - S3 bucket público sem criptografia
resource "aws_s3_bucket" "data" {
  bucket = "my-data-bucket"
  acl    = "public-read"  # ❌
}

# ✅ SEGURO - S3 bucket privado com criptografia
resource "aws_s3_bucket" "data" {
  bucket = "my-data-bucket"
}

resource "aws_s3_bucket_public_access_block" "data" {
  bucket = aws_s3_bucket.data.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_server_side_encryption_configuration" "data" {
  bucket = aws_s3_bucket.data.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "aws:kms"
    }
  }
}
```

---

## 12. Gerenciamento de Segredos em Cloud

### 12.1. Serviços Recomendados

| Provedor | Serviço | Uso |
|---|---|---|
| AWS | Secrets Manager / Parameter Store | Armazenar e rotacionar segredos |
| GCP | Secret Manager | Armazenar segredos com versionamento |
| Azure | Key Vault | Armazenar chaves, segredos e certificados |
| Multi-cloud | HashiCorp Vault | Gerenciamento centralizado de segredos |

### 12.2. Verificações

- [ ] Segredos são armazenados em serviço dedicado (não em variáveis de ambiente estáticas)?
- [ ] Rotação automática está configurada para segredos críticos?
- [ ] Acesso a segredos é auditado (logs de acesso)?
- [ ] Segredos são versionados?
- [ ] Políticas de acesso seguem princípio do menor privilégio?
- [ ] Segredos não são logados ou expostos em outputs?

---

## 13. Logging e Monitoramento

### 13.1. Verificações

- [ ] Logs de auditoria estão habilitados para todos os serviços críticos?
- [ ] Logs são centralizados (CloudWatch, Stackdriver, Azure Monitor)?
- [ ] Logs são imutáveis (proteção contra adulteração)?
- [ ] Retenção de logs adequada está configurada?
- [ ] Alertas estão configurados para eventos de segurança?
- [ ] SIEM está integrado para correlação de eventos?
- [ ] Logs não contêm dados sensíveis (PII, senhas)?
- [ ] Dashboards de segurança estão disponíveis?

### 13.2. Eventos Críticos para Monitorar

| Evento | Prioridade | Ação |
|---|---|---|
| Login de root/admin | 🔴 Alta | Alerta imediato |
| Criação de usuário IAM com permissões elevadas | 🔴 Alta | Alerta imediato |
| Modificação de security group | 🟡 Média | Alerta e revisão |
| Bucket/blob tornado público | 🔴 Alta | Alerta imediato |
| Desabilitação de logging | 🔴 Alta | Alerta imediato |
| API calls de regiões não utilizadas | 🟡 Média | Investigar |
| Falhas repetidas de autenticação | 🟡 Média | Investigar |
| Criação de chaves de acesso | 🟡 Média | Alerta e revisão |

---

## 14. Considerações de Conformidade

### 14.1. LGPD (Lei Geral de Proteção de Dados)

Verificações relevantes para conformidade com a LGPD:

- [ ] Dados pessoais são inventariados (mapeamento de dados)?
- [ ] Base legal para processamento de dados pessoais está definida?
- [ ] Consentimento é obtido quando necessário e é revogável?
- [ ] Existe mecanismo para atender direitos dos titulares (acesso, correção, exclusão)?
- [ ] Dados pessoais são criptografados em repouso e trânsito?
- [ ] Existe DPO (Encarregado de Proteção de Dados) designado?
- [ ] Existe Relatório de Impacto à Proteção de Dados (RIPD)?
- [ ] Transferência internacional de dados é adequadamente tratada?
- [ ] Incidentes de segurança têm processo de notificação definido?
- [ ] Período de retenção de dados pessoais está definido e implementado?

### 14.2. GDPR (Considerações Básicas)

Para sistemas que processam dados de cidadãos da UE:

- [ ] Mesmas verificações da LGPD aplicam-se (similar em escopo)
- [ ] Privacy by Design e Privacy by Default implementados?
- [ ] Data Protection Impact Assessment (DPIA) realizado?
- [ ] Mecanismos de transferência internacional (SCCs, adequacy decisions)?
- [ ] Direito ao esquecimento implementado tecnicamente?
- [ ] Portabilidade de dados disponível?

---

## 15. Referências

- AWS Well-Architected Framework — Security Pillar: https://docs.aws.amazon.com/wellarchitected/latest/security-pillar/
- GCP Security Best Practices: https://cloud.google.com/security/best-practices
- Azure Security Benchmark: https://learn.microsoft.com/en-us/security/benchmark/azure/
- CIS Cloud Benchmarks: https://www.cisecurity.org/benchmark
- OWASP Cloud Security: https://owasp.org/www-project-cloud-security/
- LGPD (Lei 13.709/2018): https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/lei/l13709.htm

---

*Última atualização: Outubro 2026*
*Referências cruzadas: [audit-methodology.md](./audit-methodology.md) | [network-security.md](./network-security.md) | [database-security.md](./database-security.md) | [safe-testing-policy.md](./safe-testing-policy.md)*
