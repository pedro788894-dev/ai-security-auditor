# Segurança de Autenticação — Guia de Auditoria

> Documento de referência para auditoria de mecanismos de autenticação.
> Todos os testes devem ser realizados **exclusivamente com contas sintéticas** criadas para a auditoria.

---

## 1. Visão Geral

A autenticação é a primeira linha de defesa de qualquer sistema. Uma implementação falha pode permitir acesso não autorizado a dados sensíveis, comprometimento de contas e escalação de privilégios. Este guia cobre a auditoria completa de mecanismos de autenticação.

> 🔴 **REGRA ABSOLUTA**: NUNCA incluir listas de senhas, wordlists ou credenciais reais neste documento ou durante a auditoria. NUNCA testar credenciais de usuários reais. Utilizar **apenas contas sintéticas** criadas especificamente para os testes.

---

## 2. Políticas de Senha e Armazenamento

### 2.1. Requisitos Mínimos de Política de Senha

Verificar se o sistema implementa:

| Requisito | Mínimo Recomendado | Ideal |
|---|---|---|
| Comprimento mínimo | 8 caracteres | 12+ caracteres |
| Complexidade | Letra + número | Letra maiúsc. + minúsc. + número + especial |
| Verificação contra senhas vazadas | Não implementado | HaveIBeenPwned API ou equivalente |
| Histórico de senhas | Nenhum | Últimas 5-10 senhas |
| Expiração | Não obrigatória (NIST 800-63B) | Apenas se houver suspeita de comprometimento |
| Entropia mínima estimada | — | zxcvbn score ≥ 3 |

**Pontos de verificação:**
- [ ] O sistema aceita senhas fracas (ex: `123456`, `password`)?
- [ ] Existe feedback em tempo real sobre a força da senha?
- [ ] Senhas são verificadas contra listas de senhas vazadas?
- [ ] O sistema impõe comprimento máximo razoável (não inferior a 64 caracteres)?

### 2.2. Armazenamento Seguro de Senhas

Verificar qual algoritmo de hashing é utilizado:

| Algoritmo | Status | Observações |
|---|---|---|
| **Argon2id** | ✅ Recomendado | Resistente a ataques GPU e side-channel |
| **bcrypt** | ✅ Aceitável | Cost factor ≥ 10 |
| **scrypt** | ✅ Aceitável | Resistente a ataques com hardware especializado |
| **PBKDF2** | ⚠️ Aceitável com ressalvas | Mínimo 600.000 iterações (OWASP 2023) com HMAC-SHA256 |
| **SHA-256/SHA-512** | ❌ Inadequado | Sem salt ou iterações |
| **MD5** | ❌ Crítico | Completamente inseguro |
| **SHA-1** | ❌ Crítico | Colisões demonstradas |

**Checklist de armazenamento:**
- [ ] Hashing com salt único por senha?
- [ ] Algoritmo adaptativo (Argon2id, bcrypt, scrypt)?
- [ ] Parâmetros de custo adequados?
- [ ] Pepper (segredo do servidor) implementado?
- [ ] Senhas nunca armazenadas em texto plano ou com encoding reversível (Base64)?

**Como verificar (análise de código):**

```python
# ✅ CORRETO - Argon2id
from argon2 import PasswordHasher
ph = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=4)
hash = ph.hash(password)

# ✅ CORRETO - bcrypt
import bcrypt
hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt(rounds=12))

# ❌ INCORRETO - hash simples
import hashlib
hash = hashlib.sha256(password.encode()).hexdigest()

# ❌ INCORRETO - armazenamento reversível
import base64
stored = base64.b64encode(password.encode())
```

---

## 3. Rate Limiting e Classificação de Defesas contra Força Bruta

### 3.1. Classificação das Defesas em 4 Estados

Durante a avaliação de endpoints de autenticação (login, OTP/2FA, reset de senha, refresh de tokens), os sinais observáveis devem ser classificados em um dos quatro estados:

| Estado da Defesa | Sinais Observáveis | Mecanismo |
|---|---|---|
| **Hard lockout** | Status `403 Forbidden` ou mensagem textual explícita de bloqueio de conta. | Conta ou sessão temporariamente desativada no backend. |
| **Soft IP throttle** | Status `429 Too Many Requests`, header `Retry-After` ou latência crescente. | Limitação de requisições por endereço IP. |
| **CAPTCHA injection** | Resposta passa a conter desafio dinâmico (reCAPTCHA, hCaptcha, Turnstile). | Interrupção de automação através de desafio humano. |
| **Silent shadow-throttle** | Códigos de resposta mantêm-se 200/401, mas requisições deixam de ser processadas. | Confirmado via **Shadow-Throttle Seed Test**. |

### 3.2. Metodologia do Shadow-Throttle Seed Test

Se nenhuma alteração de status for observada após uma sequência de tentativas, trate como **candidato a ausência de rate limiting**, mas realize o teste de semente para desempate:
1. Em uma posição fixa da sequência (ou após $N$ tentativas em OTP), envie uma **credencial/código sabidamente válido**.
2. **Se a credencial válida autenticar normalmente sob carga**: ausência real de rate limiting (vulnerabilidade confirmada).
3. **Se a credencial válida falhar sob carga**: o sistema implementa estrangulamento silencioso (*Silent shadow-throttle*).

### 3.3. Avaliação de Proteção: Baseada em IP vs Baseada em Conta (Account-Based)

Atacantes avançados utilizam redes de bots e proxies residenciais para distribuir requisições por milhares de IPs distintos:
- **Proteção puramente por IP**: Vulnerável a ataques de *Credential Stuffing* e *Password Spraying* distribuídos.
- **Proteção Baseada em Conta (Account-Based)**: Contadores de tentativas falhas vinculados à identidade do usuário/e-mail no banco/Redis, garantindo bloqueio progressivo independente de quantos IPs são utilizados.

### 3.4. Detecção Rigorosa de Enumeração de Usuários e Timing Side-Channels

- **Diferenças Observáveis**:
  - Mensagens de erro divergentes ("Usuário inexistente" vs "Senha inválida").
  - Códigos de status distintos (404 vs 401).
- **Canais Laterais de Tempo (Timing Side-Channels)**:
  - **Exigência Estatística**: Mediana de **pelo menos 30 amostras por usuário** para mitigar oscilações transitórias de rede.
  - Apenas caracterizar timing side-channel se a diferença ($\Delta median$) for consistente e relevante ($\ge 35$ ms).

### 3.5. Limites Operacionais e Salvaguardas Éticas

- **Máximo de 20 a 50 tentativas por janela de teste**.
- **Interrupção imediata** ao primeiro sinal de sobrecarga (status 5xx ou latência $> 3000$ ms) ou bloqueio.
- **Utilizar exclusivamente contas de teste dedicadas**. NUNCA usar senhas de usuários reais ou ferramentas de bypass/evasão.

---

## 4. Autenticação Multifator (MFA)

### 4.1. Revisão de Implementação MFA

| Método MFA | Segurança | Observações |
|---|---|---|
| **WebAuthn/FIDO2** | ✅ Excelente | Resistente a phishing |
| **TOTP (Authenticator App)** | ✅ Bom | Verificar implementação correta |
| **Push notification** | ✅ Bom | Verificar fadiga de MFA (MFA bombing) |
| **SMS** | ⚠️ Fraco | Vulnerável a SIM swapping e interceptação |
| **Email** | ⚠️ Fraco | Depende da segurança do email |

### 4.2. Verificações de TOTP

- [ ] O segredo TOTP tem entropia adequada (≥ 160 bits)?
- [ ] A janela de tempo aceita códigos de no máximo ±1 intervalo (30s)?
- [ ] Códigos TOTP são de uso único (não podem ser reutilizados na mesma janela)?
- [ ] Existe limite de tentativas para códigos TOTP?
- [ ] O segredo TOTP é armazenado de forma segura no servidor?
- [ ] Códigos de backup são gerados e armazenados com segurança?
- [ ] Códigos de backup são de uso único?

### 4.3. Verificações de WebAuthn

- [ ] A origin validation está correta?
- [ ] O RP ID (Relying Party ID) está configurado corretamente?
- [ ] A attestation é verificada quando necessário?
- [ ] Existe mecanismo de recuperação se o dispositivo for perdido?

### 4.4. Bypass de MFA — Pontos de Verificação

Verificar se o MFA pode ser contornado através de:

- [ ] Manipulação de parâmetros na requisição (remover campo MFA)
- [ ] Acesso direto a endpoints pós-MFA sem completar o fluxo
- [ ] Tokens de sessão emitidos antes da verificação do MFA
- [ ] Fluxo de "lembrar dispositivo" com token fraco
- [ ] Fluxo de recuperação de senha que ignora MFA
- [ ] APIs que não exigem MFA mesmo quando habilitado no perfil

---

## 5. Recuperação de Senha

### 5.1. Fluxo Seguro de Recuperação

**Verificações de segurança do token de recuperação:**

| Aspecto | Requisito | Como Verificar |
|---|---|---|
| **Entropia** | ≥ 128 bits (token aleatório criptograficamente seguro) | Analisar código de geração |
| **Expiração** | 15-60 minutos | Testar token após expiração |
| **Uso único** | Token invalidado após uso | Tentar reutilizar token |
| **Vinculação** | Token vinculado à conta específica | Tentar usar token de outra conta |
| **Transmissão** | Via HTTPS apenas | Verificar link no email |
| **Armazenamento** | Hash do token no banco (nunca texto plano) | Analisar código/banco |

### 5.2. Verificações do Fluxo

- [ ] O sistema retorna a mesma mensagem independente de o email existir ou não? (Prevenir enumeração)
- [ ] O token de sessão anterior é invalidado após redefinição de senha?
- [ ] O MFA é exigido ou verificado durante a recuperação?
- [ ] Existe rate limiting no endpoint de recuperação?
- [ ] O email de recuperação contém informações sobre a requisição (IP, horário)?
- [ ] Links de recuperação usam HTTPS?
- [ ] O token não é passado como query parameter em requisições GET logadas?

---

## 6. Gerenciamento de Sessão

### 6.1. Criação de Sessão

- [ ] IDs de sessão são gerados com CSPRNG (mínimo 128 bits de entropia)?
- [ ] IDs de sessão são transmitidos apenas via cookies seguros?
- [ ] Nova sessão é criada no login (prevenção de session fixation)?

### 6.2. Atributos de Cookie de Sessão

```http
Set-Cookie: session_id=<valor>; Secure; HttpOnly; SameSite=Strict; Path=/; Max-Age=3600
```

| Atributo | Obrigatório | Descrição |
|---|---|---|
| `Secure` | ✅ Sim | Cookie transmitido apenas via HTTPS |
| `HttpOnly` | ✅ Sim | Cookie inacessível via JavaScript |
| `SameSite=Strict` ou `Lax` | ✅ Sim | Proteção contra CSRF |
| `Path=/` | ✅ Sim | Limitar escopo do cookie |
| `Max-Age` ou `Expires` | ✅ Sim | Definir tempo de vida |
| `Domain` | Conforme necessidade | Evitar domínio genérico demais |

### 6.3. Rotação de Sessão

Verificar se o ID de sessão é renovado em:
- [ ] Login bem-sucedido
- [ ] Elevação de privilégio
- [ ] Alteração de senha
- [ ] Ativação/desativação de MFA
- [ ] Mudança de role/permissão

### 6.4. Invalidação de Sessão

- [ ] Logout invalida a sessão no servidor (não apenas no cliente)?
- [ ] Todas as sessões são invalidadas ao trocar a senha?
- [ ] Existe timeout de inatividade (idle timeout)?
- [ ] Existe timeout absoluto (mesmo com atividade)?
- [ ] O usuário pode visualizar e invalidar sessões ativas?

### 6.5. Timeouts Recomendados

| Tipo de Aplicação | Idle Timeout | Absolute Timeout |
|---|---|---|
| Financeiro/Saúde | 5-15 min | 4-8 horas |
| Aplicação crítica | 15-30 min | 8-12 horas |
| Aplicação padrão | 30-60 min | 24 horas |
| Baixo risco | 2-4 horas | 72 horas |

---

## 7. Defesas contra Credential Stuffing

### 7.1. Verificações

- [ ] Detecção de padrões de login automatizado (timing, volume)?
- [ ] CAPTCHA ou desafio após tentativas suspeitas?
- [ ] Verificação contra bancos de senhas vazadas (HaveIBeenPwned)?
- [ ] Notificação ao usuário de tentativas de login suspeitas?
- [ ] Detecção de login de localização/dispositivo incomum?
- [ ] Fingerprinting de navegador para detecção de bots?
- [ ] Rate limiting adaptativo baseado em padrões de tráfego?

---

## 8. Enumeração de Usuários

### 8.1. Vetores de Enumeração

Verificar se o sistema vaza informações sobre a existência de contas em:

| Vetor | O que verificar | Exemplo de falha |
|---|---|---|
| **Mensagens de erro** | Mensagens diferentes para usuário válido vs. inválido | "Senha incorreta" vs. "Usuário não encontrado" |
| **Timing** | Diferença de tempo de resposta | Hash computado apenas se o usuário existe |
| **Registro** | Mensagem diferente se email já registrado | "Este email já está cadastrado" |
| **Recuperação de senha** | Confirmação de email existente | "Email de recuperação enviado para X" (apenas se existir) |
| **Códigos HTTP** | Status codes diferentes | 401 vs. 404 |
| **Tamanho da resposta** | Respostas de tamanhos diferentes | Body mais longo para erro de senha |

### 8.2. Resposta Correta (Anti-enumeração)

```json
// ✅ CORRETO - mesma resposta em ambos os casos
{
  "message": "Se o email estiver cadastrado, você receberá instruções de recuperação."
}

// ❌ INCORRETO - revela existência da conta
{
  "error": "Senha incorreta para o usuário joao@example.com"
}
```

### 8.3. Metodologia de Teste

1. Enviar requisição de login com **conta sintética existente** e senha errada
2. Enviar requisição de login com **email inexistente** e senha errada
3. Comparar: mensagem de erro, tempo de resposta, código HTTP, tamanho da resposta
4. Repetir para endpoints de registro e recuperação de senha

---

## 9. Detecção e Monitoramento de Força Bruta

### 9.1. Verificações de Monitoramento

- [ ] Tentativas de login falhas são registradas em logs?
- [ ] Os logs incluem: timestamp, IP, user-agent, conta alvo, resultado?
- [ ] Existe alerta automático para padrões de ataque?
- [ ] Os logs NÃO contêm senhas (nem incorretas)?
- [ ] Existe dashboard de monitoramento de autenticação?

---

## 10. OAuth 2.0 e OpenID Connect (OIDC)

### 10.1. Verificações de Implementação

- [ ] O `state` parameter é usado para prevenir CSRF?
- [ ] O `state` é validado no callback?
- [ ] O `nonce` é usado em fluxos OIDC (prevenir replay)?
- [ ] O `redirect_uri` é validado estritamente (match exato, não prefixo)?
- [ ] O `code_verifier`/`code_challenge` (PKCE) é implementado?
- [ ] Tokens de acesso são validados (audience, issuer, expiration)?
- [ ] ID tokens são validados conforme especificação OIDC?
- [ ] Escopos solicitados são mínimos necessários?
- [ ] O client secret é armazenado de forma segura?
- [ ] Refresh tokens são rotacionados e têm expiração?

### 10.2. Fluxos Seguros

| Fluxo | Uso Recomendado | Observações |
|---|---|---|
| **Authorization Code + PKCE** | ✅ Aplicações web e mobile | Padrão recomendado |
| **Authorization Code** (sem PKCE) | ⚠️ Apenas servidor-a-servidor | PKCE deve ser adicionado |
| **Implicit** | ❌ Descontinuado | Não usar |
| **Resource Owner Password** | ❌ Descontinuado | Não usar |
| **Client Credentials** | ✅ Machine-to-machine | Apenas backend |

---

## 11. Tokens "Lembrar-me" (Remember Me)

### 11.1. Verificações

- [ ] O token tem entropia adequada (≥ 128 bits)?
- [ ] O token está vinculado ao dispositivo/navegador?
- [ ] O token expira após um período razoável (ex: 30 dias)?
- [ ] O token é armazenado como hash no servidor?
- [ ] O token é invalidado ao trocar a senha?
- [ ] Existe limite de tokens "lembrar-me" ativos por conta?
- [ ] A funcionalidade pode ser desabilitada pelo usuário?
- [ ] O token não concede acesso a operações sensíveis (exigir re-autenticação)?

---

## 12. Metodologia de Teste

> 🔴 **REFORÇO**: Todos os testes DEVEM ser realizados com contas sintéticas. NUNCA utilizar listas de senhas ou credenciais reais.

### 12.1. Ordem de Execução dos Testes

1. **Análise de código** — Revisar implementação de autenticação no código-fonte
2. **Análise de configuração** — Verificar configurações de sessão e cookies
3. **Testes passivos** — Observar respostas, headers, comportamento
4. **Testes com conta sintética** — Login, logout, recuperação, MFA
5. **Verificação de rate limiting** — Com limites conservadores
6. **Documentação** — Registrar todas as descobertas

### 12.2. Contas Sintéticas

Utilizar contas de teste com as seguintes características:
- Criadas especificamente para a auditoria
- Dados fictícios (nome, email, telefone)
- Removidas ou desativadas após a auditoria
- Sem acesso a dados reais de produção

---

## 13. Referências

- OWASP Authentication Cheat Sheet: https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html
- OWASP Session Management Cheat Sheet: https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet.html
- NIST SP 800-63B (Digital Identity Guidelines): https://pages.nist.gov/800-63-3/sp800-63b.html
- OWASP Testing Guide — Authentication Testing: https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/04-Authentication_Testing/

---

*Última atualização: Outubro 2026*
*Referências cruzadas: [audit-methodology.md](./audit-methodology.md) | [api-security.md](./api-security.md) | [safe-testing-policy.md](./safe-testing-policy.md)*
