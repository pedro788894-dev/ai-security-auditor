# Segurança de APIs — Guia de Auditoria

> Documento de referência para auditoria de segurança de APIs REST, GraphQL e WebSocket.
> Baseado no OWASP API Security Top 10 (2023).

---

## 1. Visão Geral

APIs são a espinha dorsal de aplicações modernas e representam uma superfície de ataque significativa. Este guia cobre a auditoria de segurança de APIs, incluindo REST, GraphQL e WebSocket, com foco em vulnerabilidades comuns e metodologia de verificação.

---

## 2. OWASP API Security Top 10 (2023)

| # | Vulnerabilidade | Código |
|---|---|---|
| 1 | Broken Object Level Authorization (BOLA) | API1:2023 |
| 2 | Broken Authentication | API2:2023 |
| 3 | Broken Object Property Level Authorization | API3:2023 |
| 4 | Unrestricted Resource Consumption | API4:2023 |
| 5 | Broken Function Level Authorization | API5:2023 |
| 6 | Unrestricted Access to Sensitive Business Flows | API6:2023 |
| 7 | Server Side Request Forgery (SSRF) | API7:2023 |
| 8 | Security Misconfiguration | API8:2023 |
| 9 | Improper Inventory Management | API9:2023 |
| 10 | Unsafe Consumption of APIs | API10:2023 |

---

## 3. Checklist de Segurança REST API

### 3.1. Autenticação e Autorização

- [ ] Todos os endpoints requerem autenticação (exceto os explicitamente públicos)?
- [ ] A autorização é verificada em **cada endpoint** individualmente?
- [ ] A autorização verifica o **recurso específico** sendo acessado (não apenas a rota)?
- [ ] Tokens de autenticação são validados em cada requisição?
- [ ] Endpoints administrativos têm controle de acesso adicional?
- [ ] A autenticação é consistente entre todos os endpoints (incluindo versões antigas)?

### 3.2. Validação de Entrada

- [ ] Todos os parâmetros de entrada são validados (tipo, formato, tamanho)?
- [ ] Content-Type é validado contra o esperado?
- [ ] Parâmetros inesperados são rejeitados ou ignorados?
- [ ] Existe limitação de tamanho para o corpo da requisição?
- [ ] Uploads de arquivo são validados (tipo, tamanho, conteúdo)?
- [ ] Caracteres especiais são tratados adequadamente?

### 3.3. Respostas e Exposição de Dados

- [ ] As respostas contêm apenas os campos necessários?
- [ ] Dados sensíveis são filtrados nas respostas (senhas, tokens, PII)?
- [ ] Mensagens de erro não expõem detalhes internos (stack traces, SQL)?
- [ ] Headers de resposta estão configurados adequadamente?
- [ ] Paginação é implementada para evitar retorno de grandes volumes de dados?

### 3.4. Headers de Segurança

```http
# Headers recomendados para APIs
Content-Type: application/json
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Content-Security-Policy: default-src 'none'
```

**Verificações de headers:**
- [ ] `X-Content-Type-Options: nosniff` presente?
- [ ] `Strict-Transport-Security` configurado?
- [ ] `Cache-Control: no-store` para respostas com dados sensíveis?
- [ ] Headers de servidor (ex: `Server`, `X-Powered-By`) removidos ou ofuscados?
- [ ] CORS configurado corretamente (ver seção 8)?

---

## 4. BOLA/IDOR — Broken Object Level Authorization

### 4.1. Descrição

BOLA (Broken Object Level Authorization), também conhecido como IDOR (Insecure Direct Object Reference), ocorre quando a API não verifica se o usuário autenticado tem permissão para acessar o recurso solicitado.

### 4.2. Metodologia de Detecção

> ⚠️ **IMPORTANTE**: Testar apenas com contas sintéticas criadas para a auditoria.

**Passos:**

1. **Identificar endpoints com referências a objetos**: Endpoints que usam IDs na URL ou corpo da requisição.
   ```
   GET /api/users/{id}/profile
   GET /api/orders/{orderId}
   PUT /api/documents/{docId}
   DELETE /api/comments/{commentId}
   ```

2. **Testar acesso cruzado**: Com a Conta A (sintética), tentar acessar recursos da Conta B (sintética).
   ```
   # Conta A está autenticada, tentando acessar recurso da Conta B
   GET /api/users/CONTA_B_ID/profile
   Authorization: Bearer <token_conta_A>
   ```

3. **Verificar variações de método HTTP**:
   ```
   GET /api/orders/123    → Pode estar protegido
   PUT /api/orders/123    → Pode NÃO estar protegido
   DELETE /api/orders/123 → Pode NÃO estar protegido
   ```

4. **Testar IDs previsíveis**:
   - IDs sequenciais (1, 2, 3...) são mais suscetíveis
   - UUIDs reduzem o risco mas NÃO são um controle de segurança

### 4.3. Padrões de Código Vulnerável vs. Seguro

```python
# ❌ VULNERÁVEL - não verifica ownership
@app.get("/api/orders/{order_id}")
def get_order(order_id: int, user: User = Depends(get_current_user)):
    order = db.query(Order).filter(Order.id == order_id).first()
    return order

# ✅ SEGURO - verifica ownership
@app.get("/api/orders/{order_id}")
def get_order(order_id: int, user: User = Depends(get_current_user)):
    order = db.query(Order).filter(
        Order.id == order_id,
        Order.user_id == user.id  # Verifica ownership
    ).first()
    if not order:
        raise HTTPException(status_code=404)
    return order
```

---

## 5. Vulnerabilidades de Mass Assignment

### 5.1. Descrição

Mass assignment ocorre quando a API aceita e processa parâmetros que o cliente não deveria poder definir (ex: role, isAdmin, balance).

### 5.2. Metodologia de Detecção

1. **Identificar endpoints de criação/atualização** (POST, PUT, PATCH)
2. **Analisar o modelo de dados** para campos sensíveis
3. **Enviar campos extras** na requisição com conta sintética

```json
// Requisição normal de atualização de perfil
PUT /api/users/profile
{
  "name": "Teste Auditoria",
  "email": "teste@audit.example"
}

// Tentativa de mass assignment (com conta sintética)
PUT /api/users/profile
{
  "name": "Teste Auditoria",
  "email": "teste@audit.example",
  "role": "admin",
  "isVerified": true,
  "balance": 99999
}
```

### 5.3. Padrões de Código

```python
# ❌ VULNERÁVEL - aceita todos os campos
@app.put("/api/users/profile")
def update_profile(data: dict, user: User = Depends(get_current_user)):
    for key, value in data.items():
        setattr(user, key, value)
    db.commit()

# ✅ SEGURO - usa DTO/schema com campos permitidos
class UpdateProfileSchema(BaseModel):
    name: str
    email: EmailStr
    # role, isAdmin NÃO estão no schema

@app.put("/api/users/profile")
def update_profile(data: UpdateProfileSchema, user: User = Depends(get_current_user)):
    user.name = data.name
    user.email = data.email
    db.commit()
```

---

## 6. GraphQL — Riscos Específicos

### 6.1. Introspection

- [ ] A introspection está desabilitada em produção?
- [ ] Se habilitada, expõe schemas sensíveis?

```graphql
# Query de introspection
{
  __schema {
    types {
      name
      fields {
        name
        type { name }
      }
    }
  }
}
```

**Verificação**: Enviar a query acima e verificar se retorna o schema completo.

### 6.2. Depth Limiting

- [ ] Existe limite de profundidade de queries?
- [ ] Queries profundas são rejeitadas?

```graphql
# Query com profundidade excessiva (potencial DoS)
{
  user {
    friends {
      friends {
        friends {
          friends {
            name
          }
        }
      }
    }
  }
}
```

**Recomendação**: Limite de profundidade de 5-10 níveis, dependendo do schema.

### 6.3. Query Cost / Complexity Analysis

- [ ] Existe análise de custo/complexidade de queries?
- [ ] Queries complexas são rejeitadas antes da execução?
- [ ] Existe limite de aliases por query?

```graphql
# Batching attack via aliases
{
  a1: user(id: "1") { name email }
  a2: user(id: "2") { name email }
  a3: user(id: "3") { name email }
  # ... centenas de aliases
}
```

### 6.4. Batching

- [ ] Existe limite para operações em lote (batching)?
- [ ] Mutations em lote são restringidas?

### 6.5. Checklist GraphQL Completo

- [ ] Introspection desabilitada em produção
- [ ] Limite de profundidade configurado
- [ ] Análise de complexidade implementada
- [ ] Rate limiting por query/operação
- [ ] Validação de autorização por campo/resolver
- [ ] Proteção contra N+1 queries (DataLoader)
- [ ] Timeout de execução de query
- [ ] Tamanho máximo de query definido

---

## 7. Rate Limiting e Throttling

### 7.1. Verificações

- [ ] Rate limiting implementado em todos os endpoints?
- [ ] Limites diferenciados por tipo de endpoint (leitura vs. escrita)?
- [ ] Headers de rate limit retornados nas respostas?
- [ ] Resposta 429 (Too Many Requests) implementada?
- [ ] Rate limiting não pode ser contornado via headers (X-Forwarded-For)?

### 7.2. Headers de Rate Limiting

```http
HTTP/1.1 200 OK
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1697840400
```

### 7.3. Limites Recomendados

| Tipo de Endpoint | Limite Sugerido |
|---|---|
| Leitura (GET) | 100-1000 req/min |
| Escrita (POST/PUT) | 20-100 req/min |
| Autenticação | 5-10 req/15min |
| Upload | 5-10 req/hora |
| API pública | 30-60 req/min |

---

## 8. Configuração CORS

### 8.1. Verificações

```http
# Requisição preflight
OPTIONS /api/data
Origin: https://malicious-site.example
Access-Control-Request-Method: GET
```

**Pontos de verificação:**
- [ ] `Access-Control-Allow-Origin` NÃO é `*` para APIs autenticadas?
- [ ] A origin é validada contra uma lista de origens permitidas?
- [ ] `Access-Control-Allow-Credentials: true` não é combinado com `Allow-Origin: *`?
- [ ] `Access-Control-Allow-Methods` lista apenas os métodos necessários?
- [ ] `Access-Control-Allow-Headers` é restritivo?
- [ ] `Access-Control-Max-Age` está configurado (reduzir preflight requests)?

### 8.2. Configurações Vulneráveis

```python
# ❌ VULNERÁVEL - reflete qualquer origin
@app.middleware("http")
async def cors(request, call_next):
    response = await call_next(request)
    origin = request.headers.get("origin")
    response.headers["Access-Control-Allow-Origin"] = origin  # Reflete a origin
    response.headers["Access-Control-Allow-Credentials"] = "true"
    return response

# ❌ VULNERÁVEL - wildcard com credentials
CORS(app, origins=["*"], allow_credentials=True)

# ✅ SEGURO - lista de origens permitidas
CORS(app, origins=["https://app.example.com", "https://admin.example.com"])
```

---

## 9. JWT (JSON Web Tokens)

### 9.1. Verificações de Validação

- [ ] O algoritmo é verificado e restrito (ex: apenas RS256 ou ES256)?
- [ ] O token `alg: none` é rejeitado?
- [ ] A confusão de algoritmo (RSA vs HMAC) é prevenida?
- [ ] O `exp` (expiration) é validado?
- [ ] O `iat` (issued at) é validado?
- [ ] O `aud` (audience) é validado?
- [ ] O `iss` (issuer) é validado?
- [ ] O `nbf` (not before) é validado?
- [ ] O `jti` (JWT ID) é usado para prevenção de replay?
- [ ] JWTs expirados são rejeitados corretamente?

### 9.2. Vulnerabilidades Comuns

```python
# ❌ VULNERÁVEL - não verifica algoritmo
jwt.decode(token, key, algorithms=["HS256", "RS256", "none"])

# ❌ VULNERÁVEL - aceita qualquer algoritmo
jwt.decode(token, key, options={"verify_signature": False})

# ✅ SEGURO - algoritmo fixo
jwt.decode(token, public_key, algorithms=["RS256"], audience="my-api", issuer="auth.example.com")
```

### 9.3. Tempos de Expiração Recomendados

| Tipo de Token | Expiração |
|---|---|
| Access token | 5-15 minutos |
| Refresh token | 7-30 dias |
| ID token (OIDC) | 5-60 minutos |

---

## 10. Gerenciamento de API Keys

### 10.1. Verificações

- [ ] API keys são transmitidas apenas via headers (não via query string)?
- [ ] API keys são armazenadas com hash no servidor?
- [ ] Existe mecanismo de rotação de API keys?
- [ ] API keys expiram após um período definido?
- [ ] API keys têm escopo de permissões limitado?
- [ ] API keys podem ser revogadas individualmente?
- [ ] Existe monitoramento de uso anômalo de API keys?
- [ ] API keys não são expostas em logs, URLs ou código-fonte?

---

## 11. Tratamento de Erros e Divulgação de Informações

### 11.1. Verificações

```json
// ❌ INCORRETO - expõe detalhes internos
{
  "error": "PG::UndefinedTable: ERROR: relation \"users\" does not exist\n  at /app/models/user.rb:45",
  "stack": "Error at DatabaseConnection.query (db.js:123)..."
}

// ✅ CORRETO - erro genérico com ID de rastreamento
{
  "error": "Erro interno do servidor",
  "requestId": "req_a1b2c3d4",
  "status": 500
}
```

**Pontos de verificação:**
- [ ] Stack traces são suprimidos em produção?
- [ ] Erros de banco de dados são abstrados?
- [ ] Informações de versão e tecnologia não são expostas?
- [ ] Caminhos internos do sistema não são revelados?
- [ ] Cada erro tem um ID de rastreamento para debugging interno?
- [ ] Erros 500 são genéricos e não informativos para o atacante?

---

## 12. Segurança de WebSocket

### 12.1. Verificações

- [ ] A conexão WebSocket requer autenticação?
- [ ] A autenticação é verificada no handshake inicial?
- [ ] A autorização é verificada para cada mensagem/canal?
- [ ] Existe validação de origem (Origin header)?
- [ ] Mensagens são validadas (tipo, tamanho, formato)?
- [ ] Existe rate limiting para mensagens?
- [ ] Existe timeout para conexões inativas?
- [ ] A conexão usa WSS (WebSocket Secure)?
- [ ] Existe proteção contra injeção via mensagens WebSocket?
- [ ] Reconexão automática não ignora autenticação?

---

## 13. Versionamento de API e Segurança

### 13.1. Verificações

- [ ] APIs em versões antigas ainda estão acessíveis?
- [ ] Versões depreciadas mantêm os mesmos controles de segurança?
- [ ] Existe prazo definido para desligamento de versões antigas?
- [ ] Vulnerabilidades corrigidas em versões novas foram corrigidas nas antigas?
- [ ] A documentação de API indica versões depreciadas?
- [ ] Endpoints não documentados (shadow APIs) foram identificados?

### 13.2. Shadow APIs

Verificar endpoints que podem existir mas não estão documentados:
- Endpoints de versões anteriores (`/v1/`, `/v2/`)
- Endpoints de debug (`/debug/`, `/test/`, `/_internal/`)
- Endpoints de saúde/status (`/health`, `/status`, `/metrics`)
- Endpoints de administração (`/admin/`, `/manage/`)

---

## 14. SSRF (Server-Side Request Forgery)

### 14.1. Verificações em APIs

- [ ] Endpoints que aceitam URLs como parâmetro validam o destino?
- [ ] Existe blocklist para endereços internos (127.0.0.1, 10.x, 172.16.x, 169.254.x)?
- [ ] Redirecionamentos são seguidos de forma segura (ou bloqueados)?
- [ ] Schemas de URL são restritos (apenas HTTP/HTTPS)?
- [ ] Existe resolução de DNS para prevenir TOCTOU (time-of-check-time-of-use)?

---

## 15. Referências

- OWASP API Security Top 10 (2023): https://owasp.org/API-Security/
- OWASP REST Security Cheat Sheet: https://cheatsheetseries.owasp.org/cheatsheets/REST_Security_Cheat_Sheet.html
- OWASP GraphQL Cheat Sheet: https://cheatsheetseries.owasp.org/cheatsheets/GraphQL_Cheat_Sheet.html
- OWASP JWT Security Cheat Sheet: https://cheatsheetseries.owasp.org/cheatsheets/JSON_Web_Token_for_Java_Cheat_Sheet.html

---

*Última atualização: Outubro 2026*
*Referências cruzadas: [authentication-security.md](./authentication-security.md) | [code-security.md](./code-security.md) | [safe-testing-policy.md](./safe-testing-policy.md)*
