# Segurança de Código — Guia de Auditoria

> Documento de referência para revisão de segurança de código-fonte.
> Cobre análise estática, padrões de vulnerabilidade, dependências e revisão de histórico Git.

---

## 1. Visão Geral

A revisão de segurança de código-fonte é uma das atividades mais eficazes para identificar vulnerabilidades antes que sejam exploradas. Este guia cobre metodologia de análise estática, padrões de código vulnerável, ferramentas de detecção e práticas de codificação segura.

> 🔴 **REGRA ABSOLUTA**: NUNCA executar código malicioso encontrado durante a revisão. NUNCA executar payloads, exploits ou malware identificados no código-fonte. Documentar a existência e reportar sem executar.

---

## 2. Metodologia de Análise Estática

### 2.1. Abordagem Sistemática

```mermaid
flowchart TD
    A["1. Inventário de Código"] --> B["2. Análise Automatizada"]
    B --> C["3. Revisão Manual Dirigida"]
    C --> D["4. Análise de Dependências"]
    D --> E["5. Revisão de Histórico Git"]
    E --> F["6. Documentação de Descobertas"]
```

### 2.2. Fase 1 — Inventário de Código

Antes de iniciar a análise, documentar:

- [ ] Linguagens de programação utilizadas
- [ ] Frameworks e bibliotecas principais
- [ ] Estrutura de diretórios
- [ ] Pontos de entrada (endpoints, handlers, controllers)
- [ ] Fluxos de dados (entrada → processamento → saída → armazenamento)
- [ ] Mecanismos de autenticação e autorização
- [ ] Integrações externas (APIs, bancos de dados, serviços)

### 2.3. Fase 2 — Análise Automatizada

Executar ferramentas de SAST (Static Application Security Testing):

| Ferramenta | Linguagens | Uso |
|---|---|---|
| **Semgrep** | Multi-linguagem | Análise de padrões, regras customizáveis |
| **Bandit** | Python | Análise de segurança Python |
| **ESLint (security plugin)** | JavaScript/TypeScript | Regras de segurança JS/TS |
| **gosec** | Go | Análise de segurança Go |
| **SpotBugs + Find Security Bugs** | Java | Análise de segurança Java |
| **Brakeman** | Ruby on Rails | Análise de segurança Rails |
| **SonarQube** | Multi-linguagem | Plataforma completa de qualidade e segurança |

### 2.4. Fase 3 — Revisão Manual Dirigida

Focar a revisão manual nos seguintes pontos:

1. **Pontos de entrada de dados** (inputs do usuário)
2. **Processamento de dados sensíveis** (autenticação, pagamentos)
3. **Queries de banco de dados** (injeção SQL)
4. **Renderização de saída** (XSS)
5. **Execução de comandos** (command injection)
6. **Manipulação de arquivos** (path traversal)
7. **Controles de acesso** (autorização)
8. **Gerenciamento de sessão** (tokens, cookies)
9. **Criptografia** (algoritmos, chaves)
10. **Tratamento de erros** (exposição de informações)

---

## 3. OWASP Top 10 — Padrões de Vulnerabilidade

### 3.1. A01 — Broken Access Control

```python
# ❌ VULNERÁVEL - sem verificação de ownership
@app.route("/api/documents/<doc_id>")
def get_document(doc_id):
    doc = Document.query.get(doc_id)
    return jsonify(doc.to_dict())

# ✅ SEGURO - verifica ownership
@app.route("/api/documents/<doc_id>")
@login_required
def get_document(doc_id):
    doc = Document.query.filter_by(id=doc_id, owner_id=current_user.id).first()
    if not doc:
        abort(404)
    return jsonify(doc.to_dict())
```

**Checklist:**
- [ ] Cada endpoint verifica autorização do usuário?
- [ ] CORS configurado adequadamente?
- [ ] Métodos HTTP restritos por rota?
- [ ] Acesso a recursos verifica ownership?
- [ ] Funções administrativas protegidas?
- [ ] Directory listing desabilitado?

### 3.2. A02 — Cryptographic Failures

```python
# ❌ VULNERÁVEL - hash fraco
import hashlib
password_hash = hashlib.md5(password.encode()).hexdigest()

# ❌ VULNERÁVEL - criptografia fraca
from Crypto.Cipher import DES  # DES é inseguro

# ❌ VULNERÁVEL - chave hardcoded
SECRET_KEY = "minha-chave-super-secreta-123"

# ✅ SEGURO - hash adequado
from argon2 import PasswordHasher
ph = PasswordHasher()
password_hash = ph.hash(password)

# ✅ SEGURO - criptografia forte
from cryptography.fernet import Fernet
key = Fernet.generate_key()  # Armazenar de forma segura
```

**Checklist:**
- [ ] Dados sensíveis são criptografados em trânsito (TLS)?
- [ ] Dados sensíveis são criptografados em repouso?
- [ ] Algoritmos criptográficos modernos e seguros?
- [ ] Chaves criptográficas não estão hardcoded?
- [ ] Geração de números aleatórios usa CSPRNG?
- [ ] Hashing de senhas usa algoritmo adaptativo?

### 3.3. A03 — Injection

#### SQL Injection

```python
# ❌ VULNERÁVEL
query = f"SELECT * FROM users WHERE name = '{user_input}'"

# ✅ SEGURO
query = "SELECT * FROM users WHERE name = %s"
cursor.execute(query, (user_input,))
```

#### Command Injection

```python
# ❌ VULNERÁVEL
import os
os.system(f"ping {user_input}")

# ❌ VULNERÁVEL
import subprocess
subprocess.call(f"ls {user_input}", shell=True)

# ✅ SEGURO
import subprocess
subprocess.call(["ping", "-c", "4", validated_host], shell=False)
```

#### XSS (Cross-Site Scripting)

```javascript
// ❌ VULNERÁVEL - innerHTML com dados do usuário
element.innerHTML = userInput;

// ❌ VULNERÁVEL - document.write
document.write(userInput);

// ✅ SEGURO - textContent
element.textContent = userInput;

// ✅ SEGURO - framework com escape automático (React)
return <div>{userInput}</div>;  // React escapa automaticamente

// ❌ VULNERÁVEL - bypass do escape do React
return <div dangerouslySetInnerHTML={{__html: userInput}} />;
```

```python
# ❌ VULNERÁVEL - Jinja2 sem escape
return render_template_string(f"<p>{user_input}</p>")

# ✅ SEGURO - Jinja2 com autoescaping
return render_template("template.html", name=user_input)
# template.html: <p>{{ name }}</p>  (escape automático)
```

#### LDAP Injection

```python
# ❌ VULNERÁVEL
search_filter = f"(uid={user_input})"

# ✅ SEGURO - escape de caracteres especiais LDAP
from ldap3.utils.conv import escape_filter_chars
search_filter = f"(uid={escape_filter_chars(user_input)})"
```

#### Path Traversal

```python
# ❌ VULNERÁVEL
file_path = os.path.join("/uploads", user_filename)
with open(file_path) as f:
    return f.read()

# ✅ SEGURO - validação do caminho
import os
base_dir = os.path.realpath("/uploads")
file_path = os.path.realpath(os.path.join(base_dir, user_filename))
if not file_path.startswith(base_dir):
    abort(403)
with open(file_path) as f:
    return f.read()
```

### 3.4. A04 — Insecure Design

**Checklist:**
- [ ] Existe modelagem de ameaças para fluxos críticos?
- [ ] Rate limiting implementado em operações sensíveis?
- [ ] Limites de negócio implementados (ex: valor máximo de transferência)?
- [ ] Fluxos de multi-step não permitem pular etapas?
- [ ] Captcha/desafio para operações sensíveis?

### 3.5. A05 — Security Misconfiguration

**Checklist:**
- [ ] Debug mode desabilitado em produção?
- [ ] Stack traces não são expostas ao usuário?
- [ ] Credenciais padrão foram alteradas?
- [ ] Headers de segurança configurados?
- [ ] Funcionalidades não utilizadas desabilitadas?
- [ ] Listagem de diretório desabilitada?
- [ ] Cors configurado restritivamente?

### 3.6. A06 — Vulnerable and Outdated Components

Ver seção 5 (Análise de Dependências).

### 3.7. A07 — Identification and Authentication Failures

Ver [authentication-security.md](./authentication-security.md).

### 3.8. A08 — Software and Data Integrity Failures

```python
# ❌ VULNERÁVEL - desserialização insegura (pickle)
import pickle
data = pickle.loads(user_input)  # RCE possível

# ❌ VULNERÁVEL - YAML inseguro
import yaml
data = yaml.load(user_input)  # Deve usar yaml.safe_load

# ✅ SEGURO - desserialização segura
import json
data = json.loads(user_input)  # JSON é seguro para desserializar

# ✅ SEGURO - YAML seguro
import yaml
data = yaml.safe_load(user_input)
```

**Checklist:**
- [ ] Desserialização usa formatos seguros (JSON)?
- [ ] `pickle`, `marshal` não são usados com dados do usuário?
- [ ] `yaml.safe_load` é usado em vez de `yaml.load`?
- [ ] Integridade de atualizações/plugins é verificada (assinaturas)?
- [ ] CI/CD pipeline é protegido contra adulteração?

### 3.9. A09 — Security Logging and Monitoring Failures

**Checklist:**
- [ ] Eventos de autenticação são logados?
- [ ] Falhas de controle de acesso são logadas?
- [ ] Tentativas de injeção são logadas?
- [ ] Logs não contêm dados sensíveis (senhas, tokens, PII)?
- [ ] Logs são centralizados e protegidos contra adulteração?
- [ ] Alertas estão configurados para eventos suspeitos?

### 3.10. A10 — Server-Side Request Forgery (SSRF)

```python
# ❌ VULNERÁVEL - SSRF
import requests
url = request.args.get("url")
response = requests.get(url)
return response.content

# ✅ SEGURO - validação de URL
from urllib.parse import urlparse
import ipaddress

def is_safe_url(url):
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        return False
    try:
        ip = ipaddress.ip_address(parsed.hostname)
        if ip.is_private or ip.is_loopback or ip.is_reserved:
            return False
    except ValueError:
        pass  # hostname, não IP - validar DNS
    return True
```

---

## 4. Insecure Deserialization — Detalhamento

### 4.1. Linguagens e Riscos

| Linguagem | Mecanismo Perigoso | Risco |
|---|---|---|
| Python | `pickle.loads()`, `yaml.load()` | RCE |
| Java | `ObjectInputStream.readObject()` | RCE |
| PHP | `unserialize()` | RCE |
| Ruby | `Marshal.load()`, `YAML.load()` | RCE |
| .NET | `BinaryFormatter.Deserialize()` | RCE |
| JavaScript | `node-serialize`, `funcster` | RCE |

### 4.2. Regra Geral

> ⚠️ **NUNCA** desserializar dados não confiáveis usando mecanismos nativos de serialização de objetos. Usar formatos de dados simples como JSON.

---

## 5. Análise de Dependências

### 5.1. Ferramentas de Scanning

```bash
# Python
pip-audit
safety check

# JavaScript/TypeScript
npm audit
yarn audit
npx snyk test

# Go
govulncheck ./...

# Java
mvn org.owasp:dependency-check-maven:check

# Multi-linguagem
snyk test
trivy fs .
```

### 5.2. Verificações

- [ ] `package-lock.json` / `yarn.lock` / `poetry.lock` está commitado?
- [ ] Dependências com CVEs conhecidas identificadas?
- [ ] Dependências abandonadas (sem atualização em >2 anos) identificadas?
- [ ] Dependências com licenças incompatíveis identificadas?
- [ ] Dependências desnecessárias ou duplicadas removidas?
- [ ] Versões fixas (não ranges) em produção?
- [ ] Dependências de desenvolvimento não estão em produção?

### 5.3. Classificação de Risco de Dependência

| Fator | Baixo Risco | Alto Risco |
|---|---|---|
| Popularidade | >10k downloads/semana | <100 downloads/semana |
| Manutenção | Commits recentes, muitos mantenedores | Sem atualização >1 ano, 1 mantenedor |
| Vulnerabilidades | Nenhuma CVE ou patches rápidos | CVEs não corrigidas |
| Escopo | Runtime restrito | Acesso a rede, filesystem, system |

---

## 6. Detecção de Segredos Hardcoded

### 6.1. Padrões Comuns

```python
# ❌ Segredos hardcoded que devem ser detectados
API_KEY = "sk_live_4eC39HqLyjWDarjtT1zdp7dc"
DATABASE_URL = "postgresql://user:password123@host:5432/db"
AWS_SECRET_ACCESS_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
GITHUB_TOKEN = "ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
STRIPE_SECRET = "sk_live_xxxxxxxxxxxxxxxxxxxx"
JWT_SECRET = "my-super-secret-jwt-key-do-not-share"
PRIVATE_KEY = "-----BEGIN RSA PRIVATE KEY-----\nMIIEpAIBAAK..."
```

### 6.2. Ferramentas de Detecção

```bash
# Gitleaks - scanner de segredos em repositórios Git
gitleaks detect --source . --verbose

# TruffleHog - busca segredos em repositórios
trufflehog filesystem .

# detect-secrets (Yelp) - detecta segredos no código
detect-secrets scan .
```

### 6.3. Regex para Detecção Manual

```python
# Padrões de regex para segredos comuns
patterns = {
    "AWS Access Key": r"AKIA[0-9A-Z]{16}",
    "AWS Secret Key": r"(?i)aws(.{0,20})?['\"][0-9a-zA-Z/+]{40}['\"]",
    "GitHub Token": r"ghp_[0-9a-zA-Z]{36}",
    "GitHub OAuth": r"gho_[0-9a-zA-Z]{36}",
    "Slack Token": r"xox[baprs]-[0-9a-zA-Z]{10,48}",
    "Stripe Key": r"sk_live_[0-9a-zA-Z]{24,}",
    "Generic Secret": r"(?i)(password|secret|key|token|api_key)\s*=\s*['\"][^\s'\"]{8,}['\"]",
    "Private Key": r"-----BEGIN (RSA |EC |DSA )?PRIVATE KEY-----",
    "JWT": r"eyJ[A-Za-z0-9-_]+\.eyJ[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+",
    "Connection String": r"(?i)(mongodb|postgres|mysql|redis):\/\/[^\s]+@[^\s]+",
}
```

---

## 7. Padrões de Segurança por Linguagem

### 7.1. Python

| Risco | Padrão Vulnerável | Padrão Seguro |
|---|---|---|
| SQL Injection | `f"SELECT ... WHERE x = '{input}'"` | `cursor.execute("... WHERE x = %s", (input,))` |
| Command Injection | `os.system(f"cmd {input}")` | `subprocess.run(["cmd", input], shell=False)` |
| Path Traversal | `open(os.path.join(base, input))` | Validar `os.path.realpath()` |
| Desserialização | `pickle.loads(data)` | `json.loads(data)` |
| YAML | `yaml.load(data)` | `yaml.safe_load(data)` |
| Templating | `render_template_string(input)` | `render_template("file.html", var=input)` |
| Crypto | `hashlib.md5(...)` | `argon2.PasswordHasher()` |
| Random | `random.random()` | `secrets.token_urlsafe()` |
| XML | `xml.etree.ElementTree.parse(input)` | `defusedxml.parse(input)` |

### 7.2. JavaScript / TypeScript

| Risco | Padrão Vulnerável | Padrão Seguro |
|---|---|---|
| XSS | `element.innerHTML = input` | `element.textContent = input` |
| XSS (React) | `dangerouslySetInnerHTML` | `{variable}` (escape automático) |
| SQL Injection | Template literal em query | Parameterized queries |
| Prototype Pollution | `Object.assign({}, input)` | Validar/sanitizar input, usar `Map` |
| ReDoS | Regex com backtracking catastrófico | Testar regex com ferramentas |
| Path Traversal | `path.join(base, input)` | `path.resolve()` + validação |
| eval | `eval(input)` | ❌ Nunca usar com input do usuário |
| Dependências | `require(input)` | Lista fixa de módulos permitidos |

### 7.3. Java

| Risco | Padrão Vulnerável | Padrão Seguro |
|---|---|---|
| SQL Injection | `Statement.execute(input)` | `PreparedStatement` com bind |
| Desserialização | `ObjectInputStream.readObject()` | JSON (Jackson, Gson) com DTOs |
| XXE | `DocumentBuilder.parse(input)` | Desabilitar DTDs e external entities |
| SSRF | `new URL(input).openConnection()` | Validar URL contra allowlist |
| Log Injection | `logger.info(input)` | Sanitizar antes de logar |
| Path Traversal | `new File(base + input)` | `Path.resolve()` + validação |

### 7.4. Go

| Risco | Padrão Vulnerável | Padrão Seguro |
|---|---|---|
| SQL Injection | `fmt.Sprintf("... %s", input)` | `db.Query("... $1", input)` |
| Command Injection | `exec.Command("sh", "-c", input)` | `exec.Command(cmd, args...)` sem shell |
| Template Injection | `text/template` com input | `html/template` com escape automático |
| TOCTOU | `os.Stat()` → `os.Open()` | `os.Open()` direto com tratamento de erro |
| Integer Overflow | Aritmética sem verificação | Verificar limites antes de operações |

---

## 8. Checklist de Revisão de Código

### 8.1. Checklist Geral

```markdown
## Autenticação e Sessão
- [ ] Senhas hasheadas com algoritmo adequado?
- [ ] Sessões gerenciadas de forma segura?
- [ ] Tokens com entropia adequada?
- [ ] Timeout de sessão configurado?

## Autorização
- [ ] Verificação de autorização em cada endpoint?
- [ ] Ownership verificado para cada recurso?
- [ ] Roles e permissões implementados corretamente?
- [ ] Escalação de privilégio prevenida?

## Validação de Entrada
- [ ] Toda entrada do usuário é validada?
- [ ] Validação de tipo, formato e tamanho?
- [ ] Caracteres especiais são tratados?
- [ ] Uploads de arquivo são validados?

## Saída e Encoding
- [ ] Output encoding contra XSS?
- [ ] Content-Type correto nas respostas?
- [ ] CSP (Content Security Policy) configurado?

## Criptografia
- [ ] Algoritmos modernos e seguros?
- [ ] Chaves com tamanho adequado?
- [ ] CSPRNG para geração de números aleatórios?
- [ ] Nenhuma chave hardcoded?

## Tratamento de Erros
- [ ] Erros não expõem informações internas?
- [ ] Exceções são tratadas adequadamente?
- [ ] Fallback seguro em caso de erro?

## Logging
- [ ] Eventos relevantes são logados?
- [ ] Dados sensíveis não são logados?
- [ ] Logs são protegidos contra injeção?
```

---

## 9. Semgrep — Uso e Regras Customizadas

### 9.1. Regras Básicas

```bash
# Executar com regras OWASP
semgrep --config "p/owasp-top-ten" .

# Executar com regras de segurança gerais
semgrep --config "p/security-audit" .

# Executar com múltiplas regras
semgrep --config "p/python" --config "p/javascript" .
```

### 9.2. Regra Customizada — Exemplo

```yaml
rules:
  - id: insecure-pickle-load
    patterns:
      - pattern: pickle.loads(...)
    message: |
      Uso de pickle.loads() com dados potencialmente não confiáveis.
      Pickle pode executar código arbitrário durante desserialização.
      Use json.loads() para dados do usuário.
    severity: ERROR
    languages: [python]
    metadata:
      cwe: CWE-502
      owasp: A08:2021

  - id: sql-injection-fstring
    patterns:
      - pattern: |
          $CURSOR.execute(f"...{$VAR}...")
    message: |
      Possível SQL injection via f-string.
      Use consultas parametrizadas.
    severity: ERROR
    languages: [python]
    metadata:
      cwe: CWE-89
      owasp: A03:2021

  - id: hardcoded-secret
    patterns:
      - pattern-regex: (?i)(password|secret|api_key|token)\s*=\s*["'][^"']{8,}["']
    message: |
      Possível segredo hardcoded encontrado.
      Use variáveis de ambiente ou um secrets manager.
    severity: WARNING
    languages: [generic]
    metadata:
      cwe: CWE-798
```

---

## 10. Revisão de Histórico Git

### 10.1. Busca de Segredos em Commits

```bash
# Usando gitleaks
gitleaks detect --source . --verbose --log-opts="--all"

# Usando trufflehog
trufflehog git file://. --since-commit HEAD~100

# Busca manual por padrões
git log --all -p -S "password" --diff-filter=A
git log --all -p -S "SECRET_KEY" --diff-filter=A
git log --all -p -S "BEGIN RSA PRIVATE KEY" --diff-filter=A
```

### 10.2. Verificações de Histórico

- [ ] Segredos foram commitados e depois removidos (ainda no histórico)?
- [ ] Arquivos sensíveis (`.env`, chaves privadas) foram commitados?
- [ ] `.gitignore` exclui adequadamente arquivos sensíveis?
- [ ] Existe pre-commit hook para prevenir commit de segredos?
- [ ] Autores desconhecidos ou suspeitos nos commits?
- [ ] Commits que alteram configurações de segurança sem justificativa?

### 10.3. .gitignore Recomendado para Segurança

```gitignore
# Variáveis de ambiente
.env
.env.*
!.env.example

# Chaves e certificados
*.pem
*.key
*.p12
*.pfx

# Credenciais
credentials.json
service-account.json
*-keyfile.json

# IDE e OS
.idea/
.vscode/settings.json
.DS_Store
Thumbs.db
```

---

## 11. Referências

- OWASP Top 10 (2021): https://owasp.org/Top10/
- OWASP Code Review Guide: https://owasp.org/www-project-code-review-guide/
- Semgrep Registry: https://semgrep.dev/explore
- CWE Top 25 (2023): https://cwe.mitre.org/top25/archive/2023/2023_top25_list.html
- OWASP Cheat Sheet Series: https://cheatsheetseries.owasp.org/
- Gitleaks: https://github.com/gitleaks/gitleaks
- TruffleHog: https://github.com/trufflesecurity/trufflehog

---

*Última atualização: Outubro 2026*
*Referências cruzadas: [audit-methodology.md](./audit-methodology.md) | [api-security.md](./api-security.md) | [database-security.md](./database-security.md) | [safe-testing-policy.md](./safe-testing-policy.md)*
