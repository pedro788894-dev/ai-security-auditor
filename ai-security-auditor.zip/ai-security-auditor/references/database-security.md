# Segurança de Banco de Dados — Guia de Auditoria

> Documento de referência para auditoria de segurança de bancos de dados.
> Padrão inegociável: **Operação 100% somente leitura**. NUNCA execute comandos `INSERT`, `UPDATE`, `DELETE`, `DROP` ou qualquer alteração estrutural.
> Testes dinâmicos de injeção em banco de produção são expressamente proibidos.

---

## 1. Visão Geral e Princípios Fundamentais

Bancos de dados são o repositório central de informações sensíveis de uma aplicação. Uma configuração inadequada pode levar a vazamento de dados, acesso não autorizado e comprometimento completo do sistema.

> 🔴 **REGRA ABSOLUTA**: NUNCA acessar, copiar, exibir ou exfiltrar dados reais de clientes. NUNCA imprimir segredos, chaves ou tokens encontrados no banco de dados. Trabalhar exclusivamente com metadados, schemas, configurações e análise estática de código.

### 1.1. Detecção Estática de Injeção de SQL e NoSQL
Na ausência de ambiente de testes autorizado ou para garantir integridade total do banco:
- Inspecione arquivos de código em busca de concatenação de strings (`"SELECT ... " + id`), f-strings Python e `.format()` em chamadas a cursores/queries.
- Verifique cláusulas dinâmicas `ORDER BY` ou `LIKE` montadas sem lista branca (whitelist).
- Inspecione raw queries de ORMs (`sequelize.query`, `knex.raw`, `django.db.models.expressions.RawSQL`) com template literals não parametrizados.
- Verifique padrões de injeção NoSQL no MongoDB/Mongoose (passagem de objetos `req.body` sem sanitização permitindo injeção de operadores `$gt`, `$ne`, `$where`).

---

## 2. PostgreSQL — Revisão de Configuração de Segurança

### 2.1. Arquivo `postgresql.conf`

| Parâmetro | Valor Recomendado | Descrição |
|---|---|---|
| `listen_addresses` | `'localhost'` ou IPs específicos | ❌ NUNCA usar `'*'` em produção |
| `port` | 5432 (padrão) ou personalizado | Porta customizada pode reduzir scan automático |
| `ssl` | `on` | Habilitar SSL para conexões |
| `ssl_cert_file` | Caminho do certificado | Certificado válido |
| `ssl_key_file` | Caminho da chave | Chave privada protegida |
| `ssl_min_protocol_version` | `'TLSv1.2'` | Mínimo TLS 1.2 |
| `password_encryption` | `'scram-sha-256'` | ❌ NUNCA usar `'md5'` |
| `log_connections` | `on` | Registrar conexões |
| `log_disconnections` | `on` | Registrar desconexões |
| `log_statement` | `'ddl'` ou `'all'` | Registrar comandos DDL no mínimo |
| `log_line_prefix` | `'%m [%p] %q%u@%d '` | Incluir timestamp, PID, user, database |

### 2.2. Arquivo `pg_hba.conf`

O arquivo `pg_hba.conf` controla a autenticação de clientes. Verificar:

```
# ❌ INSEGURO - permite qualquer conexão sem senha
host    all    all    0.0.0.0/0    trust

# ❌ INSEGURO - MD5 é vulnerável a ataques
host    all    all    0.0.0.0/0    md5

# ✅ SEGURO - SCRAM-SHA-256 com SSL para IPs específicos
hostssl all    app_user    10.0.1.0/24    scram-sha-256
hostssl all    admin       10.0.0.5/32    scram-sha-256

# ✅ SEGURO - rejeitar conexões não autorizadas
host    all    all    0.0.0.0/0    reject
```

**Checklist `pg_hba.conf`:**
- [ ] Nenhuma regra usa método `trust` (exceto para socket local em alguns casos)?
- [ ] Método `scram-sha-256` é usado em vez de `md5`?
- [ ] Conexões limitadas a IPs específicos (não `0.0.0.0/0`)?
- [ ] SSL obrigatório para conexões remotas (`hostssl`)?
- [ ] Regra padrão `reject` no final do arquivo?
- [ ] Superuser não acessível remotamente?

### 2.3. Verificação via SQL

```sql
-- Verificar versão do PostgreSQL
SELECT version();

-- Verificar parâmetros de segurança
SHOW ssl;
SHOW password_encryption;
SHOW listen_addresses;
SHOW log_connections;
SHOW log_statement;

-- Verificar configuração de SSL
SELECT name, setting FROM pg_settings
WHERE name LIKE 'ssl%';

-- Listar roles e permissões
SELECT rolname, rolsuper, rolcreaterole, rolcreatedb, rolcanlogin
FROM pg_roles
ORDER BY rolsuper DESC, rolcreaterole DESC;

-- Verificar extensões instaladas
SELECT * FROM pg_extension;

-- Verificar conexões ativas (sem expor dados sensíveis)
SELECT datname, usename, client_addr, state, query_start
FROM pg_stat_activity
WHERE state = 'active';
```

---

## 3. Supabase — Segurança Específica

### 3.1. Arquitetura de Segurança Supabase

O Supabase usa PostgreSQL como backend com camadas adicionais:

```
Cliente → PostgREST API → PostgreSQL (com RLS)
   ↓
Supabase Auth (GoTrue)
   ↓
Supabase Realtime (WebSocket)
   ↓
Supabase Storage (S3-compatible)
```

### 3.2. Chaves de Acesso

| Chave | Uso | Risco se Exposta |
|---|---|---|
| **anon key** | Requisições públicas (client-side) | ⚠️ Acesso a dados públicos e operações anônimas |
| **service_role key** | Operações do servidor (bypass RLS) | 🔴 CRÍTICO — Acesso total ao banco |
| **JWT secret** | Assinatura de tokens | 🔴 CRÍTICO — Permite forjar tokens |
| **Database password** | Conexão direta ao PostgreSQL | 🔴 CRÍTICO — Acesso direto ao banco |

**Verificações de chaves:**
- [ ] A `service_role key` NUNCA é exposta no frontend/client-side?
- [ ] A `service_role key` NUNCA está em código JavaScript do navegador?
- [ ] O `JWT secret` está armazenado de forma segura?
- [ ] A `anon key` é usada apenas com RLS habilitado?
- [ ] Chaves não estão hardcoded no código-fonte?
- [ ] Chaves não estão em histórico do Git?
- [ ] Variáveis de ambiente são usadas para todas as chaves?

### 3.3. Row Level Security (RLS)

RLS é o mecanismo principal de segurança de dados no Supabase. **Deve estar habilitado em TODAS as tabelas que contêm dados de usuários.**

#### 3.3.1. Verificação de RLS

```sql
-- Verificar quais tabelas têm RLS habilitado
SELECT schemaname, tablename, rowsecurity
FROM pg_tables
WHERE schemaname = 'public'
ORDER BY rowsecurity;

-- Tabelas SEM RLS (potencial risco)
SELECT schemaname, tablename
FROM pg_tables
WHERE schemaname = 'public'
AND rowsecurity = false;

-- Listar todas as políticas RLS
SELECT
  schemaname,
  tablename,
  policyname,
  permissive,
  roles,
  cmd,
  qual,
  with_check
FROM pg_policies
WHERE schemaname = 'public'
ORDER BY tablename, policyname;
```

#### 3.3.2. Análise de Políticas RLS

Para cada tabela, verificar se existem políticas adequadas para cada operação:

| Operação | Política Esperada | Verificação |
|---|---|---|
| **SELECT** | Usuário só vê seus dados | `auth.uid() = user_id` |
| **INSERT** | Usuário só insere com seu ID | `auth.uid() = user_id` na cláusula WITH CHECK |
| **UPDATE** | Usuário só atualiza seus dados | `auth.uid() = user_id` em USING e WITH CHECK |
| **DELETE** | Usuário só deleta seus dados | `auth.uid() = user_id` |

**Exemplos de políticas RLS:**

```sql
-- ✅ SEGURO - SELECT apenas dados próprios
CREATE POLICY "Usuários veem apenas seus dados"
ON public.profiles
FOR SELECT
USING (auth.uid() = user_id);

-- ✅ SEGURO - INSERT com verificação de ownership
CREATE POLICY "Usuários inserem apenas seus dados"
ON public.profiles
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- ✅ SEGURO - UPDATE com dupla verificação
CREATE POLICY "Usuários atualizam apenas seus dados"
ON public.profiles
FOR UPDATE
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- ❌ INSEGURO - permite tudo
CREATE POLICY "allow_all"
ON public.profiles
FOR ALL
USING (true);

-- ❌ INSEGURO - SELECT sem filtro de usuário
CREATE POLICY "everyone_can_read"
ON public.sensitive_data
FOR SELECT
USING (true);
```

#### 3.3.3. Armadilhas Comuns de RLS

- [ ] Política `USING (true)` em tabelas com dados sensíveis
- [ ] Falta de política `WITH CHECK` em INSERT/UPDATE (permite inserir dados de outros)
- [ ] RLS desabilitado em tabela exposta via API
- [ ] Funções `SECURITY DEFINER` que bypassam RLS sem verificação
- [ ] Uso de `service_role` key no frontend (ignora RLS completamente)
- [ ] Colunas sensíveis acessíveis sem filtragem adequada
- [ ] Joins que vazam dados de tabelas protegidas

### 3.4. Funções e Segurança

```sql
-- Listar funções e seu tipo de segurança
SELECT
  n.nspname as schema,
  p.proname as function_name,
  CASE p.prosecdef
    WHEN true THEN 'SECURITY DEFINER ⚠️'
    ELSE 'SECURITY INVOKER ✅'
  END as security_type,
  pg_get_functiondef(p.oid) as definition
FROM pg_proc p
JOIN pg_namespace n ON p.pronamespace = n.oid
WHERE n.nspname = 'public';
```

**Verificações de funções:**
- [ ] Funções `SECURITY DEFINER` são realmente necessárias?
- [ ] Funções `SECURITY DEFINER` validam `auth.uid()` internamente?
- [ ] Funções `SECURITY DEFINER` têm `search_path` definido explicitamente?
- [ ] Funções expostas via RPC validam parâmetros de entrada?
- [ ] Funções não executam SQL dinâmico com entrada do usuário sem sanitização?

---

## 4. Auditoria de Roles e Permissões

### 4.1. Princípio do Menor Privilégio

```sql
-- Verificar permissões por tabela
SELECT
  grantee,
  table_schema,
  table_name,
  privilege_type
FROM information_schema.table_privileges
WHERE table_schema = 'public'
ORDER BY table_name, grantee;

-- Verificar membros de roles
SELECT
  r.rolname as role,
  ARRAY_AGG(m.rolname) as members
FROM pg_auth_members am
JOIN pg_roles r ON r.oid = am.roleid
JOIN pg_roles m ON m.oid = am.member
GROUP BY r.rolname;

-- Verificar permissões de schema
SELECT
  nspname,
  nspacl
FROM pg_namespace
WHERE nspname NOT LIKE 'pg_%';
```

### 4.2. Checklist de Roles

- [ ] Cada aplicação/serviço usa um role dedicado (não o superuser)?
- [ ] O role `postgres` (superuser) não é usado pela aplicação?
- [ ] Roles de aplicação têm apenas as permissões necessárias?
- [ ] Roles não utilizados foram removidos?
- [ ] Senhas de roles têm complexidade adequada?
- [ ] Existe separação entre roles de leitura e escrita?
- [ ] Roles de backup não têm permissões excessivas?

---

## 5. Segurança de Conexão

### 5.1. Verificações de SSL/TLS

```sql
-- Verificar se SSL está habilitado
SHOW ssl;

-- Verificar conexões ativas usando SSL
SELECT datname, usename, ssl, client_addr
FROM pg_stat_ssl
JOIN pg_stat_activity ON pg_stat_ssl.pid = pg_stat_activity.pid;
```

- [ ] SSL está habilitado para todas as conexões remotas?
- [ ] Certificado SSL é válido e não expirado?
- [ ] Versão mínima do TLS é 1.2?
- [ ] Cipher suites fracas estão desabilitadas?
- [ ] Conexões sem SSL são rejeitadas (`hostnossl ... reject`)?

### 5.2. Pool de Conexões

- [ ] Connection pooler (PgBouncer, pgpool) está configurado?
- [ ] Limite máximo de conexões está definido?
- [ ] Timeout de conexão inativa está configurado?
- [ ] Conexões não utilizadas são liberadas?

---

## 6. Prevenção de Injeção SQL

### 6.1. Verificações de Código

```python
# ❌ VULNERÁVEL - concatenação de strings
query = f"SELECT * FROM users WHERE id = {user_input}"
cursor.execute(query)

# ❌ VULNERÁVEL - formatação de string
query = "SELECT * FROM users WHERE name = '%s'" % user_input
cursor.execute(query)

# ✅ SEGURO - consulta parametrizada
query = "SELECT * FROM users WHERE id = %s"
cursor.execute(query, (user_input,))

# ✅ SEGURO - ORM com binding
user = db.query(User).filter(User.id == user_input).first()
```

```javascript
// ❌ VULNERÁVEL - template literal
const query = `SELECT * FROM users WHERE id = ${userId}`;
await client.query(query);

// ✅ SEGURO - consulta parametrizada
const query = 'SELECT * FROM users WHERE id = $1';
await client.query(query, [userId]);

// ✅ SEGURO - Supabase client
const { data } = await supabase
  .from('users')
  .select('*')
  .eq('id', userId);
```

### 6.2. Stored Procedures e Funções

- [ ] Funções usam parâmetros tipados (não concatenação)?
- [ ] `EXECUTE ... USING` é usado em vez de `EXECUTE ... ||`?
- [ ] SQL dinâmico é evitado quando possível?
- [ ] Quando necessário, `quote_ident()` e `quote_literal()` são usados?

```sql
-- ❌ VULNERÁVEL - concatenação em função
CREATE FUNCTION get_user(p_name text) RETURNS SETOF users AS $$
BEGIN
  RETURN QUERY EXECUTE 'SELECT * FROM users WHERE name = ''' || p_name || '''';
END;
$$ LANGUAGE plpgsql;

-- ✅ SEGURO - parâmetro com USING
CREATE FUNCTION get_user(p_name text) RETURNS SETOF users AS $$
BEGIN
  RETURN QUERY EXECUTE 'SELECT * FROM users WHERE name = $1' USING p_name;
END;
$$ LANGUAGE plpgsql;
```

---

## 7. Segurança de Backups

### 7.1. Verificações

- [ ] Backups são realizados regularmente?
- [ ] Backups são criptografados em repouso?
- [ ] Backups são armazenados em local seguro e separado?
- [ ] Acesso aos backups é restrito a pessoal autorizado?
- [ ] Existe procedimento de restauração testado?
- [ ] Backups antigos são eliminados conforme política de retenção?
- [ ] Point-in-Time Recovery (PITR) está configurado?
- [ ] WAL (Write-Ahead Log) archiving está habilitado e protegido?

### 7.2. Criptografia de Backups

```bash
# ✅ Backup criptografado com pg_dump
pg_dump -Fc mydb | gpg --symmetric --cipher-algo AES256 -o backup.dump.gpg

# ✅ Verificar que backups não estão em texto plano em storage público
# Verificar permissões do bucket/diretório de backup
```

---

## 8. Gerenciamento de Variáveis de Ambiente e Segredos

### 8.1. Verificações

- [ ] Credenciais de banco de dados estão em variáveis de ambiente (não no código)?
- [ ] Arquivo `.env` está no `.gitignore`?
- [ ] `.env` de produção não está no repositório?
- [ ] Secrets manager é utilizado em produção (AWS Secrets Manager, Vault, etc.)?
- [ ] Connection strings não contêm senhas em logs?
- [ ] Senhas de banco não são passadas via linha de comando (visível em `ps`)?

### 8.2. Padrões de Verificação

```python
# ❌ INSEGURO - credenciais hardcoded
DATABASE_URL = "postgresql://admin:S3nha123@db.example.com:5432/mydb"

# ✅ SEGURO - variável de ambiente
import os
DATABASE_URL = os.environ.get("DATABASE_URL")

# ✅ SEGURO - secrets manager
from aws_secretsmanager import get_secret
db_config = get_secret("prod/database/credentials")
```

---

## 9. Avaliação de Exposição do Banco de Dados

### 9.1. Verificações de Exposição

- [ ] Banco de dados está acessível apenas pela rede interna?
- [ ] Porta do banco (5432, 3306, 27017) não está aberta publicamente?
- [ ] Painel de administração (pgAdmin, phpMyAdmin) não está exposto publicamente?
- [ ] APIs de gerenciamento não estão acessíveis sem autenticação?
- [ ] Métricas do banco não expõem informações sensíveis?

### 9.2. Verificação com Nmap (apenas alvos autorizados)

```bash
# Verificar se a porta do banco está aberta publicamente
nmap -sS -p 5432,3306,27017,1433,6379 <ALVO_AUTORIZADO>
```

---

## 10. MongoDB — Considerações Básicas

### 10.1. Verificações Essenciais

- [ ] Autenticação está habilitada (`--auth`)?
- [ ] `bindIp` não é `0.0.0.0` (ou tem firewall adequado)?
- [ ] TLS/SSL está habilitado para conexões?
- [ ] Roles seguem o princípio do menor privilégio?
- [ ] `mongod` não está exposto publicamente na porta 27017?
- [ ] Audit logging está habilitado?

```yaml
# ✅ mongod.conf seguro
security:
  authorization: enabled

net:
  bindIp: 127.0.0.1,10.0.1.5
  tls:
    mode: requireTLS
    certificateKeyFile: /etc/ssl/mongodb.pem
```

---

## 11. MySQL — Considerações Básicas

### 11.1. Verificações Essenciais

- [ ] `mysql_secure_installation` foi executado?
- [ ] Usuário root não é acessível remotamente?
- [ ] Banco de dados `test` foi removido?
- [ ] Contas anônimas foram removidas?
- [ ] `bind-address` está configurado para IP específico?
- [ ] Plugin de autenticação seguro está em uso (`caching_sha2_password`)?
- [ ] SSL está habilitado para conexões remotas?
- [ ] `GRANT ALL ON *.*` não é usado para contas de aplicação?

```sql
-- Verificar contas com acesso excessivo
SELECT user, host, plugin, Super_priv, Grant_priv
FROM mysql.user
WHERE Super_priv = 'Y' OR Grant_priv = 'Y';

-- Verificar contas sem senha
SELECT user, host FROM mysql.user WHERE authentication_string = '';

-- Verificar variáveis de segurança
SHOW VARIABLES LIKE 'bind_address';
SHOW VARIABLES LIKE 'require_secure_transport';
SHOW VARIABLES LIKE 'default_authentication_plugin';
```

---

## 12. Referências

- PostgreSQL Security Documentation: https://www.postgresql.org/docs/current/security.html
- Supabase Security Documentation: https://supabase.com/docs/guides/platform/security
- OWASP SQL Injection Prevention: https://cheatsheetseries.owasp.org/cheatsheets/SQL_Injection_Prevention_Cheat_Sheet.html
- CIS PostgreSQL Benchmark: https://www.cisecurity.org/benchmark/postgresql
- CIS MongoDB Benchmark: https://www.cisecurity.org/benchmark/mongodb
- CIS MySQL Benchmark: https://www.cisecurity.org/benchmark/oracle_mysql

---

*Última atualização: Outubro 2026*
*Referências cruzadas: [audit-methodology.md](./audit-methodology.md) | [code-security.md](./code-security.md) | [safe-testing-policy.md](./safe-testing-policy.md)*
