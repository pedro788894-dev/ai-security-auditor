# Metodologia de Auditoria de Segurança

> Documento de referência para agentes de IA realizando auditorias de segurança autorizadas.
> Este guia define as fases, processos e padrões a serem seguidos em cada auditoria.

---

## 1. Visão Geral

Uma auditoria de segurança é um processo sistemático e documentado para avaliar a postura de segurança de um sistema, aplicação ou infraestrutura. Este documento define a metodologia completa, baseada em frameworks reconhecidos como o **OWASP Testing Guide v4.2**, **PTES (Penetration Testing Execution Standard)** e **NIST SP 800-115 (Technical Guide to Information Security Testing and Assessment)**.

### 1.1. Princípios Fundamentais

- **Autorização explícita**: Toda auditoria deve possuir autorização documentada antes de iniciar qualquer atividade.
- **Escopo definido**: Apenas ativos explicitamente listados no escopo podem ser testados.
- **Segurança do alvo**: Nenhuma ação deve comprometer a disponibilidade, integridade ou confidencialidade dos sistemas auditados.
- **Documentação completa**: Cada fase, descoberta e decisão deve ser registrada com evidências.
- **Proporcionalidade**: A intensidade dos testes deve ser proporcional ao risco e à criticidade do ativo.

---

## 2. Fases da Auditoria

A auditoria é dividida em cinco fases sequenciais. Cada fase possui seus próprios objetivos, atividades e critérios de saída.

```mermaid
flowchart LR
    A["1. Reconhecimento"] --> B["2. Análise"]
    B --> C["3. Testes"]
    C --> D["4. Validação"]
    D --> E["5. Relatório"]
```

---

### 2.1. Fase 1 — Reconhecimento

**Objetivo**: Coletar informações sobre o alvo para identificar a superfície de ataque e planejar os testes.

#### 2.1.1. Reconhecimento Passivo

Coleta de informações **sem interação direta** com o alvo. Não gera tráfego para os sistemas auditados.

| Atividade | Descrição | Ferramentas / Fontes |
|---|---|---|
| Análise de código-fonte | Revisão de repositórios fornecidos | Git, GitHub, GitLab |
| Análise de documentação | Revisão de docs técnicos e APIs | Swagger/OpenAPI, READMEs |
| Pesquisa OSINT | Informações públicas sobre o alvo | DNS público, WHOIS, Shodan (consulta) |
| Análise de dependências | Identificação de bibliotecas e versões | `package.json`, `requirements.txt`, `go.mod` |
| Revisão de configuração | Análise de arquivos de configuração fornecidos | `.env.example`, `docker-compose.yml`, IaC |

#### 2.1.2. Reconhecimento Ativo

Coleta de informações **com interação direta** com o alvo. Requer autorização explícita e validação de escopo.

| Atividade | Descrição | Restrições |
|---|---|---|
| Varredura de portas | Identificação de serviços expostos | Apenas IPs/domínios autorizados |
| Fingerprinting de serviços | Identificação de versões e tecnologias | Sem exploração de vulnerabilidades |
| Enumeração de endpoints | Mapeamento de rotas e APIs | Respeitar rate limiting |
| Análise de respostas HTTP | Headers, cookies, tratamento de erros | Apenas requisições não destrutivas |

**Critérios de saída da Fase 1:**
- [ ] Inventário de ativos e tecnologias documentado
- [ ] Superfície de ataque mapeada
- [ ] Escopo validado e confirmado
- [ ] Plano de testes preliminar definido

#### 2.1.3. Documentação do Reconhecimento

Registrar para cada ativo identificado:

```markdown
## Ativo: [nome/URL/IP]

- **Tipo**: Aplicação Web / API / Serviço / Banco de Dados / Infraestrutura
- **Tecnologias identificadas**: [lista]
- **Versões detectadas**: [lista]
- **Endpoints mapeados**: [quantidade]
- **Dentro do escopo**: Sim / Não
- **Nível de criticidade estimado**: Alto / Médio / Baixo
- **Observações**: [notas relevantes]
```

---

### 2.2. Fase 2 — Análise

**Objetivo**: Analisar as informações coletadas para identificar potenciais vulnerabilidades e priorizar os testes.

#### 2.2.1. Atividades de Análise

1. **Modelagem de ameaças**: Identificar cenários de ataque relevantes com base na arquitetura do sistema.
2. **Análise de configuração**: Comparar configurações com baselines de segurança (CIS Benchmarks, OWASP).
3. **Revisão de código estático**: Analisar o código-fonte em busca de padrões vulneráveis (ver [code-security.md](./code-security.md)).
4. **Análise de dependências**: Verificar CVEs conhecidas em bibliotecas utilizadas.
5. **Mapeamento de fluxos de dados**: Identificar onde dados sensíveis são processados, armazenados e transmitidos.
6. **Análise de controles de acesso**: Mapear matriz de permissões e identificar possíveis escalações.

#### 2.2.2. Priorização Baseada em Risco

Priorizar os testes usando a seguinte matriz:

| Probabilidade \ Impacto | Baixo | Médio | Alto | Crítico |
|---|---|---|---|---|
| **Alta** | Médio | Alto | Crítico | Crítico |
| **Média** | Baixo | Médio | Alto | Crítico |
| **Baixa** | Informativo | Baixo | Médio | Alto |
| **Muito Baixa** | Informativo | Informativo | Baixo | Médio |

**Fatores de priorização:**
- Dados sensíveis envolvidos (PII, financeiros, saúde)
- Exposição pública do serviço
- Complexidade de exploração
- Existência de controles compensatórios
- Impacto no negócio

**Critérios de saída da Fase 2:**
- [ ] Lista priorizada de vulnerabilidades potenciais
- [ ] Plano de testes detalhado com casos de teste
- [ ] Riscos identificados e classificados
- [ ] Dependências e pré-requisitos de testes mapeados

---

### 2.3. Fase 3 — Testes

**Objetivo**: Executar testes de segurança para confirmar ou descartar vulnerabilidades identificadas na análise.

#### 2.3.1. Testes Passivos vs. Ativos

| Aspecto | Testes Passivos | Testes Ativos |
|---|---|---|
| **Interação com o alvo** | Nenhuma ou mínima (leitura) | Direta (envio de payloads) |
| **Risco para o sistema** | Nenhum | Baixo a moderado |
| **Autorização necessária** | Básica | Explícita e documentada |
| **Exemplos** | Revisão de código, análise de headers | Testes de injeção, bypass de autenticação |
| **Modo padrão** | ✅ Preferencial | ⚠️ Apenas com confirmação |

#### 2.3.2. Princípios de Testes Seguros

> ⚠️ **IMPORTANTE**: Consultar sempre a [Política de Testes Seguros](./safe-testing-policy.md) antes de executar qualquer teste ativo.

1. **Modo somente leitura por padrão**: Começar sempre com testes não destrutivos.
2. **Contas sintéticas**: Utilizar apenas contas de teste criadas para a auditoria. NUNCA usar contas reais de usuários.
3. **Dados de teste**: Utilizar dados fictícios para validação. NUNCA inserir dados reais.
4. **Rate limiting**: Respeitar limites de taxa e não sobrecarregar os sistemas.
5. **Rollback**: Quando possível, reverter qualquer alteração feita durante os testes.
6. **Monitoramento**: Acompanhar o impacto dos testes no sistema durante a execução.

#### 2.3.3. Categorias de Testes

Baseado no OWASP Testing Guide v4.2:

| Categoria | Referência OWASP | Documento de Referência |
|---|---|---|
| Autenticação | OTG-AUTHN | [authentication-security.md](./authentication-security.md) |
| Autorização | OTG-AUTHZ | [api-security.md](./api-security.md) |
| Gerenciamento de Sessão | OTG-SESS | [authentication-security.md](./authentication-security.md) |
| Validação de Entrada | OTG-INPVAL | [code-security.md](./code-security.md) |
| Criptografia | OTG-CRYPST | [network-security.md](./network-security.md) |
| Lógica de Negócio | OTG-BUSLOGIC | [api-security.md](./api-security.md) |
| Configuração | OTG-CONFIG | [cloud-and-saas-security.md](./cloud-and-saas-security.md) |
| Banco de Dados | — | [database-security.md](./database-security.md) |

#### 2.3.4. Coleta de Evidências

Para cada teste realizado, documentar:

```markdown
### Teste: [ID do teste]

- **Categoria**: [categoria OWASP]
- **Alvo**: [ativo testado]
- **Método**: [técnica utilizada]
- **Payload/Input**: [dado de entrada - SANITIZADO]
- **Resposta**: [resposta observada - SEM DADOS SENSÍVEIS]
- **Resultado**: Vulnerável / Não Vulnerável / Inconclusivo
- **Severidade**: [classificação conforme severity-classification.md]
- **Evidência**: [screenshot, log, trecho de código - SANITIZADO]
- **Reprodutibilidade**: [passos para reproduzir]
- **Impacto**: [descrição do impacto potencial]
```

> 🔴 **REGRA ABSOLUTA**: Nunca incluir dados sensíveis reais nas evidências. Sanitizar credenciais, tokens, PII e quaisquer dados confidenciais antes de registrar.

**Critérios de saída da Fase 3:**
- [ ] Todos os casos de teste priorizados foram executados
- [ ] Evidências coletadas e sanitizadas para cada teste
- [ ] Vulnerabilidades confirmadas documentadas com reprodutibilidade
- [ ] Nenhum impacto negativo causado ao sistema auditado

---

### 2.4. Fase 4 — Validação

**Objetivo**: Verificar a precisão das descobertas, eliminar falsos positivos e confirmar a classificação de severidade.

#### 2.4.1. Atividades de Validação

1. **Revisão de falsos positivos**: Re-testar cada vulnerabilidade para confirmar que é genuína.
2. **Validação de severidade**: Aplicar CVSS v3.1 para classificar cada vulnerabilidade (ver [severity-classification.md](./severity-classification.md)).
3. **Verificação de contexto**: Avaliar se controles compensatórios mitigam o risco.
4. **Correlação de descobertas**: Identificar cadeias de vulnerabilidades que aumentam o impacto.
5. **Validação de remediação**: Se correções foram aplicadas durante a auditoria, verificar sua eficácia.

#### 2.4.2. Critérios de Validação

| Critério | Descrição |
|---|---|
| **Reprodutível** | A vulnerabilidade pode ser reproduzida consistentemente |
| **Impactante** | O impacto é real e mensurável |
| **Exploitável** | A vulnerabilidade pode ser explorada no contexto do sistema |
| **Não mitigada** | Não existe controle compensatório eficaz |

**Critérios de saída da Fase 4:**
- [ ] Todas as descobertas foram validadas
- [ ] Falsos positivos removidos ou marcados
- [ ] Severidades confirmadas com CVSS v3.1
- [ ] Cadeias de vulnerabilidades documentadas

---

### 2.5. Fase 5 — Relatório

**Objetivo**: Produzir documentação clara, acionável e completa das descobertas para a equipe de desenvolvimento/segurança.

#### 2.5.1. Estrutura do Relatório

```markdown
# Relatório de Auditoria de Segurança

## 1. Sumário Executivo
- Escopo da auditoria
- Período de execução
- Resumo das descobertas por severidade
- Principais riscos identificados
- Recomendações prioritárias

## 2. Escopo e Metodologia
- Ativos auditados
- Metodologia utilizada
- Limitações da auditoria
- Ferramentas utilizadas

## 3. Resumo de Descobertas
- Tabela consolidada de vulnerabilidades
- Gráfico de distribuição por severidade
- Tendências e padrões observados

## 4. Descobertas Detalhadas
Para cada vulnerabilidade:
### [ID] - [Título da Vulnerabilidade]
- **Severidade**: [Crítica/Alta/Média/Baixa/Informativa]
- **CVSS v3.1**: [Score] ([Vetor])
- **Localização**: [Onde no sistema]
- **Descrição**: [Explicação técnica]
- **Impacto**: [Consequências potenciais]
- **Evidência**: [Prova sanitizada]
- **Reprodução**: [Passos para reproduzir]
- **Remediação**: [Recomendações específicas]
- **Referências**: [CWE, CVE, OWASP]

## 5. Recomendações Estratégicas
- Melhorias de processo
- Treinamento sugerido
- Investimentos recomendados

## 6. Anexos
- Detalhes técnicos adicionais
- Lista completa de testes realizados
- Glossário
```

#### 2.5.2. Boas Práticas do Relatório

- **Linguagem clara**: Evitar jargão desnecessário; o relatório deve ser compreensível por diferentes públicos.
- **Ações concretas**: Cada descoberta deve conter recomendações de remediação específicas e acionáveis.
- **Priorização**: As descobertas devem ser ordenadas por severidade e impacto no negócio.
- **Sanitização**: Garantir que nenhum dado sensível real está presente no relatório.
- **Rastreabilidade**: Cada descoberta deve ter um ID único para rastreamento.

---

## 3. Quando Parar os Testes

A auditoria deve ser **imediatamente interrompida** nas seguintes situações:

| Situação | Ação |
|---|---|
| Instabilidade do sistema detectada | Parar todos os testes ativos, documentar e notificar |
| Alvo fora do escopo atingido | Parar imediatamente, documentar o incidente |
| Dados sensíveis reais encontrados | Não copiar, não armazenar, documentar a existência sem o conteúdo |
| Erro grave causado por teste | Parar, documentar, notificar equipe responsável |
| Exploração de alta severidade confirmada | Documentar sem explorar mais, escalar conforme política |
| Dúvida sobre autorização | Parar e confirmar antes de continuar |

---

## 4. Validação de Escopo em Cada Fase

A validação de escopo é **obrigatória** em cada transição de fase:

```
Antes da Fase 1: Confirmar autorização e lista de ativos
Antes da Fase 2: Revalidar se ativos descobertos estão no escopo
Antes da Fase 3: Confirmar que cada teste está dentro do escopo autorizado
Antes da Fase 4: Verificar que validações são feitas apenas em ativos do escopo
Antes da Fase 5: Confirmar que o relatório não inclui informações fora do escopo
```

**Checklist de validação de escopo:**
- [ ] O ativo está explicitamente listado na autorização?
- [ ] O tipo de teste está permitido para este ativo?
- [ ] O horário dos testes está dentro da janela autorizada?
- [ ] Os métodos de teste estão dentro das restrições definidas?
- [ ] Existe confirmação documentada do proprietário do ativo?

---

## 5. Referências de Frameworks

### 5.1. OWASP Testing Guide v4.2
- Guia completo de testes de segurança para aplicações web
- Define categorias de testes e metodologia padrão
- Disponível em: https://owasp.org/www-project-web-security-testing-guide/

### 5.2. PTES (Penetration Testing Execution Standard)
- Define o fluxo completo de um teste de penetração
- Fases: Pre-engagement, Intelligence Gathering, Threat Modeling, Vulnerability Analysis, Exploitation, Post-Exploitation, Reporting
- Disponível em: http://www.pentest-standard.org/

### 5.3. NIST SP 800-115
- Guia técnico do NIST para avaliação de segurança
- Foco em planejamento, execução e análise de resultados
- Define técnicas de revisão, identificação e teste
- Disponível em: https://csrc.nist.gov/publications/detail/sp/800-115/final

---

## 6. Checklist Geral da Auditoria

```markdown
## Pré-Auditoria
- [ ] Autorização documentada recebida
- [ ] Escopo claramente definido
- [ ] Contatos de emergência identificados
- [ ] Janela de testes acordada
- [ ] Ambiente de teste vs. produção definido

## Durante a Auditoria
- [ ] Validação de escopo em cada fase
- [ ] Evidências coletadas e sanitizadas
- [ ] Princípios de teste seguro seguidos
- [ ] Nenhum impacto negativo causado
- [ ] Descobertas críticas escaladas imediatamente

## Pós-Auditoria
- [ ] Relatório completo entregue
- [ ] Dados de teste removidos dos sistemas
- [ ] Contas de teste desativadas
- [ ] Acompanhamento de remediação agendado
- [ ] Lições aprendidas documentadas
```

---

*Última atualização: Outubro 2026*
*Referências cruzadas: [safe-testing-policy.md](./safe-testing-policy.md) | [severity-classification.md](./severity-classification.md)*
