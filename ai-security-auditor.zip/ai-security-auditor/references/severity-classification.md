# Classificação de Severidade de Vulnerabilidades

Este documento estabelece o padrão rigoroso de classificação de severidade adotado pelo **AI Security Auditor**, baseado no **CVSS v3.1 (Common Vulnerability Scoring System)** e adaptado para auditorias defensivas e priorização de remediação.

---

## 1. Princípios da Classificação

1. **Evidência sobre Especulação**: Nenhuma severidade deve ser estimada com base em suposições teóricas sem evidência concreta observada no alvo.
2. **Impacto no Contexto do Negócio**: A gravidade real depende da criticidade dos ativos, sensibilidade dos dados expostos e facilidade de exploração.
3. **Não Inflar Severidades**: Evitar alarmismo classificando configurações subótimas como "Críticas" ou "Altas" sem vetor de ataque viável.
4. **Vetor CVSS Obrigatório**: Todo achado categorizado com pontuação numérica deve acompanhar a string formal do vetor CVSS v3.1.

---

## 2. Escala de Severidade (CVSS v3.1)

| Nível | Pontuação CVSS | SLA Recomendado de Correção | Ação Requerida |
| :--- | :--- | :--- | :--- |
| **Crítico (Critical)** | 9.0 – 10.0 | Imediato (< 24 horas) | Notificação imediata ao responsável técnico, contenção urgente |
| **Alto (High)** | 7.0 – 8.9 | Curto Prazo (< 7 dias) | Prioridade no backlog de engenharia/DevSecOps |
| **Médio (Medium)** | 4.0 – 6.9 | Médio Prazo (< 30 dias) | Correção em sprint regular de manutenção/desenvolvimento |
| **Baixo (Low)** | 0.1 – 3.9 | Longo Prazo (< 90 dias) | Endurecimento (hardening) e melhorias contínuas |
| **Informativo (Info)** | 0.0 | A critério da equipe | Boas práticas, documentação e auditoria interna |

---

## 3. As Três Métricas do CVSS v3.1

### 3.1. Métricas Base (Base Score)
Representa as qualidades intrínsecas e imutáveis da vulnerabilidade independente de tempo ou ambiente do usuário:

* **Vetor de Exploração (Attack Vector - AV)**:
  * `Network (N)`: Remoto, acessível pela internet ou rede adjacente sem restrições.
  * `Adjacent (A)`: Requer acesso à mesma rede física/lógica (ex: Wi-Fi local, VLAN interna).
  * `Local (L)`: Requer acesso local via console, terminal ou permissões de usuário no sistema operacional.
  * `Physical (P)`: Requer interação física com o hardware/dispositivo.

* **Complexidade do Ataque (Attack Complexity - AC)**:
  * `Low (L)`: Condições previsíveis, sem exigência de corrida de processos (race conditions) ou circunstâncias especiais.
  * `High (H)`: Exige preparação específica, condições de temporização raras ou informações privilegiadas.

* **Privilégios Necessários (Privileges Required - PR)**:
  * `None (N)`: Não autenticado; qualquer ator externo pode explorar.
  * `Low (L)`: Requer credenciais de usuário padrão com permissões básicas.
  * `High (H)`: Requer privilégios administrativos ou de operador do sistema.

* **Interação do Usuário (User Interaction - UI)**:
  * `None (N)`: Não requer nenhuma ação da vítima.
  * `Required (R)`: Requer que um usuário clique em um link, execute um arquivo ou seja vítima de phishing/CSRF.

* **Escopo (Scope - S)**:
  * `Unchanged (U)`: O impacto restringe-se ao próprio componente vulnerável.
  * `Changed (C)`: O impacto afeta recursos gerenciados por outras autoridades (ex: bypass de sandbox, escape de container, injeção afetando clientes).

* **Impacto na Tríade CIA**:
  * **Confidencialidade (C)**: `High (H)`, `Low (L)`, `None (N)`.
  * **Integridade (I)**: `High (H)`, `Low (L)`, `None (N)`.
  * **Disponibilidade (A)**: `High (H)`, `Low (L)`, `None (N)`.

---

## 4. Exemplos Práticos por Categoria de Severidade

### 4.1. Crítico (Critical: 9.0 – 10.0)
* **Execução Remota de Código (RCE) não autenticada**: Endpoints de upload sem validação aceitando arquivos executáveis (ex: web shells).
* **Bypass Completo de Autenticação**: Quebra na validação de JWT (`alg: none` ou chave nula) permitindo forjar tokens de qualquer usuário administrador.
* **SQL Injection não autenticado em base sensível**: Exfiltração total de tabelas de senhas e dados financeiros via endpoint público.
* **Exposição de Credencial Master**: Service Role Key do Supabase ou AWS Secret Key com `AdministratorAccess` commitada em repositório público.

### 4.2. Alto (High: 7.0 – 8.9)
* **BOLA / IDOR com Alteração ou Acesso a Dados Pessoais de Terceiros**: Acesso autenticado permitindo ler/alterar registros de outras organizações sem autorização.
* **Server-Side Request Forgery (SSRF) Interno**: Endpoint permitindo consultar serviços internos de metadados (`http://169.254.169.254/`).
* **SQL Injection Autenticado**: Usuário de nível baixo com permissão de injetar comandos no banco de dados.
* **Cross-Site Scripting (XSS) Armazenado (Stored)**: Injeção persistente em painel de administração acessado por operadores.

### 4.3. Médio (Medium: 4.0 – 6.9)
* **Ausência de Rate Limiting em Endpoint de Autenticação**: Possibilidade de força bruta offline ou tentativas automatizadas de credenciais.
* **XSS Refletido (Reflected XSS)**: Requer que a vítima clique em link malicioso forjado.
* **Cross-Site Request Forgery (CSRF)**: Ações secundárias não idempotentes sem validação de tokens anti-CSRF ou SameSite permissivo.
* **CORS Excessivamente Permissivo com Credenciais**: `Access-Control-Allow-Origin: *` com endpoints de leitura autenticada.

### 4.4. Baixo (Low: 0.1 – 3.9)
* **Divulgação de Versão de Servidor / Headers Verbosos**: Headers `Server: Apache/2.4.41` ou `X-Powered-By: Express` sem vulnerabilidade conhecida associada.
* **Falta de Headers de Segurança Recomendados**: Ausência de `Strict-Transport-Security` (HSTS), `X-Content-Type-Options: nosniff` ou `Content-Security-Policy`.
* **Cookie de Sessão sem Flag HttpOnly em contexto de baixo risco**: Risco reduzido na ausência de vetores de XSS viáveis.

### 4.5. Informativo (Info: 0.0)
* Sugestões de melhoria arquitetural (ex: migração para Argon2id em vez de bcrypt com custo baixo).
* Comentários deixados no código sem dados sensíveis (TODOs genéricos).
* Políticas internas de governança recomendadas.

---

## 5. Falhas Comuns de Classificação a Evitar

1. **Classificar Falta de Header HTTP como Severidade Alta**: A ausência de CSP ou HSTS isoladamente representa um risco baixo ou informativo, a menos que haja um vetor de exploração ativo agravado.
2. **Confundir Teoria com Prova de Conceito**: Assumir que um endpoint permite BOLA sem ter verificado o comportamento de rejeição/aceitação entre identificadores distintos.
3. **Ignorar Defesas em Camadas**: Classificar um bucket com leitura pública como "Crítico" quando o bucket armazena apenas assets públicos e intencionais do site (ex: imagens estáticas do blog).
4. **Falsos Positivos de Scanner Automático**: Declarar CVE crítica indicada por scanner em biblioteca que não está em execução no caminho crítico ou foi empacotada em branch de desenvolvimento.
