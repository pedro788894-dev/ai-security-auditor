#!/bin/sh
set -e

# ==============================================================================
# Entrypoint para o AI Security Auditor Container
# ==============================================================================

show_help() {
    cat << EOF
==============================================================================
  AI Security Auditor — Container de Auditoria de Seguranca Defensiva
==============================================================================

Uso: docker run --rm [opcoes] ai-security-auditor [COMANDO]

Comandos disponiveis:
  preflight                  Executa diagnostico de ferramentas e estrutura
  test                       Executa a suite completa de 69 testes unitarios
  validate-scope <arquivo>   Valida um documento JSON de escopo de auditoria
  check-report <arquivo>     Valida um relatorio JSON e detecta segredos
  scan-code [diretorio]      Executa analise SAST (Semgrep/Gitleaks/Trivy) em /target
  bash / sh                  Abre terminal interativo no container
  help                       Exibe esta mensagem de ajuda

Exemplos:
  # 1. Executar preflight:
  docker run --rm ai-security-auditor preflight

  # 2. Executar testes automatizados:
  docker run --rm ai-security-auditor test

  # 3. Validar escopo montado:
  docker run --rm -v \$(pwd)/meu-escopo.json:/app/escopo.json:ro ai-security-auditor validate-scope escopo.json

  # 4. Auditar codigo-fonte local com montagem somente leitura:
  docker run --rm -v /caminho/do/projeto:/target:ro -v \$(pwd)/reports:/reports ai-security-auditor scan-code

==============================================================================
EOF
}

case "$1" in
    preflight)
        echo "[*] Executando verificacao pre-voo do AI Security Auditor..."
        exec python /app/scripts/preflight.py --project-dir /app
        ;;
    test)
        echo "[*] Executando suite completa de testes automatizados..."
        cd /app
        exec python -m unittest discover -s scripts/tests -v
        ;;
    validate-scope)
        shift
        if [ -z "$1" ]; then
            echo "[-] ERRO: Informe o caminho do arquivo de escopo JSON."
            echo "Exemplo: docker run --rm -v \$(pwd)/scope.json:/app/scope.json:ro ai-security-auditor validate-scope scope.json"
            exit 1
        fi
        exec python /app/scripts/validate_scope.py --scope-file "$1"
        ;;
    check-report)
        shift
        if [ -z "$1" ]; then
            echo "[-] ERRO: Informe o caminho do arquivo de relatorio JSON."
            echo "Exemplo: docker run --rm -v \$(pwd)/report.json:/app/report.json:ro ai-security-auditor check-report report.json"
            exit 1
        fi
        exec python /app/scripts/check_report.py --report-file "$1"
        ;;
    scan-code)
        shift
        TARGET_DIR="${1:-/target}"
        REPORT_DIR="/reports"
        echo "=============================================================================="
        echo "  INICIANDO VARREDURA DEFENSIVA DE CODIGO EM: ${TARGET_DIR}"
        echo "=============================================================================="

        if [ ! -d "$TARGET_DIR" ] || [ -z "$(ls -A "$TARGET_DIR" 2>/dev/null)" ]; then
            echo "[-] AVISO: O diretorio ${TARGET_DIR} esta vazio ou nao montado."
            echo "    Monte seu projeto com: -v /caminho/do/projeto:/target:ro"
            exit 1
        fi

        echo "[1/3] Executando analise estatica de segredos (Gitleaks)..."
        if command -v gitleaks >/dev/null 2>&1; then
            gitleaks detect --source="${TARGET_DIR}" --no-git --report-path="${REPORT_DIR}/gitleaks-findings.json" --verbose || true
            echo "[+] Gitleaks finalizado. Relatorio: ${REPORT_DIR}/gitleaks-findings.json"
        else
            echo "[-] Gitleaks nao disponivel no container."
        fi

        echo "[2/3] Executando analise estatica de vulnerabilidades (Semgrep)..."
        if command -v semgrep >/dev/null 2>&1; then
            semgrep scan --config="p/security-audit" --config="p/owasp-top-ten" --json --output="${REPORT_DIR}/semgrep-findings.json" "${TARGET_DIR}" || true
            echo "[+] Semgrep finalizado. Relatorio: ${REPORT_DIR}/semgrep-findings.json"
        else
            echo "[-] Semgrep nao disponivel no container."
        fi

        echo "[3/3] Executando analise de dependencias e configuracoes (Trivy)..."
        if command -v trivy >/dev/null 2>&1; then
            trivy fs --format json --output "${REPORT_DIR}/trivy-findings.json" "${TARGET_DIR}" || true
            echo "[+] Trivy finalizado. Relatorio: ${REPORT_DIR}/trivy-findings.json"
        else
            echo "[-] Trivy nao disponivel no container."
        fi

        echo "=============================================================================="
        echo "  VARREDURA CONCLUIDA COM SUCESSO!"
        echo "  Relatorios salvos em: ${REPORT_DIR}"
        echo "=============================================================================="
        ;;
    help|--help|-h)
        show_help
        ;;
    bash|sh)
        exec /bin/bash "$@"
        ;;
    *)
        if [ -n "$1" ]; then
            exec "$@"
        else
            show_help
        fi
        ;;
esac
