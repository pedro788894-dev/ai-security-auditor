# Guia de Execução com Docker — AI Security Auditor

Este guia explica como utilizar o **AI Security Auditor** em qualquer sistema operacional (Windows, macOS ou Linux) através do **Docker**, garantindo portabilidade total e fornecendo todas as ferramentas pré-instaladas (Python, Semgrep, Trivy, Gitleaks, Nmap) sem poluir o sistema operacional hospedeiro.

---

## 1. Por que usar Docker?

* **Zero dependências locais**: Não é necessário instalar Python, Semgrep ou Nmap na sua máquina principal.
* **Isolamento de Segurança**: O código do alvo é montado como **somente leitura (`:ro`)**, impossibilitando qualquer alteração ou dano acidental ao repositório auditado.
* **Reprodutibilidade**: O ambiente de auditoria é idêntico em qualquer computador, servidor de CI/CD ou estação de trabalho.
* **Ferramentas Prontas**: Inclui Semgrep, Gitleaks, Trivy e Nmap em um único container leve baseado em Debian Slim.

---

## 2. Construindo a Imagem Docker

No diretório do projeto `ai-security-auditor`:

```bash
docker build -t ai-security-auditor .
```

---

## 3. Comandos Rápidos

### 3.1. Verificação Pré-Voo (Preflight)
Verifica se todas as ferramentas internas do container estão prontas e operacionais:

```bash
docker run --rm ai-security-auditor preflight
```

### 3.2. Executar a Suíte Completa de Testes (69 testes)
```bash
docker run --rm ai-security-auditor test
```

### 3.3. Validar um Documento de Escopo
Valida se o arquivo JSON de escopo cumpre todas as regras do schema e restrições de segurança:

```bash
# Linux/macOS
docker run --rm -v $(pwd)/meu-escopo.json:/app/meu-escopo.json:ro ai-security-auditor validate-scope meu-escopo.json

# Windows PowerShell
docker run --rm -v ${PWD}/meu-escopo.json:/app/meu-escopo.json:ro ai-security-auditor validate-scope meu-escopo.json
```

### 3.4. Validar Relatório e Checar Vazamento de Segredos
Garante que o relatório está estruturado e higienizado antes de entregá-lo:

```bash
docker run --rm -v $(pwd)/relatorio.json:/app/relatorio.json:ro ai-security-auditor check-report relatorio.json
```

---

## 4. Auditoria Segura de Código-Fonte Local (`scan-code`)

O comando `scan-code` roda automaticamente **Gitleaks**, **Semgrep** e **Trivy** sobre o código montado em `/target` e salva os relatórios sanitizados no diretório `/reports`:

### Linux / macOS
```bash
docker run --rm \
  -v /caminho/do/seu/projeto:/target:ro \
  -v $(pwd)/meus-relatorios:/reports \
  ai-security-auditor scan-code
```

### Windows (PowerShell)
```powershell
docker run --rm `
  -v C:\caminho\do\seu\projeto:/target:ro `
  -v ${PWD}\meus-relatorios:/reports `
  ai-security-auditor scan-code
```

---

## 5. Utilizando com Docker Compose

Você também pode utilizar o arquivo `docker-compose.yml` pré-configurado:

1. Crie a pasta `target` e copie/linke o código a ser auditado:
   ```bash
   mkdir -p target reports
   ```

2. Execute o auditor:
   ```bash
   # Executa o preflight
   docker compose up security-auditor

   # Executa os testes automatizados
   docker compose run --rm test-runner

   # Executa a varredura de código
   docker compose run --rm security-auditor scan-code
   ```

---

## 6. Endurecimento de Segurança do Container

O container foi construído seguindo os mais altos padrões de segurança:
* **Usuário não-root**: A execução é restrita ao usuário `auditor` (UID 1000).
* **Capacidades Mínimas (`cap_drop: ALL`)**: Remove todas as permissões especiais de kernel.
* **Alvo Imutável**: O volume do código alvo é **obrigatoriamente montado com flag `:ro`** (Read-Only).
