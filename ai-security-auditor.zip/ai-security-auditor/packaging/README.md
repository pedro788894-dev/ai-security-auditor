# Empacotamento e Distribuição

## Gerando o ZIP para Distribuição

### Linux/macOS

```bash
cd ai-security-auditor/
cd ..
zip -r ai-security-auditor.zip ai-security-auditor/ \
  -x "ai-security-auditor/__pycache__/*" \
  -x "ai-security-auditor/scripts/__pycache__/*" \
  -x "ai-security-auditor/scripts/tests/__pycache__/*" \
  -x "ai-security-auditor/*.pyc" \
  -x "ai-security-auditor/.venv/*" \
  -x "ai-security-auditor/venv/*"
```

### Windows PowerShell

```powershell
Compress-Archive -Path ai-security-auditor\* -DestinationPath ai-security-auditor.zip -Force
```

## Verificação do ZIP

Após gerar o ZIP, verifique se o `SKILL.md` está presente:

```bash
# Linux/macOS
unzip -l ai-security-auditor.zip | grep SKILL.md

# Windows PowerShell
# O ZIP é gerado na raiz; os arquivos estarão diretamente dentro
```

## Instalação a partir do ZIP

### 1. Extraia o ZIP

```bash
# Linux/macOS
unzip ai-security-auditor.zip -d destino/

# Windows PowerShell
Expand-Archive -Path ai-security-auditor.zip -DestinationPath destino\
```

### 2. Copie para o diretório de skills do agente

Siga as instruções de instalação no `README.md` ou nos guias específicos em `agents/`.

## Estrutura Esperada no ZIP

O ZIP deve conter todos os arquivos do projeto, exceto:

- `__pycache__/` e arquivos `.pyc`
- Ambientes virtuais (`venv/`, `.venv/`)
- Relatórios de auditoria reais
- Escopos de auditoria reais
- Logs de execução
- Credenciais ou segredos

## Validação Pós-Instalação

Após instalar, execute:

```bash
# Verificar estrutura
python scripts/preflight.py --project-dir .

# Executar testes
python -m pytest scripts/tests/ -v

# Validar exemplo de escopo
python scripts/validate_scope.py --scope-file examples/sample-scope.json
```
