#!/usr/bin/env python3
"""
Script de empacotamento e distribuição do AI Security Auditor.
Gera o arquivo ai-security-auditor.zip contendo a estrutura da skill
e valida sua integridade.
"""

import os
import sys
import zipfile
from pathlib import Path

# Configurar stdout/stderr seguro
if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

PROJECT_ROOT = Path(__file__).resolve().parent.parent
OUTPUT_ZIP = PROJECT_ROOT.parent / "ai-security-auditor.zip"

EXCLUDE_DIRS = {
    "__pycache__",
    ".pytest_cache",
    ".venv",
    "venv",
    ".git",
    "dist",
    "build",
}

EXCLUDE_EXTENSIONS = {
    ".pyc",
    ".pyo",
    ".pyd",
    ".DS_Store",
    ".zip",
}

def create_distribution_zip(project_dir: Path, output_zip_path: Path) -> Path:
    """Cria arquivo ZIP a partir do diretório do projeto ignorando artefatos temporários."""
    print(f"[*] Empacotando de: {project_dir}")
    print(f"[*] Destino: {output_zip_path}")
    
    file_count = 0
    with zipfile.ZipFile(output_zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(project_dir):
            # Filtrar diretórios indesejados
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
            
            for file in files:
                ext = Path(file).suffix.lower()
                if ext in EXCLUDE_EXTENSIONS:
                    continue
                if file.endswith("~") or file.startswith(".#"):
                    continue
                
                full_path = Path(root) / file
                rel_path = full_path.relative_to(project_dir)
                archive_name = Path("ai-security-auditor") / rel_path
                
                zipf.write(full_path, arcname=str(archive_name).replace("\\", "/"))
                file_count += 1
                
    print(f"[+] Total de arquivos empacotados: {file_count}")
    return output_zip_path

def verify_zip(zip_path: Path) -> bool:
    """Verifica a integridade do arquivo ZIP gerado e a presença dos arquivos críticos."""
    print(f"[*] Verificando integridade de: {zip_path}")
    if not zip_path.exists():
        print("[-] ERRO: Arquivo ZIP não foi encontrado!")
        return False
        
    with zipfile.ZipFile(zip_path, "r") as zipf:
        # Testa integridade CRC
        test_result = zipf.testzip()
        if test_result is not None:
            print(f"[-] ERRO: Arquivo corrompido no ZIP: {test_result}")
            return False
            
        namelist = zipf.namelist()
        
        required_in_zip = [
            "ai-security-auditor/SKILL.md",
            "ai-security-auditor/README.md",
            "ai-security-auditor/LICENSE",
            "ai-security-auditor/schemas/scope.schema.json",
            "ai-security-auditor/schemas/report.schema.json",
            "ai-security-auditor/scripts/run_audit.py",
            "ai-security-auditor/scripts/auto_scope.py",
            "ai-security-auditor/scripts/brute_force_auditor.py",
            "ai-security-auditor/scripts/db_security_auditor.py",
            "ai-security-auditor/scripts/executable_auditor.py",
            "ai-security-auditor/scripts/web_auditor.py",
            "ai-security-auditor/scripts/preflight.py",
            "ai-security-auditor/scripts/validate_scope.py",
            "ai-security-auditor/scripts/check_report.py",
            "ai-security-auditor/templates/scope-template.json",
            "ai-security-auditor/templates/report-template.md",
            "ai-security-auditor/examples/sample-scope.json",
            "ai-security-auditor/examples/sample-report.md",
        ]
        
        missing = [req for req in required_in_zip if req not in namelist]
        if missing:
            print(f"[-] ERRO: Arquivos obrigatórios faltando no ZIP: {missing}")
            return False
            
    print(f"[+] Integridade verificada com sucesso! SKILL.md e arquivos essenciais presentes.")
    return True

if __name__ == "__main__":
    out = create_distribution_zip(PROJECT_ROOT, OUTPUT_ZIP)
    success = verify_zip(out)
    if not success:
        sys.exit(1)
    print(f"[OK] ZIP gerado com sucesso em: {out}")
