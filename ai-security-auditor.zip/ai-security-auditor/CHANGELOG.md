# Changelog

Todas as alterações relevantes deste projeto serão documentadas neste arquivo.

O formato é baseado em [Keep a Changelog](https://keepachangelog.com/pt-BR/1.1.0/),
e este projeto adere ao [Versionamento Semântico](https://semver.org/lang/pt-BR/).

## [2.0.0] - 2026-10-21

### Adicionado
- **Experiência Simplificada de Auditoria**:
  - Auditoria automática direta informando URL (`--url`), executável (`--file`) ou repositório (`--code`).
  - Geração automática e transparente de escopo temporário (`scripts/auto_scope.py`) sem exigir preenchimento manual de JSON ou configuração prévia de laboratório.
- **Auditor Especializado em Força Bruta e Autenticação** (`scripts/brute_force_auditor.py`):
  - Classificação de defesas em 4 estados: *Hard lockout*, *Soft IP throttle*, *CAPTCHA injection* e *Silent shadow-throttle*.
  - Metodologia de *Shadow-Throttle Seed Test* para login e OTP/2FA.
  - Avaliação de proteções *account-based* vs *IP-only* (resistência a credential stuffing e password spraying).
  - Detecção rigorosa de enumeração de usuários e timing side-channels baseada na mediana de pelo menos 30 amostras.
  - Análise estática de código para ausência de middlewares de rate limit, tokens de reset fracos e bypass de MFA.
- **Auditoria de Segurança de Banco de Dados** (`scripts/db_security_auditor.py`):
  - Operação estritamente somente leitura (proibição absoluta de INSERT, UPDATE, DELETE, DROP).
  - Detecção estática de injeção de SQL (concatenação, f-strings, ORDER BY e LIKE dinâmicos, raw queries de ORMs).
  - Detecção estática de injeção NoSQL (MongoDB/Mongoose via objetos não sanitizados e operadores `$gt`/`$ne`/`$where`).
  - Inventário de portas de bancos expostas na rede (PostgreSQL 5432, MySQL 3306, MongoDB 27017, Redis 6379, MSSQL 1433, Elasticsearch 9200/9300).
  - Detecção de dumps e backups expostos (`.sql`, `.dump`, `.bak`) e conexões via superusuários (`root`, `sa`, `postgres`).
- **Análise Estática de Executáveis** (`scripts/executable_auditor.py`):
  - Inspeção de cabeçalhos PE sem execução de binários desconhecidos no host.
  - Verificação de mitigações de compilador: ASLR, DEP/NX, SafeSEH, High Entropy VA e assinatura digital (Authenticode).
  - Extração estática de strings (URLs, IPs, comandos shell embutidos).
  - Detecção de APIs sensíveis de injeção de memória, keylogging e acesso a credenciais.
- **Orquestrador Unificado e Relatório Automático** (`scripts/run_audit.py`):
  - Emissão automática de relatórios em Markdown e JSON estruturado validado contra `schemas/report.schema.json`.
  - Sanitização automática de credenciais, tokens e segredos em evidências técnicas.
- **Novas Suítes de Testes Automatizados**:
  - Testes para escopo automático (`test_auto_scope.py`).
  - Testes para classificação de defesas e interrupção segura (`test_brute_force_auditor.py`).
  - Testes para injeção de SQL/NoSQL e banco de dados (`test_db_security_auditor.py`).
  - Testes para análise de binários (`test_executable_auditor.py`).
  - Testes de integração de ponta a ponta (`test_run_audit.py`).

### Modificado
- `SKILL.md`: Atualizado para versão 2.0.0 com instruções completas para agente de IA sênior, novos fluxos de trabalho e salvaguardas operacionais.
- `packaging/build_dist.py`: Atualizado com os novos módulos e scripts incluídos na verificação de integridade da distribuição.

## [1.0.0] - 2026-10-20

### Adicionado

- `SKILL.md` — Instrução principal com fases A-F de auditoria defensiva.
- Documentação de referência completa:
  - Metodologia de auditoria (`references/audit-methodology.md`)
  - Segurança de autenticação (`references/authentication-security.md`)
  - Segurança de APIs (`references/api-security.md`)
  - Segurança de rede (`references/network-security.md`)
  - Segurança de bancos de dados (`references/database-security.md`)
  - Cloud e SaaS (`references/cloud-and-saas-security.md`)
  - Segurança de código (`references/code-security.md`)
  - Classificação de severidade com CVSS v3.1 (`references/severity-classification.md`)
  - Política de testes seguros (`references/safe-testing-policy.md`)
- Scripts de validação em Python 3:
  - `scripts/preflight.py` — Verificação pré-auditoria
  - `scripts/validate_scope.py` — Validação de escopo
  - `scripts/check_report.py` — Validação de relatório com detecção de segredos
- Testes automatizados (`scripts/tests/`)
- JSON Schemas para escopo e relatório (`schemas/`)
- Modelos reutilizáveis (`templates/`)
- Exemplos preenchidos (`examples/`)
- Adaptadores de integração para Semgrep, OWASP ZAP, Trivy, Gitleaks e Nmap (`integrations/`)
- Guias de instalação para Antigravity, Cursor e Claude Code (`agents/`)
- `README.md` com documentação completa em português brasileiro
- `SECURITY.md` com política de segurança do projeto
- `LICENSE` — Licença MIT

### Segurança

- Modo somente leitura como padrão
- Escopo obrigatório antes de testes ativos
- 12 controles de segurança documentados em `SKILL.md`
- Detecção de segredos em relatórios via `check_report.py`
- Proibição explícita de exploração automática de alto impacto
